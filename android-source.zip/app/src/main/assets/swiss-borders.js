/* Switzerland-only route verifier. Border geometry comes from a bundled GeoJSON
 * (ZHB/switzerland-geojson, based on Switzerland outline). Fail closed if not available.
 * This checks the WHOLE route, not just its selected waypoints. */
(function(root){
 'use strict';
 let swiss=null;
 let loading=null;
 const rad=Math.PI/180;
 const source='ZHB/switzerland-geojson (country/switzerland.geojson)';
 function km(a,b){
   const dl=(b[0]-a[0])*rad, dn=(b[1]-a[1])*rad;
   const s=Math.sin(dl/2)**2+Math.cos(a[0]*rad)*Math.cos(b[0]*rad)*Math.sin(dn/2)**2;
   return 12742*Math.asin(Math.min(1,Math.sqrt(s)));
 }
 function pointInRing(point,ring){
   const lon=point[1],lat=point[0];let inside=false;
   for(let i=0,j=ring.length-1;i<ring.length;j=i++){
     const a=ring[i],b=ring[j];
     if(((a[1]>lat)!==(b[1]>lat)) && lon<(b[0]-a[0])*(lat-a[1])/(b[1]-a[1])+a[0])inside=!inside;
   }
   return inside;
 }
 function inside(point,shape=swiss){
   if(!shape)return false;
   const polygons=shape.type==='Polygon'?[shape.coordinates]:shape.type==='MultiPolygon'?shape.coordinates:[];
   return polygons.some(poly=>pointInRing(point,poly[0]) && !poly.slice(1).some(hole=>pointInRing(point,hole)));
 }
 // Approximate minimum distance to the boundary in kilometres, projected locally.
 function borderDistanceKm(point,shape=swiss){
   const polygons=shape.type==='Polygon'?[shape.coordinates]:shape.type==='MultiPolygon'?shape.coordinates:[];
   const x=point[1]*111.2*Math.cos(point[0]*rad),y=point[0]*111.2;
   let best=Infinity;
   for(const polygon of polygons)for(const ring of polygon){
     for(let j=0;j<ring.length;j++){
       const a=ring[j],b=ring[(j+1)%ring.length];
       const ax=a[0]*111.2*Math.cos(point[0]*rad),bx=b[0]*111.2*Math.cos(point[0]*rad);
       const ay=a[1]*111.2,by=b[1]*111.2,dx=bx-ax,dy=by-ay;
       const t=(dx*dx+dy*dy)>0?Math.max(0,Math.min(1,((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy))):0;
       const d=Math.hypot(x-ax-t*dx,y-ay-t*dy);
       if(d<best)best=d;
     }
   }
   return best;
 }
 // Reject points within 300m of a simplified, historical boundary outline.
 // This deliberately rejects some legitimate border-hugging roads, rather than
 // claiming no border crossing when the reference data is not precise enough.
 function safeInside(point,shape=swiss){return inside(point,shape)&&borderDistanceKm(point,shape)>=0.3;}
 async function ensure(){
   if(swiss)return swiss;
   if(!loading)loading=(async()=>{
     const r=await fetch('swiss-border.geojson',{cache:'force-cache'});
     if(!r.ok)throw Error('boundary_unavailable');
     const data=await r.json();const geom=(data.features||[]).map(f=>f.geometry).find(g=>g&&(g.type==='Polygon'||g.type==='MultiPolygon'))||data.geometry||data;
     const count=geom?.type==='Polygon'?geom.coordinates?.[0]?.length:(geom?.coordinates?.[0]?.[0]?.length);
     if(!geom||!['Polygon','MultiPolygon'].includes(geom.type)||!(count>500))throw Error('boundary_unavailable');
     swiss=geom;return swiss;
   })().catch(e=>{loading=null;throw e});
   return loading;
 }
 function everySegmentInside(coords,shape=swiss){
   if(!shape||!Array.isArray(coords)||coords.length<2)return false;
   // 250-m samples detect intermediate crossings that have no OSRM vertex.
   for(let i=0;i<coords.length;i++){
     const p=coords[i];if(!Array.isArray(p)||!Number.isFinite(p[0])||!Number.isFinite(p[1])||!safeInside(p,shape))return false;
     if(i===0)continue;
     const prev=coords[i-1],parts=Math.max(1,Math.ceil(km(prev,p)/0.25));
     for(let j=1;j<parts;j++){
       const t=j/parts,mid=[prev[0]+(p[0]-prev[0])*t,prev[1]+(p[1]-prev[1])*t];
       if(!safeInside(mid,shape))return false;
     }
   }
   return true;
 }
 root.SwissBorders={ensure,safeInside,everySegmentInside,inside,borderDistanceKm,source,km};
})(typeof window!=='undefined'?window:globalThis);
