/* AlpRiders 0.21 border preference / route validation.
 * Switzerland-only retains the original detailed SwissBorder guard.
 * Neighbor outlines are Natural Earth 1:110m (public domain) and APPROXIMATE.
 * Routes in cross-border mode are experimental and must be checked by the rider.
 */
(function(root){
 'use strict';
 const codes=['FR','IT','DE','AT'];
 let borders=null,loading=null;
 const defaultPolicy=()=>({mode:'ch',countries:[]});
 function normalize(value){
   const c=Array.isArray(value?.countries)?[...new Set(value.countries.filter(x=>codes.includes(x)))]:[];
   return {mode:value?.mode==='neighbors'&&c.length?'neighbors':'ch',countries:c};
 }
 function isSwissOnly(policy){return normalize(policy).mode==='ch';}
 async function ensure(policy){
   await root.SwissBorders.ensure();
   if(isSwissOnly(policy))return;
   if(borders)return;
   if(!loading)loading=(async()=>{
     const response=await root.fetch('neighbor-countries.geojson',{cache:'force-cache'});
     if(!response.ok)throw Error('boundary_unavailable');
     const json=await response.json();
     const shapes=Object.create(null);
     for(const feature of json?.features||[]){
       const iso=feature.properties?.code;
       if(codes.includes(iso)&&['Polygon','MultiPolygon'].includes(feature.geometry?.type))shapes[iso]=feature.geometry;
     }
     if(codes.some(iso=>!shapes[iso]))throw Error('boundary_unavailable');
     borders=shapes;
   })().catch(e=>{loading=null;throw e});
   return loading;
 }
 function pointAllowed(point,policy){
   const p=normalize(policy);
   if(p.mode==='ch')return root.SwissBorders.safeInside(point);
   // In opted-in border mode use *inside* for Switzerland: SwissBorder's
   // 300m margin would otherwise block legal border crossings.
   if(root.SwissBorders.inside(point))return true;
   return !!borders && p.countries.some(code=>root.SwissBorders.inside(point,borders[code]));
 }
 function routeAllowed(coords,policy){
   const p=normalize(policy);
   if(p.mode==='ch')return root.SwissBorders.everySegmentInside(coords);
   if(!borders||!Array.isArray(coords)||coords.length<2)return false;
   const km=root.SwissBorders.km;
   for(let i=0;i<coords.length;i++){
     const v=coords[i];
     if(!Array.isArray(v)||v.length!==2||!v.every(Number.isFinite)||!pointAllowed(v,p))return false;
     if(!i)continue;
     const last=coords[i-1];
     const parts=Math.max(1,Math.ceil(km(last,v)/0.25));
     for(let step=1;step<parts;step++){
       const t=step/parts;
       if(!pointAllowed([last[0]+t*(v[0]-last[0]),last[1]+t*(v[1]-last[1])],p))return false;
     }
   }
   return true;
 }
 function routeInfo(policy){
   const p=normalize(policy);
   return {swissVerified:true, borderPolicy:p, country:p.mode==='ch'?'CH':'CH+'+p.countries.join('+')};
 }
 root.AlpAllowedCountries={defaultPolicy,normalize,isSwissOnly,ensure,pointAllowed,routeAllowed,routeInfo,codes};
})(typeof window!=='undefined'?window:globalThis);
