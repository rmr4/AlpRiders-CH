/* Route geometry helpers. This is not traffic/closure information. */
(function(root){
 'use strict';
 const R=6371000,rad=Math.PI/180;
 function metres(a,b){
  const dlat=(b[0]-a[0])*rad,dlon=(b[1]-a[1])*rad;
  const q=Math.sin(dlat/2)**2+Math.cos(a[0]*rad)*Math.cos(b[0]*rad)*Math.sin(dlon/2)**2;
  return 2*R*Math.asin(Math.min(1,Math.sqrt(q)));
 }
 function pointAt(path,distance){
  if(!path?.length)return null;
  let d=0;
  for(let i=1;i<path.length;i++){
   const leg=metres(path[i-1],path[i]);
   if(d+leg>=distance&&leg>0){const f=Math.max(0,(distance-d)/leg);
    return [path[i-1][0]+(path[i][0]-path[i-1][0])*f,path[i-1][1]+(path[i][1]-path[i-1][1])*f];}
   d+=leg;
  }
  return path[path.length-1];
 }
 function closestAlong(path,p,minimum=0){
  if(!path?.length||!p)return null;
  let best=Infinity,along=null,soFar=0;
  for(let i=1;i<path.length;i++){
   const a=path[i-1],b=path[i],seg=metres(a,b);
   const latScale=111195,lonScale=111195*Math.cos((a[0]+b[0])*rad/2);
   const dx=(b[1]-a[1])*lonScale,dy=(b[0]-a[0])*latScale;
   const px=(p[1]-a[1])*lonScale,py=(p[0]-a[0])*latScale;
   const f=dx*dx+dy*dy>0?Math.max(0,Math.min(1,(px*dx+py*dy)/(dx*dx+dy*dy))):0;
   const pos=soFar+seg*f;
   const dd=Math.hypot(px-f*dx,py-f*dy);
   if(pos>=minimum-30&&dd<best){best=dd;along=pos;}
   soFar+=seg;
  }
  return along;
 }
 function remainingStops(path,stops,along){
  if(!Array.isArray(stops)||stops.length<2)return [];
  const result=[],all=stops.slice(1,-1);
  let lastSeen=0;
  for(const p of all){
   const projected=closestAlong(path,p,lastSeen);
   if(projected==null)continue;
   if(projected>along+300)result.push(p);
   lastSeen=Math.max(lastSeen,projected);
  }
  result.push(stops[stops.length-1]);
  return result.slice(0,8);
 }
 function nearCorridor(path,blocked,radius=260){
  if(!blocked||!Array.isArray(path)||path.length<2)return true;
  for(let i=1;i<path.length;i++){
   const p=path[i-1],q=path[i],n=Math.max(1,Math.ceil(metres(p,q)/90));
   for(let j=0;j<=n;j++){
    const f=j/n,x=[p[0]+(q[0]-p[0])*f,p[1]+(q[1]-p[1])*f];
    if(metres(x,blocked)<radius)return true;
   }
  }
  return false;
 }
 function sidePoints(gps,block,distKm){
  const scaleLat=111.195,scaleLon=scaleLat*Math.cos(gps[0]*rad);
  const dx=(block[1]-gps[1])*scaleLon,dy=(block[0]-gps[0])*scaleLat;
  const length=Math.hypot(dx,dy)||1;
  const result=[];
  for(const direction of [1,-1]){
   const x=(direction*(-dy)/length)*distKm,y=(direction*dx/length)*distKm;
   result.push([gps[0]+y/scaleLat,gps[1]+x/scaleLon]);
  }
  return result;
 }
 root.AlpRideDetour={metres,pointAt,closestAlong,remainingStops,nearCorridor,sidePoints};
})(typeof window!=='undefined'?window:globalThis);
