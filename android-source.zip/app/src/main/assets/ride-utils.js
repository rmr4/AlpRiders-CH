/* Pure routing and contact helpers. No network or Android permissions. */
(function(root) {
 'use strict';
 const toRad=Math.PI/180;
 function km(a,b){
   const dl=(b[0]-a[0])*toRad, dn=(b[1]-a[1])*toRad;
   const v=Math.sin(dl/2)**2+Math.cos(a[0]*toRad)*Math.cos(b[0]*toRad)*Math.sin(dn/2)**2;
   return 12742*Math.asin(Math.min(1,Math.sqrt(v)));
 }
 function isClosed(waypoints){return waypoints.length>=3&&km(waypoints[0],waypoints[waypoints.length-1])<0.15;}
 function distinctWaypoints(waypoints){
   if (!Array.isArray(waypoints)) throw Error('Pontos inválidos');
   const filtered=waypoints.map(p=>[Number(p[0]),Number(p[1])]);
   if(filtered.some(p=>!Number.isFinite(p[0])||!Number.isFinite(p[1])))throw Error('Pontos inválidos');
   if(isClosed(filtered))filtered.pop();
   return filtered;
 }
 function roundTripWaypoints(waypoints){
   const route=distinctWaypoints(waypoints);
   if(route.length<3)throw Error('Para um circuito, marca a partida e pelo menos dois pontos intermédios diferentes.');
   for(let i=0;i<route.length;i++)for(let j=i+1;j<route.length;j++){
     if(km(route[i],route[j])<2.5)throw Error('Afasta os pontos intermédios para criar um passeio circular, não uma ida e volta.');
   }
   return [...route, [...route[0]]];
 }
 // Sample an OSRM leg uniformly (~100 m) and compare the return leg with outward legs.
 function sampledLeg(leg,stepKm=0.10){
   const coords=(leg.steps||[]).flatMap(step=>(step.geometry?.coordinates||[]).map(p=>[p[1],p[0]]));
   if(coords.length<2)return [];
   const out=[coords[0]];
   for(let i=1;i<coords.length;i++){
     const prev=coords[i-1],next=coords[i];const distance=km(prev,next);
     const parts=Math.max(1,Math.ceil(distance/stepKm));
     for(let j=1;j<=parts;j++){const t=j/parts;out.push([prev[0]+(next[0]-prev[0])*t,prev[1]+(next[1]-prev[1])*t]);}
   }
   return out;
 }
 function grid(p){
   // 60-70 m grid at Swiss latitudes, a conservative indicator for retraced road.
   return `${Math.round(p[0]*1600)}:${Math.round(p[1]*2300)}`;
 }
 function retraceFraction(legs){
   if(!Array.isArray(legs)||legs.length<3)return null;
   const outbound=legs.slice(0,-1).flatMap(l=>sampledLeg(l));
   const inbound=sampledLeg(legs[legs.length-1]);
   if(outbound.length<20||inbound.length<20)return null;
   const used=new Set(outbound.map(grid));
   let matching=0;
   for(const p of inbound){const lat=Math.round(p[0]*1600),lon=Math.round(p[1]*2300);
     let found=false;
     for(let i=-1;i<=1&&!found;i++)for(let j=-1;j<=1;j++)if(used.has(`${lat+i}:${lon+j}`)){found=true;break;}
     if(found)matching++;
   }
   return matching/inbound.length;
 }
 function parseWhatsappNumber(raw){
   const original=String(raw||'').trim();
   if(!original.startsWith('+'))return '';
   const number=original.replace(/[\s()\-]/g,'');
   return /^\+[1-9][0-9]{7,14}$/.test(number)?number.slice(1):'';
 }
 root.AlpRideUtils={km,isClosed,distinctWaypoints,roundTripWaypoints,retraceFraction,parseWhatsappNumber};
})(typeof window!=='undefined'?window:globalThis);
