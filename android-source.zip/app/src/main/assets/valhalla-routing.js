/* AlpRiders v0.18 — limited Valhalla demo adapter.
 * Valhalla returns OSRM-compatible GeoJSON/steps so the existing map, border
 * validation and turn prompts can be retained. Never treat returned directions
 * as verified Swiss routes until SwissBorders.everySegmentInside passes. */
(function(root){
 'use strict';
 const DEMO='https://valhalla1.openstreetmap.de/route';
 const VALID_LANG={pt:'pt-PT',fr:'fr-FR',de:'de-DE',it:'it-IT',es:'es-ES',en:'en-GB'};
 const km=(a,b)=>root.AlpRideUtils?.km(a,b)??0;
 function requestBody(stops,opts={}){
   if(!Array.isArray(stops)||stops.length<2||stops.length>12||stops.some(p=>
     !Array.isArray(p)||p.length!==2||!p.every(Number.isFinite)))throw Error('invalid_waypoints');
   const alternatives=Math.max(0,Math.min(3,Math.floor(Number(opts.alternatives)||0)));
   const result={
     locations:stops.map(([lat,lon])=>({lat,lon,type:'break'})),
     costing:'motorcycle',format:'osrm',shape_format:'geojson',
     units:'kilometers',language:VALID_LANG[opts.language]||'pt-PT',
     directions_type:'instructions',
     costing_options:{motorcycle:{use_highway:0.25,use_trails:0,
       // Discourages leaving CH but is NOT a hard border exclusion.
       country_crossing_penalty:opts.allowBorders?0:18000}},
   };
   if(alternatives&&stops.length===2)result.alternates=alternatives;
   if(Array.isArray(opts.excludeLocations)&&opts.excludeLocations.length){
     const valid=opts.excludeLocations.slice(0,6).filter(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite));
     if(valid.length)result.exclude_locations=valid.map(([lat,lon])=>({lat,lon}));
   }
   return result;
 }
 async function route(stops,opts={}){
   if(opts.budget){
     if(opts.budget.used>=opts.budget.max)throw Error('routing_budget');
     opts.budget.used++;
   }
   const payload=requestBody(stops,opts);
   const fetcher=opts.fetcher||root.fetch;
   const timeout=Math.max(3000,Math.min(30000,opts.timeoutMs||18000));
   let response;
   try{
     response=await fetcher(opts.endpoint||DEMO,{
       method:'POST',headers:{'Content-Type':'application/json','X-Client-Id':'alpriders-ch-test'},
       body:JSON.stringify(payload),signal:AbortSignal.timeout(timeout)});
   }catch(e){if(e?.name==='AbortError'||e?.name==='TimeoutError')throw Error('routing_timeout');throw Error('routing');}
   if(response.status===429)throw Error('routing_rate_limited');
   if(!response.ok)throw Error('routing');
   let data;
   try{data=await response.json();}catch{throw Error('routing');}
   if(!Array.isArray(data.routes)||!data.routes.length)throw Error('routing');
   return data;
 }
 // Select points clearly OUTSIDE the actual Swiss outline from a rejected
 // route. The Valhalla exclude_locations mechanism attempts to avoid the
 // offending foreign roads on the next request. No claim of hard exclusion.
 function foreignRoadPoints(data,borders=root.SwissBorders){
   if(!borders?.inside)return [];
   const candidates=[];
   for(const r of data?.routes||[]){
     for(const [lon,lat] of r?.geometry?.coordinates||[]){
       const pt=[lat,lon];
       if(Number.isFinite(lat)&&Number.isFinite(lon)&&!borders.inside(pt)){
         if(candidates.every(p=>km(pt,p)>0.8))candidates.push(pt);
       }
     }
     if(candidates.length>=3)break;
   }
   if(candidates.length<=3)return candidates;
   return [candidates[0],candidates[Math.floor(candidates.length/2)],candidates[candidates.length-1]];
 }
 root.AlpValhalla={route,requestBody,foreignRoadPoints,DEMO};
})(typeof window!=='undefined'?window:globalThis);
