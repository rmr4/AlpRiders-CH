/* Offline route-candidate selection and checked, leg-by-leg fallback for routing services with OSRM output.
 * Never bypass the Switzerland geometry guard or fabricate manoeuvres. */
(function(root){
 'use strict';
 const km=(a,b)=>root.AlpRideUtils.km(a,b);
 function scorePath(path){
   if(!Array.isArray(path)||path.length<4)return -Infinity;
   let straight=0,interior=0;
   for(let i=1;i<path.length;i++){
     const d=km(path[i-1],path[i]);straight+=d;
     // Pre-screen merely prioritises routes. Real road still MUST be checked.
     // Only a quick prioritisation heuristic: the COMPLETE road is checked
     // later. Sampling a long straight segment every 250m here would freeze UI.
     const a=path[i-1],b=path[i];
     if([0.25,0.5,0.75].every(t=>root.SwissBorders.safeInside([
       a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])])))interior++;
   }
   return interior*2.5 + Math.min(straight/100,2.5);
 }
 // Alternate scenic and non-scenic candidates, with far enough via-points.
 // Prevent the first 18 attempts from all using the same towns/roads.
 function prioritize(paths,start,limit=18){
   const ranked=(paths||[]).filter(path=>Array.isArray(path)&&path.length>=4&&
     path.every(p=>root.SwissBorders.safeInside(p)))
     .map(path=>({path,score:scorePath(path)}))
     .sort((a,b)=>b.score-a.score);
   const chosen=[],centres=[];
   for(let spacing of [9,4,0]){
     for(const item of ranked){
       if(chosen.some(x=>x===item.path))continue;
       const mids=item.path.slice(1,-1);
       const distinct=centres.every(prev=>mids.some(p=>prev.every(q=>km(p,q)>spacing)));
       if(!distinct)continue;
       chosen.push(item.path);centres.push(mids);
       if(chosen.length>=limit)return chosen;
     }
   }
   return chosen;
 }
 function checkRoute(route,options={}){
   if(!route?.geometry?.coordinates || route.geometry.coordinates.length<2)return null;
   const geometry=route.geometry.coordinates.map(p=>[p[1],p[0]]);
   if(!root.SwissBorders.everySegmentInside(geometry))return null;
   if(options.blockedPoints?.some(p=>root.AlpRideDetour.nearCorridor(geometry,p,options.avoidRadius||280)))return null;
   const legs=route.legs||[];
   return {geometry,swissVerified:true,country:'CH',distance:(route.distance/1000).toFixed(1),
     duration:Math.round(route.duration/60),returnOverlap:root.AlpRideUtils.retraceFraction(legs),
     steps:legs.flatMap(leg=>(leg.steps||[]).map(st=>({p:[st.maneuver.location[1],st.maneuver.location[0]],
     type:st.maneuver.type||'',mod:st.maneuver.modifier||'',name:st.name||''}))),
     _legs:legs};
 }
 function fromResponse(data,opts){
   const valid=(data?.routes||[]).map(r=>checkRoute(r,opts)).filter(Boolean);
   return valid.sort((a,b)=>Number(a.distance)-Number(b.distance));
 }
 // If the routing engine picks a French shortcut on a full circuit, ask separately for each
 // Swiss-to-Swiss leg and its alternatives. Still reject any leg outside CH.
 async function legwise(waypoints,request,opts={}){
   if(!Array.isArray(waypoints)||waypoints.length<4||waypoints.length>7)return null;
   const alternatives=[];
   for(let i=1;i<waypoints.length;i++){
     let data;
     try{data=await request([waypoints[i-1],waypoints[i]],3);}catch{return null;}
     const options=fromResponse(data,opts).slice(0,3);
     if(!options.length)return null;
     alternatives.push(options);
   }
   const target=opts.targetMinutes||120;
   const maxOverlap=opts.maxOverlap??0.27;
   let best=null, bestScore=Infinity,checked=0;
   function visit(i,picked){
     if(checked>=300)return;
     if(i===alternatives.length){
       checked++;
       const legs=picked.flatMap(x=>x._legs);
       const overlap=root.AlpRideUtils.retraceFraction(legs);
       if(overlap===null||overlap>maxOverlap)return;
       const geometry=picked.flatMap((x,index)=>index?x.geometry.slice(1):x.geometry);
       if(!root.SwissBorders.everySegmentInside(geometry))return;
       const distance=picked.reduce((s,x)=>s+Number(x.distance),0);
       const duration=picked.reduce((s,x)=>s+x.duration,0);
       const score=Math.abs(duration-target)/Math.max(1,target)+overlap*1.8;
       if(score<bestScore){bestScore=score;best={geometry,swissVerified:true,country:'CH',
         distance:distance.toFixed(1),duration,returnOverlap:overlap,
         steps:picked.flatMap(x=>x.steps),recovery:'via_trocos'};}
       return;
     }
     for(const candidate of alternatives[i])visit(i+1,[...picked,candidate]);
   }
   visit(0,[]);
   return best;
 }
 root.AlpRouteRecovery={prioritize,fromResponse,legwise,scorePath};
})(typeof window!=='undefined'?window:globalThis);
