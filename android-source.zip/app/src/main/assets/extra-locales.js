/* Complete missing principal-screen strings and localize future status messages. */
(function(){
'use strict';
if(typeof i18n!=='object'||typeof translatePage!=='function')return;
Object.assign(i18n, {
  "Protótipo experimental: usa locais panorâmicos como pontos intermédios e um serviço público de rotas rodoviárias para automóveis. A duração pode variar. Não confirma que as estradas e passagens alpinas estão abertas, oferece indicações experimentais na página, mas não substitui um GPS homologado ou a verificação da estrada.": [
    "Prototype expérimental : utilise des points panoramiques et un service public de calcul d’itinéraires automobiles. Les durées peuvent varier. Vérifie les fermetures de cols et l’état des routes : ce n’est pas un GPS moto certifié.",
    "Prototipo sperimentale: usa punti panoramici e un servizio pubblico di itinerari per auto. I tempi possono variare. Controlla la chiusura dei passi e le condizioni stradali: non è un navigatore moto certificato.",
    "Prototipo experimental: usa lugares panorámicos y un servicio público de rutas para coches. Los tiempos pueden variar. Consulta los puertos cerrados y el estado de las carreteras: no es un GPS de moto certificado.",
    "Experimenteller Prototyp: nutzt Aussichtspunkte und einen öffentlichen Routenservice für Autos. Fahrzeiten können abweichen. Prüfe Passsperrungen und Strassenzustand; kein zertifiziertes Motorrad-Navi.",
    "Experimental prototype: uses scenic waypoints and a public car-routing service. Travel times may vary. Check mountain-pass closures and road conditions; this is not a certified motorcycle navigator."
  ],
  "Indica a rua, número, código postal e localidade na Suíça. A pesquisa precisa de Internet e deve confirmar o número de porta.": [
    "Saisis une rue, un numéro et une localité en Suisse. Choisis ensuite une adresse exacte parmi les suggestions.",
    "Inserisci via, numero civico e località in Svizzera. Seleziona quindi un indirizzo esatto tra i suggerimenti.",
    "Escribe una calle, número y localidad de Suiza. Después elige una dirección exacta de las sugerencias.",
    "Gib Strasse, Hausnummer und Ort in der Schweiz ein. Wähle danach eine genaue Adresse aus den Vorschlägen.",
    "Enter a street, house number and town in Switzerland, then select an exact address from the suggestions."
  ],
  "Escolher partida no mapa": [
    "Choisir le départ sur la carte",
    "Scegli partenza sulla mappa",
    "Elegir salida en el mapa",
    "Startpunkt auf Karte wählen",
    "Choose start on map"
  ],
  "A app só aceita um destino localizado e um percurso verificado dentro da Suíça.": [
    "Seules les destinations identifiées et les routes vérifiées en Suisse sont acceptées.",
    "Sono accettate solo destinazioni individuate e percorsi verificati in Svizzera.",
    "Solo se aceptan destinos identificados y rutas verificadas en Suiza.",
    "Nur gefundene Ziele und geprüfte Routen innerhalb der Schweiz werden akzeptiert.",
    "Only verified destinations and routes within Switzerland are accepted."
  ],
  "Velocidade GPS": [
    "Vitesse GPS",
    "Velocità GPS",
    "Velocidad GPS",
    "GPS-Geschwindigkeit",
    "GPS speed"
  ],
  "Ativar GPS": [
    "Activer le GPS",
    "Attiva GPS",
    "Activar GPS",
    "GPS einschalten",
    "Enable GPS"
  ],
  "Precisa de autorização de localização e normalmente de um endereço HTTPS. Indicador de teste; não substitui o velocímetro da mota.": [
    "Autorisation de localisation nécessaire. Affichage expérimental, pas un compteur de vitesse certifié.",
    "È necessaria l’autorizzazione alla posizione. Indicatore di prova, non sostituisce il tachimetro della moto.",
    "Necesita permiso de ubicación. Indicador de prueba, no sustituye al velocímetro de la moto.",
    "Standortberechtigung erforderlich. Testanzeige; kein Ersatz für den Motorradtacho.",
    "Location permission required. Experimental display; not a substitute for the motorcycle speedometer."
  ],
  "🧭 Iniciar navegação aqui": [
    "🧭 Démarrer le guidage",
    "🧭 Avvia navigazione",
    "🧭 Iniciar navegación",
    "🧭 Navigation starten",
    "🧭 Start navigation"
  ],
  "Toca no mapa para marcar os pontos da tua rota.": [
    "Touche la carte pour placer les étapes de l’itinéraire.",
    "Tocca la mappa per inserire le tappe del percorso.",
    "Toca el mapa para colocar los puntos de la ruta.",
    "Tippe auf die Karte, um Routenpunkte zu setzen.",
    "Tap the map to add route points."
  ],
  "📍 Partida no meu GPS": [
    "📍 Départ depuis mon GPS",
    "📍 Partenza dal GPS",
    "📍 Salida desde mi GPS",
    "📍 Start am GPS-Standort",
    "📍 Start at my GPS"
  ],
  "🗺️ Partida no mapa": [
    "🗺️ Départ sur la carte",
    "🗺️ Partenza sulla mappa",
    "🗺️ Salida en el mapa",
    "🗺️ Start auf der Karte",
    "🗺️ Start on map"
  ],
  "Exemplo: Martigny → Verbier": [
    "Exemple : Martigny → Verbier",
    "Esempio: Martigny → Verbier",
    "Ejemplo: Martigny → Verbier",
    "Beispiel: Martigny → Verbier",
    "Example: Martigny → Verbier"
  ],
  "🇨🇭 Suíça apenas · não atravessar fronteiras": [
    "🇨🇭 Suisse uniquement · sans franchir de frontière",
    "🇨🇭 Solo Svizzera · senza attraversare confini",
    "🇨🇭 Solo Suiza · sin cruzar fronteras",
    "🇨🇭 Nur Schweiz · keine Grenzübertritte",
    "🇨🇭 Switzerland only · no border crossings"
  ],
  "O percurso completo é verificado antes de aparecer no mapa. Quando a fronteira cartográfica indicar passagem por França ou outro país, a rota será recusada. Algumas estradas suíças perto da fronteira poderão também ser recusadas por precaução; confirma sempre o percurso antes de conduzir.": [
    "Tout le tracé est contrôlé avant affichage. Les passages de frontière sont refusés. Certaines routes suisses proches des frontières peuvent aussi être exclues : vérifie l’itinéraire avant de partir.",
    "L’intero tracciato viene controllato prima della visualizzazione. I passaggi di confine sono rifiutati. Alcune strade svizzere vicine ai confini possono essere escluse: verifica l’itinerario prima di partire.",
    "Se comprueba toda la ruta antes de mostrarla. Se rechazan los cruces de frontera. Algunas carreteras suizas cercanas al límite también pueden excluirse: revisa la ruta antes de salir.",
    "Die gesamte Strecke wird vor der Anzeige geprüft. Grenzübertritte werden abgelehnt. Einige Schweizer Strassen nahe der Grenze können ebenfalls ausgeschlossen sein: prüfe die Route vor Fahrtbeginn.",
    "The entire route is checked before display. Border crossings are rejected. Some Swiss roads close to borders may also be excluded: review the route before riding."
  ],
  "Marca pelo menos dois pontos no mapa.": [
    "Marque au moins deux points sur la carte.",
    "Segna almeno due punti sulla mappa.",
    "Marca al menos dos puntos en el mapa.",
    "Setze mindestens zwei Punkte auf der Karte.",
    "Add at least two points on the map."
  ],
  "🇨🇭 Modo Suíça: só se aceitam rotas verificadas contra o limite do país. Não é garantia de fronteiras rodoviárias exatas ou de acesso legal. O cálculo de estrada usa um serviço público experimental para automóveis. Não substitui navegação GPS para motociclos. Consulta sempre os encerramentos das passagens alpinas.": [
    "Mode Suisse : vérification cartographique approximative. Service public de routage automobile expérimental, sans garantie d’accès légal. Vérifie les cols fermés et utilise un GPS moto fiable.",
    "Modalità Svizzera: controllo cartografico approssimativo. Servizio pubblico sperimentale per auto, senza garanzia di accesso legale. Controlla i passi chiusi e usa un GPS moto affidabile.",
    "Modo Suiza: comprobación cartográfica aproximada. Servicio público experimental para coches, sin garantía de acceso legal. Consulta los puertos cerrados y usa un GPS de moto fiable.",
    "Schweiz-Modus: ungefähre Kartenprüfung. Experimenteller öffentlicher Autorouter ohne Gewähr für die rechtliche Befahrbarkeit. Prüfe Passsperrungen und nutze ein zuverlässiges Motorrad-Navi.",
    "Swiss mode: approximate boundary check using an experimental public car router. Legal access is not guaranteed. Check pass closures and use reliable motorcycle navigation."
  ],
  "Ainda não tens percursos guardados.": [
    "Aucun itinéraire enregistré.",
    "Nessun percorso salvato.",
    "Aún no hay rutas guardadas.",
    "Noch keine gespeicherten Routen.",
    "No saved routes yet."
  ],
  "🌍 Chat geral AlpRiders CH": [
    "🌍 Discussion générale AlpRiders CH",
    "🌍 Chat generale AlpRiders CH",
    "🌍 Chat general AlpRiders CH",
    "🌍 Allgemeiner Chat AlpRiders CH",
    "🌍 AlpRiders CH community chat"
  ],
  "SEM SERVIDOR": [
    "SERVEUR ABSENT",
    "SENZA SERVER",
    "SIN SERVIDOR",
    "KEIN SERVER",
    "NO SERVER"
  ],
  "Para todos os motards registados na AlpRiders CH. As mensagens são visíveis a todos os utilizadores autenticados; não partilhes moradas, números ou localizações privadas.": [
    "Pour tous les motards inscrits. Les messages sont visibles par tous les membres connectés. Ne partage pas d’adresse ni de localisation privée.",
    "Per tutti i motociclisti registrati. I messaggi sono visibili a chi ha effettuato l’accesso. Non condividere indirizzi o posizioni private.",
    "Para todos los motoristas registrados. Los mensajes son visibles para los usuarios conectados. No compartas direcciones ni ubicaciones privadas.",
    "Für alle registrierten Motorradfahrer. Angemeldete Nutzer können Nachrichten lesen. Keine privaten Adressen oder Standorte teilen.",
    "For all registered riders. Messages are visible to signed-in users. Do not share private addresses or locations."
  ],
  "O chat geral precisa de um servidor Supabase configurado. Não está ativo nesta instalação.": [
    "Le chat général nécessite un serveur Supabase configuré. Il est inactif sur cet appareil.",
    "La chat generale richiede un server Supabase configurato. Non è attiva su questo dispositivo.",
    "El chat general necesita un servidor Supabase configurado. No está activo aquí.",
    "Der öffentliche Chat benötigt einen eingerichteten Supabase-Server. Er ist hier nicht aktiv.",
    "Community chat needs a configured Supabase server. It is not active on this device."
  ],
  "Liga o servidor e entra na tua conta para conversar.": [
    "Connecte le serveur et ouvre une session pour discuter.",
    "Collega il server e accedi per chattare.",
    "Conecta el servidor e inicia sesión para chatear.",
    "Verbinde den Server und melde dich zum Chatten an.",
    "Connect the server and sign in to chat."
  ],
  "Configurar servidor / entrar": [
    "Configurer le serveur / se connecter",
    "Configura server / accedi",
    "Configurar servidor / entrar",
    "Server einrichten / anmelden",
    "Configure server / sign in"
  ],
  "A localização só é solicitada quando utilizas GPS, crias um passeio a partir da posição atual ou pedes a posição SOS. O teu nome, rota e mensagens não são partilhados com outros utilizadores nesta demonstração.": [
    "La position n’est demandée que pour le GPS, les itinéraires au départ de ta position ou le SOS. Le partage dépend des fonctionnalités en ligne activées.",
    "La posizione è richiesta solo per GPS, itinerari dalla posizione attuale o SOS. La condivisione dipende dalle funzioni online attivate.",
    "La ubicación solo se solicita para GPS, rutas desde tu posición o SOS. La información compartida depende de las funciones en línea activadas.",
    "Der Standort wird nur für GPS, Routen ab deiner Position oder SOS angefragt. Die Freigabe hängt von den aktivierten Online-Funktionen ab.",
    "Location is requested only for GPS, routes starting near you, or SOS. Sharing depends on which online features are enabled."
  ],
  "Depois de publicar esta versão num endereço HTTPS, abre-a no Chrome e escolhe “Adicionar ao ecrã inicial”.": [
    "Pour la version web, ouvre le site dans Chrome et ajoute-le à l’écran d’accueil.",
    "Per la versione web, apri il sito in Chrome e aggiungilo alla schermata iniziale.",
    "Para la versión web, abre el sitio en Chrome y añádelo a la pantalla de inicio.",
    "Für die Webversion öffne die Website in Chrome und füge sie dem Startbildschirm hinzu.",
    "For the web version, open the site in Chrome and add it to your home screen."
  ],
  "Estes botões abrem o marcador do telemóvel; a chamada tem de ser confirmada no Android. Não dependas desta app numa emergência.": [
    "Ces boutons ouvrent le composeur téléphonique. Confirme l’appel sur Android. En cas d’urgence, ne dépends pas de cette appli.",
    "Questi pulsanti aprono il tastierino del telefono. Conferma la chiamata su Android. Non affidarti a questa app in emergenza.",
    "Estos botones abren el marcador. Confirma la llamada en Android. No dependas de esta app en una emergencia.",
    "Diese Tasten öffnen die Telefon-App. Bestätige den Anruf unter Android. Verlasse dich im Notfall nicht auf diese App.",
    "These buttons open your phone dialer. Confirm the call on Android. Do not rely on this app in an emergency."
  ],
  "Ainda não foi obtida uma posição GPS recente.": [
    "Aucune position GPS récente.",
    "Nessuna posizione GPS recente.",
    "No hay una posición GPS reciente.",
    "Kein aktueller GPS-Standort vorhanden.",
    "No recent GPS fix available."
  ],
  "depois de obteres o GPS, carrega no contacto para abrir o WhatsApp com a mensagem pronta. Confirma o destinatário e o envio no WhatsApp. Nada é enviado automaticamente.": [
    "Après localisation GPS, ouvre le contact dans WhatsApp. Vérifie le destinataire et envoie toi-même le message ; rien n’est envoyé automatiquement.",
    "Dopo aver ottenuto il GPS, apri il contatto su WhatsApp. Controlla il destinatario e invia tu il messaggio; nulla viene inviato automaticamente.",
    "Después de obtener el GPS, abre el contacto en WhatsApp. Revisa el destinatario y envía el mensaje; no se envía nada automáticamente.",
    "Öffne nach der GPS-Ortung den Kontakt in WhatsApp. Prüfe den Empfänger und sende selbst; nichts wird automatisch verschickt.",
    "After getting GPS location, open the WhatsApp contact. Check the recipient and send manually; nothing is sent automatically."
  ],
  "🏍️ Assistência em viagem — manual": [
    "🏍️ Assistance en route — manuelle",
    "🏍️ Assistenza durante il viaggio — manuale",
    "🏍️ Asistencia en ruta — manual",
    "🏍️ Hilfe unterwegs — manuell",
    "🏍️ Roadside help — manual"
  ],
  "Se tiveres uma avaria, guarda um contacto de confiança acima e usa «Preparar WhatsApp». A mensagem será aberta para revisão e envio. Esta app não está ligada a uma empresa de assistência e não deteta acidentes automaticamente.": [
    "En cas de panne, ajoute un contact et prépare un message WhatsApp. Vérifie-le avant envoi. Cette appli n’est reliée à aucun service de dépannage et ne détecte pas les accidents automatiquement.",
    "In caso di guasto, salva un contatto e prepara un messaggio WhatsApp. Controllalo prima dell’invio. L’app non è collegata al soccorso stradale e non rileva incidenti automaticamente.",
    "En caso de avería, guarda un contacto y prepara un WhatsApp. Revísalo antes de enviarlo. La app no está conectada a una empresa de asistencia ni detecta accidentes automáticamente.",
    "Bei einer Panne speichere einen Kontakt und bereite eine WhatsApp-Nachricht vor. Prüfe sie vor dem Senden. Keine Verbindung zu einem Pannendienst oder automatische Unfallmeldung.",
    "If you break down, save a contact and prepare a WhatsApp message. Review before sending. This app has no roadside assistance provider and does not automatically detect accidents."
  ],
  "Em caso de acidente com feridos ou perigo imediato, utiliza o número 112/144 diretamente. Não dependas do WhatsApp.": [
    "En cas de blessés ou de danger immédiat, appelle directement le 112 ou le 144. Ne compte pas sur WhatsApp.",
    "In caso di feriti o pericolo immediato, chiama il 112 o il 144. Non affidarti a WhatsApp.",
    "Si hay heridos o peligro inmediato, llama al 112 o al 144. No dependas de WhatsApp.",
    "Bei Verletzten oder akuter Gefahr direkt 112 oder 144 wählen. Verlasse dich nicht auf WhatsApp.",
    "For injuries or immediate danger, call 112 or 144 directly. Do not rely on WhatsApp."
  ],
  "🛡️ Monitor de segurança — TESTE": [
    "🛡️ Surveillance de sécurité — TEST",
    "🛡️ Monitoraggio sicurezza — TEST",
    "🛡️ Monitor de seguridad — PRUEBA",
    "🛡️ Sicherheitsüberwachung — TEST",
    "🛡️ Safety monitor — TEST"
  ],
  "Com passeio ativo, acompanha o GPS no Android com uma notificação permanente. Depois de 45 segundos de deslocação, pode avisar se ficares parado durante 20 minutos ou após um movimento brusco seguido de paragem. Não deteta acidentes de forma fiável.": [
    "Pendant une balade, l’application suit le GPS avec une notification. Après 45 s de mouvement, elle peut avertir après 20 min d’arrêt ou un choc suivi d’immobilité. Détection non fiable.",
    "Durante un giro segue il GPS con notifica. Dopo 45 s in movimento, può avvisare dopo 20 min di arresto o un urto seguito da immobilità. Rilevamento non affidabile.",
    "Durante una ruta sigue el GPS con una notificación. Tras 45 s en marcha puede avisar tras 20 min parado o un golpe seguido de inmovilidad. Detección no fiable.",
    "Während einer Fahrt verfolgt die App GPS mit Benachrichtigung. Nach 45 s Bewegung kann sie bei 20 min Stillstand oder nach einem Stoss warnen. Keine zuverlässige Unfallerkennung.",
    "During a ride GPS is tracked with a notification. After 45 s of movement it may alert after 20 min stopped or an impact followed by stillness. Detection is not reliable."
  ],
  "A monitorização inicia automaticamente quando abres a app, depois de dares consentimento e permissões. Se tocares em «Parar monitor», o arranque automático fica desativado até voltares a ativá-lo. Não há chamadas ou mensagens automáticas.": [
    "La surveillance démarre à l’ouverture après ton consentement. « Arrêter » désactive le démarrage automatique. Aucun appel ni message automatique.",
    "Il monitor parte all’apertura dopo il consenso. « Arresta » disattiva l’avvio automatico. Nessuna chiamata o messaggio automatico.",
    "El monitor se inicia al abrir tras tu consentimiento. « Detener » desactiva el inicio automático. No hay llamadas ni mensajes automáticos.",
    "Die Überwachung startet nach Einwilligung beim Öffnen. « Stoppen » deaktiviert den Autostart. Keine automatischen Anrufe oder Nachrichten.",
    "Monitoring starts on opening after consent. “Stop” disables automatic restart. No automatic calls or messages."
  ],
  "Monitor de teste parado. Ativa-o uma vez para começar automaticamente nas próximas aberturas.": [
    "Surveillance arrêtée. Active-la une fois pour le prochain démarrage.",
    "Monitor fermo. Attivalo una volta per gli avvii successivi.",
    "Monitor detenido. Actívalo una vez para los próximos inicios.",
    "Testüberwachung gestoppt. Einmalig aktivieren für kommende Starts.",
    "Test monitor stopped. Enable it once for future launches."
  ],
  "Ativar monitor automático": [
    "Activer surveillance automatique",
    "Attiva monitor automatico",
    "Activar monitor automático",
    "Automatische Überwachung aktivieren",
    "Enable automatic monitor"
  ],
  "Parar monitor": [
    "Arrêter la surveillance",
    "Arresta monitor",
    "Detener monitor",
    "Überwachung stoppen",
    "Stop monitor"
  ],
  "Testar alarme 60 s": [
    "Tester l’alarme 60 s",
    "Prova allarme 60 s",
    "Probar alarma 60 s",
    "Alarm 60 s testen",
    "Test 60-second alarm"
  ],
  "Estou bem · cancelar": [
    "Tout va bien · annuler",
    "Sto bene · annulla",
    "Estoy bien · cancelar",
    "Alles gut · abbrechen",
    "I am OK · cancel"
  ],
  "ALERTA EM TESTE: alarme e vibração no telemóvel. Não envia automaticamente mensagens nem liga às urgências. É preciso configurar e testar um canal de alertas antes de ativar o envio real. O GPS pode falhar no ecrã bloqueado ou sem bateria/rede.": [
    "ALERTE TEST : son et vibration uniquement. Aucun message ni appel d’urgence automatique. Un service d’alerte doit être testé et le GPS peut échouer écran verrouillé ou sans réseau.",
    "ALLARME TEST: solo suono e vibrazione. Nessun messaggio o chiamata automatica. Un servizio di avviso deve essere testato. Il GPS può fallire a schermo bloccato o senza rete.",
    "ALERTA DE PRUEBA: solo sonido y vibración. Sin mensajes ni llamadas automáticas. Debe probarse un servicio de alertas. El GPS puede fallar con pantalla bloqueada o sin red.",
    "TESTALARM: nur Ton und Vibration, keine automatische Nachricht oder Notruf. Ein Benachrichtigungsdienst muss noch geprüft werden. GPS kann bei Sperrbildschirm oder Netzausfall versagen.",
    "TEST ALERT: sound and vibration only. No automatic messages or emergency calls. An alert service must be tested; GPS may fail with the screen locked or no signal."
  ],
  "Escreve pelo menos 3 letras da rua ou localidade.": [
    "Saisis au moins 3 lettres de la rue ou de la ville.",
    "Inserisci almeno 3 lettere della via o località.",
    "Escribe al menos 3 letras de la calle o localidad.",
    "Gib mindestens 3 Buchstaben der Strasse oder des Orts ein.",
    "Enter at least 3 letters of a street or town."
  ],
  "A procurar endereços suíços…": [
    "Recherche d’adresses suisses…",
    "Ricerca indirizzi svizzeri…",
    "Buscando direcciones suizas…",
    "Suche Schweizer Adressen…",
    "Searching Swiss addresses…"
  ],
  "Escolhe um endereço da lista para confirmar a localização.": [
    "Sélectionne une adresse dans la liste pour confirmer le lieu.",
    "Seleziona un indirizzo dall’elenco per confermare la posizione.",
    "Elige una dirección de la lista para confirmar la ubicación.",
    "Wähle eine Adresse aus der Liste, um den Ort zu bestätigen.",
    "Select an address from the list to confirm the location."
  ],
  "Nenhum endereço encontrado. Acrescenta a localidade ou o número da porta.": [
    "Aucune adresse trouvée. Ajoute la ville ou le numéro.",
    "Nessun indirizzo trovato. Aggiungi località o numero civico.",
    "No se encontró la dirección. Añade la localidad o el número.",
    "Keine Adresse gefunden. Ergänze Ort oder Hausnummer.",
    "No address found. Add the town or house number."
  ],
  "Pesquisa indisponível. Verifica a ligação à Internet e tenta novamente.": [
    "Recherche indisponible. Vérifie la connexion Internet et réessaie.",
    "Ricerca non disponibile. Controlla Internet e riprova.",
    "Búsqueda no disponible. Comprueba Internet e inténtalo de nuevo.",
    "Suche nicht verfügbar. Internet prüfen und erneut versuchen.",
    "Search unavailable. Check your internet connection and retry."
  ],
  "Endereço confirmado. Já podes calcular a rota.": [
    "Adresse confirmée. Tu peux calculer l’itinéraire.",
    "Indirizzo confermato. Puoi calcolare il percorso.",
    "Dirección confirmada. Ya puedes calcular la ruta.",
    "Adresse bestätigt. Du kannst die Route berechnen.",
    "Address confirmed. You can calculate the route."
  ],
  "Escolhe um endereço da lista antes de calcular a rota.": [
    "Choisis une adresse proposée avant de calculer l’itinéraire.",
    "Seleziona un indirizzo suggerito prima di calcolare il percorso.",
    "Elige una dirección sugerida antes de calcular la ruta.",
    "Wähle eine vorgeschlagene Adresse, bevor du die Route berechnest.",
    "Select a suggested address before calculating the route."
  ],
  "Estrada repetida no regresso: ": [
    "Route parcourue deux fois au retour : ",
    "Strada ripetuta al ritorno: ",
    "Carretera repetida al volver: ",
    "Auf Rückweg doppelt gefahren: ",
    "Road repeated on return: "
  ],
  "A procurar endereço…": [
    "Recherche d’adresse…",
    "Ricerca indirizzo…",
    "Buscando dirección…",
    "Suche Adresse…",
    "Looking up address…"
  ],
  "A verificar estradas dentro da Suíça…": [
    "Vérification des routes en Suisse…",
    "Verifica strade in Svizzera…",
    "Comprobando carreteras en Suiza…",
    "Prüfe Strassen in der Schweiz…",
    "Checking Swiss roads…"
  ],
  "A procurar a localidade e as estradas panorâmicas…": [
    "Recherche de villes et routes panoramiques…",
    "Ricerca località e strade panoramiche…",
    "Buscando localidades y rutas panorámicas…",
    "Suche Orte und Panoramastrassen…",
    "Finding towns and scenic roads…"
  ],
  "A criar passeio…": [
    "Création de la balade…",
    "Creazione del giro…",
    "Creando paseo…",
    "Tour wird erstellt…",
    "Creating ride…"
  ],
  "A verificar circuito suíço": [
    "Vérification du circuit suisse",
    "Verifica circuito svizzero",
    "Comprobando circuito suizo",
    "Prüfe Schweizer Rundtour",
    "Checking Swiss loop"
  ],
  "🎲 Criar outro passeio surpresa": [
    "🎲 Créer une autre balade",
    "🎲 Crea un altro giro",
    "🎲 Crear otra ruta sorpresa",
    "🎲 Neue Überraschungstour",
    "🎲 Create another surprise ride"
  ],
  "O servidor público de rotas falhou ou está a limitar os pedidos. Tenta mais tarde.": [
    "Le serveur de routage public ne répond pas ou limite les requêtes. Réessaie plus tard.",
    "Il server pubblico non risponde o limita le richieste. Riprova più tardi.",
    "El servidor público falla o limita las consultas. Inténtalo más tarde.",
    "Der öffentliche Routenserver ist nicht erreichbar oder begrenzt Anfragen. Bitte später erneut versuchen.",
    "The public routing service failed or is rate limiting. Try again later."
  ],
  "🇨🇭 As opções encontradas atravessam uma fronteira e foram recusadas. Escolhe pontos mais no interior da Suíça.": [
    "🇨🇭 Les propositions traversaient la frontière et ont été refusées. Choisis des étapes plus à l’intérieur de la Suisse.",
    "🇨🇭 Le proposte attraversavano il confine e sono state rifiutate. Scegli tappe più interne alla Svizzera.",
    "🇨🇭 Las rutas cruzaban una frontera y se rechazaron. Elige puntos más dentro de Suiza.",
    "🇨🇭 Die Vorschläge überschritten die Grenze und wurden abgelehnt. Wähle Punkte weiter im Schweizer Inland.",
    "🇨🇭 All candidate routes crossed a border and were rejected. Choose points farther inside Switzerland."
  ],
  "Os percursos encontrados repetem demasiada estrada no regresso. Experimenta outra duração ou outros pontos de passagem.": [
    "Les trajets trouvés reprennent trop souvent les mêmes routes au retour. Essaie une autre durée ou d’autres étapes.",
    "I percorsi trovati ripetono troppe strade al ritorno. Prova un’altra durata o tappe diverse.",
    "Las rutas encontradas repiten demasiado asfalto en el regreso. Prueba otra duración o etapas diferentes.",
    "Die gefundenen Rundtouren fahren zu oft auf derselben Strasse zurück. Andere Dauer oder Zwischenziele wählen.",
    "The return routes repeat too many roads. Try another duration or different waypoints."
  ],
  "Não existem pontos adequados nesta região para essa duração.": [
    "Il n’y a pas assez de points adaptés dans cette région pour cette durée.",
    "Non ci sono punti adatti in questa zona per questa durata.",
    "No hay suficientes puntos adecuados en esta zona para esa duración.",
    "Keine passenden Zwischenziele in der Region für diese Dauer.",
    "Not enough suitable waypoints nearby for that duration."
  ],
  "Podes continuar a utilizar o mapa e criar uma rota manual em Rotas.": [
    "Tu peux placer une route manuellement dans « Itinéraires ».",
    "Puoi tracciare manualmente un percorso in « Itinerari ».",
    "Puedes crear una ruta manual en « Rutas ».",
    "Du kannst unter « Routen » eine Strecke manuell erstellen.",
    "You can still build a manual route in Routes."
  ]
});
Object.assign(i18n, {
 'Rota só de ida criada:':['Itinéraire aller simple créé :','Percorso di sola andata creato:','Ruta de ida creada:','Einfache Fahrt erstellt:','One-way route created:'],
 'Confirma o destino e o percurso antes de conduzir.':['Vérifie la destination et le parcours avant de rouler.','Controlla destinazione e percorso prima di partire.','Comprueba el destino y la ruta antes de conducir.','Prüfe Ziel und Strecke vor der Fahrt.','Confirm the destination and route before riding.'],
 'Endereços: geodados oficiais da Suíça · swisstopo / geo.admin.ch. Precisa de Internet.':['Adresses : géodonnées officielles suisses · swisstopo / geo.admin.ch. Connexion Internet requise.','Indirizzi: geodati ufficiali svizzeri · swisstopo / geo.admin.ch. Connessione Internet necessaria.','Direcciones: datos geográficos oficiales suizos · swisstopo / geo.admin.ch. Necesita Internet.','Adressen: offizielle Schweizer Geodaten · swisstopo / geo.admin.ch. Internet erforderlich.','Addresses: official Swiss geodata · swisstopo / geo.admin.ch. Internet required.']
});

Object.assign(i18n, {
  "Passagens alpinas": [
    "Cols alpins",
    "Passi alpini",
    "Puertos alpinos",
    "Alpenpässe",
    "Alpine passes"
  ],
  "Aldeias e estradas secundárias": [
    "Villages et routes secondaires",
    "Borghi e strade secondarie",
    "Pueblos y carreteras secundarias",
    "Dörfer und Nebenstrassen",
    "Villages and backroads"
  ],
  "Vinhas e paisagens rurais": [
    "Vignobles et campagne",
    "Vigneti e campagna",
    "Viñedos y paisajes rurales",
    "Weinberge und Landschaften",
    "Vineyards and countryside"
  ],
  "Florestas e natureza": [
    "Forêts et nature",
    "Boschi e natura",
    "Bosques y naturaleza",
    "Wälder und Natur",
    "Forests and nature"
  ],
  "Vilas históricas e miradouros": [
    "Bourgs historiques et points de vue",
    "Borghi storici e belvedere",
    "Pueblos históricos y miradores",
    "Historische Orte und Aussichtspunkte",
    "Historic towns and viewpoints"
  ],
  "📍 Rota só de ida por endereço": [
    "📍 Itinéraire aller simple par adresse",
    "📍 Percorso di sola andata per indirizzo",
    "📍 Ruta de ida por dirección",
    "📍 Einfache Fahrt zur Adresse",
    "📍 One-way route to address"
  ],
  "Morada exata": [
    "Adresse précise",
    "Indirizzo esatto",
    "Dirección exacta",
    "Genaue Adresse",
    "Exact address"
  ],
  "A minha posição GPS": [
    "Ma position GPS",
    "La mia posizione GPS",
    "Mi ubicación GPS",
    "Mein GPS-Standort",
    "My GPS location"
  ],
  "Localidade escrita": [
    "Ville saisie",
    "Località inserita",
    "Localidad escrita",
    "Ort eingeben",
    "Enter a town"
  ],
  "Ponto selecionado no mapa": [
    "Point choisi sur la carte",
    "Punto selezionato sulla mappa",
    "Punto elegido en el mapa",
    "Punkt auf Karte gewählt",
    "Point selected on map"
  ],
  "Endereço de destino na Suíça": [
    "Adresse de destination en Suisse",
    "Indirizzo di destinazione in Svizzera",
    "Dirección de destino en Suiza",
    "Zieladresse in der Schweiz",
    "Destination address in Switzerland"
  ],
  "Calcular rota só de ida": [
    "Calculer un itinéraire aller simple",
    "Calcola percorso di sola andata",
    "Calcular ruta de ida",
    "Einfache Route berechnen",
    "Calculate one-way route"
  ],
  "Grupo": [
    "Groupe",
    "Gruppo",
    "Grupo",
    "Gruppe",
    "Group"
  ],
  "Outro cantão": [
    "Autre canton",
    "Altro cantone",
    "Otro cantón",
    "Anderer Kanton",
    "Other canton"
  ],
  "Genebra (GE)": [
    "Genève (GE)",
    "Ginevra (GE)",
    "Ginebra (GE)",
    "Genf (GE)",
    "Geneva (GE)"
  ],
  "Berna (BE)": [
    "Berne (BE)",
    "Berna (BE)",
    "Berna (BE)",
    "Bern (BE)",
    "Bern (BE)"
  ],
  "Friburgo (FR)": [
    "Fribourg (FR)",
    "Friburgo (FR)",
    "Friburgo (FR)",
    "Freiburg (FR)",
    "Fribourg (FR)"
  ],
  "Zurique (ZH)": [
    "Zurich (ZH)",
    "Zurigo (ZH)",
    "Zúrich (ZH)",
    "Zürich (ZH)",
    "Zurich (ZH)"
  ],
  "Grisões (GR)": [
    "Grisons (GR)",
    "Grigioni (GR)",
    "Grisones (GR)",
    "Graubünden (GR)",
    "Graubünden (GR)"
  ],
  "Lucerna (LU)": [
    "Lucerne (LU)",
    "Lucerna (LU)",
    "Lucerna (LU)",
    "Luzern (LU)",
    "Lucerne (LU)"
  ],
  "Valais (VS)": [
    "Valais (VS)",
    "Vallese (VS)",
    "Valais (VS)",
    "Wallis (VS)",
    "Valais (VS)"
  ],
  "Vaud (VD)": [
    "Vaud (VD)",
    "Vaud (VD)",
    "Vaud (VD)",
    "Waadt (VD)",
    "Vaud (VD)"
  ],
  "Ticino (TI)": [
    "Tessin (TI)",
    "Ticino (TI)",
    "Tesino (TI)",
    "Tessin (TI)",
    "Ticino (TI)"
  ],
  "SOS": [
    "SOS",
    "SOS",
    "SOS",
    "SOS",
    "SOS"
  ]
});

// Dynamic status text nodes are recreated by the planner; translate those as they appear.
let pending=false;
const app=document.querySelector('.app');
if(app){new MutationObserver(()=>{
 if(pending)return;
 pending=true;
 queueMicrotask(()=>{pending=false;translatePage();});
}).observe(app,{subtree:true,childList:true,characterData:true});}
translatePage();
})();
