/* Swiss official address suggestions for rider navigation.
   Source: Swiss federal geo.admin.ch SearchServer, origin=address.
   A user must pick an explicit result; we never guess GPS coordinates from raw text.
*/
(function (root) {
  'use strict';
  function safeLabel(raw) {
    // Keep plain text. Never inject the third-party label as HTML.
    return String(raw || '').replace(/<[^>]*>/g, ' ').replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&').replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'").replace(/\s+/g, ' ').trim().slice(0, 180);
  }
  function parseAddressRows(json) {
    const list = Array.isArray(json?.results) ? json.results : [];
    const used = new Set(), choices = [];
    for (const result of list) {
      const p = result?.attrs || {};
      if (p.origin !== 'address') continue;
      const lat = Number(p.lat), lon = Number(p.lon);
      if (!Number.isFinite(lat) || !Number.isFinite(lon) ||
          lat < 45.7 || lat > 47.9 || lon < 5.8 || lon > 10.7) continue;
      const label = safeLabel(p.label);
      if (!label || used.has(label.toLowerCase())) continue;
      // Address origin identifies an actual address in the official Swiss catalogue.
      used.add(label.toLowerCase());
      choices.push({label, coord:[lat,lon], featureId:String(p.featureId || result.id || '')});
    }
    return choices.slice(0, 8);
  }
  async function search(query, options={}) {
    const text=String(query||'').trim().slice(0,110);
    if(text.length < 3) return [];
    const url = 'https://api3.geo.admin.ch/rest/services/ech/SearchServer?'
      + new URLSearchParams({searchText:text, type:'locations', origins:'address', limit:'8'});
    const response=await fetch(url,{signal:options.signal,headers:{Accept:'application/json'}});
    if(!response.ok)throw Error('swiss_address_search_unavailable');
    return parseAddressRows(await response.json());
  }
  root.SwissAddressSearch={search,parseAddressRows,safeLabel};
})(typeof window !== 'undefined' ? window : globalThis);
