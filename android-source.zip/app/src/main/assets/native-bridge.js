/* AlpRiders CH Android bridge: preserve existing features, route state, and language. */
(function () {
  'use strict';
  if (!window.AndroidBridge || window.__alpBridgeReady) return;
  window.__alpBridgeReady = true;
  // Native bottom navigation owns the five tabs.
  const oldNav = document.querySelector('.nav');
  if (oldNav) oldNav.style.display = 'none';
  const header = document.querySelector('.header');
  if (header) header.style.display = 'none';
  const a = document.querySelector('.app');
  if (a) a.style.paddingBottom = '15px';
  // Make the complete existing route planner available in the Routes tab.
  const planner = document.querySelector('#auto-planner');
  const routePage = document.querySelector('#view-routes');
  if (planner && routePage) routePage.insertBefore(planner, routePage.children[1]);
  // Hide broken leaflet map inside the embedded HTML. MapLibre is native.
  const style = document.createElement('style');
  style.textContent = '.mapbox,#route-creator,#nav-guide,#gps-one-card,#nav-actions{display:none!important}' +
    'body{background:#0c1722!important}.screen{padding-top:8px!important}' +
    '#auto-planner{margin-top:14px}';
  document.head.appendChild(style);
  const originalTab = window.tab;
  window.tab = function (t) {
    originalTab(t);
    if (t === 'map') window.AndroidBridge.openMap();
  };
  const originalDraw = window.draw;
  window.draw = function () {
    originalDraw();
    try { window.AndroidBridge.onRouteChange(JSON.stringify({points: points, road: road})); } catch(e){}
  };
  const pinButton = document.getElementById('choose-pin');
  if (pinButton) pinButton.onclick = function () { window.AndroidBridge.chooseStartPin(); };
  const pick = document.querySelector('#language-picker');
  if (pick) pick.addEventListener('change', function () {window.AndroidBridge.languageChanged(pick.value)});
  // Web planner is the authoritative place for saved routes.
  // Android file picker handles GPX reliably (WebView cannot download blob: URLs by itself).
  const originalDownload = window.downloadGpx;
  window.downloadGpx = function (coords, name, roadData) {
    const coordinates=(roadData && roadData.geometry && roadData.geometry.length)?roadData.geometry:coords;
    window.AndroidBridge.exportGPX(String(name || 'AlpRiders CH'),JSON.stringify(coordinates));
  };
  window.AlpNative = {
    show: function (t) { originalTab(t); },
    planner: function () {
      originalTab('routes');
      setTimeout(function () {document.querySelector('#auto-planner')?.scrollIntoView({block:'start'});}, 90);
    },
    save: function () { document.querySelector('#save-route')?.click(); },
    calculate: function () { if (typeof calculate === 'function') calculate(); },
    clear: function () { if (typeof clearRoute === 'function') clearRoute(); },
    addPoint: function (lat, lon) {
      if (points.length >= 12) {toast('Máximo de 12 pontos por percurso.');return;}
      points.push([lat, lon]);road=null;draw();
    },
    useGPS: function (lat,lon) {
      points=[[lat,lon]];road=null;draw();
    },
    selectPin: function(lat,lon) {
      selectedPin=[lat,lon];
      const el=document.querySelector('#pin-status');
      if(el)el.textContent='Partida: '+lat.toFixed(5)+', '+lon.toFixed(5);
      document.querySelector('#start-mode').value='pin';
      changeStartMode();
    },
    language: function (code) {
      if (document.querySelector('#language-picker')) {
        document.querySelector('#language-picker').value=code;
        document.querySelector('#language-picker').dispatchEvent(new Event('change'));
      }
    },
    sync: function () {
      window.AndroidBridge.onRouteChange(JSON.stringify({points:points,road:road}));
    }
  };
  window.AlpNative.sync();
})();
