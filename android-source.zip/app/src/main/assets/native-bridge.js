/* AlpRiders CH Android bridge: preserve existing features, route state, and language. */
(function () {
  'use strict';
  if (!window.AndroidBridge || window.__alpBridgeReady) return;
  window.__alpBridgeReady = true;
  // Native bottom navigation owns the five tabs.
  const oldNav = document.querySelector('.nav');
  if (oldNav) oldNav.style.display = 'none';
  const header = document.querySelector('.header');
  if (header) header.style.display = 'none';
  const a = document.querySelector('.app');
  if (a) a.style.paddingBottom = '15px';
  // Make the complete existing route planner available in the Routes tab.
  const planner = document.querySelector('#auto-planner');
  const routePage = document.querySelector('#view-routes');
  if (planner && routePage) routePage.insertBefore(planner, routePage.children[1]);
  // Hide broken leaflet map inside the embedded HTML. MapLibre is native.
  const style = document.createElement('style');
  style.textContent = '.mapbox,#route-creator,#nav-guide,#gps-one-card,#nav-actions{display:none!important}' +
    'body{background:#0c1722!important}.screen{padding-top:8px!important}' +
    '#auto-planner{margin-top:14px}';
  document.head.appendChild(style);
  const originalTab = window.tab;
  window.tab = function (t) {
    originalTab(t);
    if (t === 'map') window.AndroidBridge.openMap();
  };
  const originalDraw = window.draw;
  window.draw = function () {
    originalDraw();
    try { window.AndroidBridge.onRouteChange(JSON.stringify({points: points, road: road})); } catch(e){}
  };
  const pinButton = document.getElementById('choose-pin');
  if (pinButton) pinButton.onclick = function () { window.AndroidBridge.chooseStartPin(); };
  const pick = document.querySelector('#language-picker');
  if (pick) pick.addEventListener('change', function () {window.AndroidBridge.languageChanged(pick.value);translateSafety(pick.value)});
  // Web planner is the authoritative place for saved routes.
  // Android file picker handles GPX reliably (WebView cannot download blob: URLs by itself).
  const originalDownload = window.downloadGpx;
  window.downloadGpx = function (coords, name, roadData) {
    const coordinates=(roadData && roadData.geometry && roadData.geometry.length)?roadData.geometry:coords;
    window.AndroidBridge.exportGPX(String(name || 'AlpRiders CH'),JSON.stringify(coordinates));
  };
  let nextRequest = 1;
  const waitingForLocation = new Map();
  function nativeLocation() {
    return new Promise(function(resolve,reject) {
      const id=nextRequest++;
      const deadline=setTimeout(function(){
        if (!waitingForLocation.has(id)) return;
        waitingForLocation.delete(id);
        reject(new Error('GPS timeout'));
      },20000);
      waitingForLocation.set(id, {resolve,reject,deadline});
      try {window.AndroidBridge.requestLocation(id)}
      catch(e) {clearTimeout(deadline);waitingForLocation.delete(id);reject(e)}
    });
  }
  // Original inline JavaScript used browser geolocation. The APK uses Android's
  // runtime location permissions and fresh LocationManager fixes instead.
  window.locateNow = async function() {
    const pos=await nativeLocation().catch(function() {throw new Error('gps')});
    if (typeof onPosition === 'function') onPosition(pos);
    return pos;
  };
  const installButton = document.querySelector('#install-btn');
  if (installButton) installButton.closest('.card')?.setAttribute('hidden', '');
  const sosCopy=document.querySelector('#sos-copy');
  if(sosCopy) sosCopy.onclick=function() {
    const message=typeof positionMessage==='function'?positionMessage():'';
    if(!message){toast('Atualiza primeiro o GPS.');return;}
    window.AndroidBridge.copyText(message);
  };
  const sosShare=document.querySelector('#sos-share');
  if(sosShare) sosShare.onclick=function() {
    const message=typeof positionMessage==='function'?positionMessage():'';
    if(!message){toast('Atualiza primeiro o GPS.');return;}
    window.AndroidBridge.shareText(message);
  };
  // Six-language labels for the new test panel; native safety notifications use PT in beta.
  const safetyStrings = {
    pt: ['🛡️ Monitor de segurança — TESTE','Durante um passeio, acompanha o GPS. Após 45 s em movimento, pode alertar se estiveres parado durante 20 min ou após um movimento brusco seguido de paragem. Não é deteção fiável de acidentes.','Ativar monitor automático','Parar monitor','Testar alarme 60 s','Estou bem · cancelar','MODO TESTE: alarme local. Não envia mensagens nem telefona automaticamente.'],
    fr: ['🛡️ Surveillance de sécurité — TEST','Pendant une balade, le GPS reste suivi. Après 45 s de mouvement, alerte possible après 20 min immobile ou après un choc suivi d’un arrêt. Ce n’est pas une détection fiable d’accident.','Activer surveillance auto','Arrêter','Tester 60 s','Tout va bien · annuler','MODE TEST : alarme local, sans message ni appel automatique.'],
    it: ['🛡️ Monitoraggio sicurezza — TEST','Durante un giro, segue il GPS. Dopo 45 s di movimento, possibile avviso se fermi 20 min o dopo un urto seguito da arresto. Non rileva gli incidenti in modo affidabile.','Attiva monitor automatico','Arresta','Prova allarme 60 s','Sto bene · annulla','MODALITÀ TEST: solo allarme locale, senza messaggi né chiamate automatiche.'],
    es: ['🛡️ Monitor de seguridad — PRUEBA','Durante una ruta, sigue el GPS. Después de 45 s en movimiento, puede avisar tras 20 min parado o un impacto seguido de parada. No detecta accidentes de forma fiable.','Activar monitor automático','Detener monitor','Probar alarma 60 s','Estoy bien · cancelar','MODO PRUEBA: alarma local, sin mensajes ni llamadas automáticas.'],
    de: ['🛡️ Sicherheitsmonitor — TEST','Während der Fahrt wird GPS verfolgt. Nach 45 s Fahrt kann nach 20 min Stillstand oder nach einem starken Stoß mit Stopp ein Alarm erscheinen. Keine zuverlässige Unfallerkennung.','Automatisch aktivieren','Monitor stoppen','Alarm 60 s testen','Mir geht es gut · abbrechen','TESTMODUS: nur lokaler Alarm, keine automatischen Nachrichten oder Anrufe.'],
    en: ['🛡️ Safety monitor — TEST','During a ride, GPS is monitored. After 45 s moving, it can warn after 20 min stationary or an impact followed by stopping. This is not reliable crash detection.','Enable automatic monitor','Stop monitor','Test 60 s alarm','I am OK · cancel','TEST MODE: local alarm only. No automatic messages or emergency calls.']
  };
  function translateSafety(code) {
    const text = safetyStrings[code] || safetyStrings.pt;
    ['title','intro','start','stop','test','cancel','warning'].forEach(function(key,i) {
      const el=document.querySelector('[data-safety="'+key+'"]');
      if(el) el.textContent=text[i];
    });
  }
  translateSafety(document.querySelector('#language-picker')?.value || 'pt');
  const safetyActions = [
    ['safety-start','startSafetyMonitor'],
    ['safety-stop','stopSafetyMonitor'],
    ['safety-test','testSafetyAlarm'],
    ['safety-cancel','cancelSafetyAlarm']
  ];
  safetyActions.forEach(function(item){
    const el=document.getElementById(item[0]);
    if(el) el.onclick=function(){window.AndroidBridge[item[1]]();};
  });
  window.AlpNative = {
    safetyStatus: function(message) {
      const el=document.getElementById('safety-status');
      if(el) el.textContent=message;
    },
    nativeLocationResult: function(id,pos) {
      const req=waitingForLocation.get(id);if(!req)return;
      clearTimeout(req.deadline);waitingForLocation.delete(id);req.resolve(pos);
    },
    nativeLocationError: function(id,error) {
      const req=waitingForLocation.get(id);if(!req)return;
      clearTimeout(req.deadline);waitingForLocation.delete(id);
      req.reject(new Error(error||'GPS indisponível'));
    },
    show: function (t) { originalTab(t); },
    planner: function () {
      originalTab('routes');
      setTimeout(function () {document.querySelector('#auto-planner')?.scrollIntoView({block:'start'});}, 90);
    },
    save: function () { document.querySelector('#save-route')?.click(); },
    calculate: function () { if (typeof calculate === 'function') calculate(); },
    clear: function () { if (typeof clearRoute === 'function') clearRoute(); },
    addPoint: function (lat, lon) {
      const loop=AlpRideUtils.isClosed(points);
      if (points.length >= 12) {toast('Máximo de 12 pontos por percurso.');return;}
      if(loop)points.splice(points.length-1,0,[lat,lon]);
      else points.push([lat,lon]);
      road=null;draw();
    },
    useGPS: function (lat,lon) {
      points=[[lat,lon]];road=null;draw();
    },
    selectPin: function(lat,lon) {
      selectedPin=[lat,lon];
      const el=document.querySelector('#pin-status');
      if(el)el.textContent='Partida: '+lat.toFixed(5)+', '+lon.toFixed(5);
      document.querySelector('#start-mode').value='pin';
      changeStartMode();
    },
    language: function (code) {
      if (document.querySelector('#language-picker')) {
        document.querySelector('#language-picker').value=code;
        document.querySelector('#language-picker').dispatchEvent(new Event('change'));
      }
    },
    sync: function () {
      window.AndroidBridge.onRouteChange(JSON.stringify({points:points,road:road}));
    }
  };
  window.AlpNative.sync();
})();
