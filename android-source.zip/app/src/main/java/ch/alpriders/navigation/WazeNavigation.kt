package ch.alpriders.navigation

import java.util.Locale
import kotlin.math.abs

/** Official Waze Deep Links: one destination per launch, NOT a multi-stop itinerary. */
internal object WazeNavigation {
    internal data class Stop(val stage:Int,val latitude:Double,val longitude:Double,val isFinal:Boolean,val isReturn:Boolean)

    private fun near(a:Pair<Double,Double>,b:Pair<Double,Double>):Boolean =
        abs(a.first-b.first)<0.0001 && abs(a.second-b.second)<0.0001

    fun destinations(points:List<Pair<Double,Double>>):List<Stop> {
        if(points.size<2)return emptyList()
        val loop=points.size>=3 && near(points.first(),points.last())
        // Use all intermediate points; do NOT navigate directly home for a round trip.
        return points.drop(1).mapIndexed { index,p ->
            Stop(index+1,p.first,p.second,index==points.size-2,loop && index==points.size-2)
        }
    }

    fun link(latitude:Double,longitude:Double):String? {
        if(!latitude.isFinite() || !longitude.isFinite() || latitude !in -90.0..90.0 || longitude !in -180.0..180.0)return null
        val loc=String.format(Locale.US,"%.6f%%2C%.6f",latitude,longitude)
        return "https://waze.com/ul?ll=$loc&navigate=yes&vehicle_type=motorcycle&utm_source=alpriders_ch"
    }
}
