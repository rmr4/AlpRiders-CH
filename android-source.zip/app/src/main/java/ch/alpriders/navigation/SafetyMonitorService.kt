package ch.alpriders.navigation

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.*
import androidx.annotation.RequiresApi

/** TEST MODE ONLY: monitors a ride; NEVER sends a message or calls emergency services. */
class SafetyMonitorService : Service(), LocationListener, SensorEventListener {
    companion object {
        const val ACTION_START = "ch.alpriders.safety.START"
        const val ACTION_STOP = "ch.alpriders.safety.STOP"
        const val ACTION_CANCEL = "ch.alpriders.safety.CANCEL"
        const val ACTION_TEST = "ch.alpriders.safety.TEST"
        const val ACTION_HELP = "ch.alpriders.safety.HELP"
        private const val CHANNEL = "alpriders_safety_v07"
        private const val ID = 20507
        var observer: ((String) -> Unit)? = null
        var summary: String = "Parado — iniciar durante um passeio."
            private set
    }
    private val handler = Handler(Looper.getMainLooper())
    private val logic = SafetyLogic()
    private var locationManager: LocationManager? = null
    private var sensorManager: SensorManager? = null
    private var latestFix: SafetyLogic.Fix? = null
    private var alarmUntil: Long = 0L
    private var alarmType = ""
    private var ringtone: Ringtone? = null
    private var active = false
    private var lastImpactAt: Long = 0L
    private val clock get() = SystemClock.elapsedRealtime()
    private val tick = object : Runnable {
        override fun run() {
            if (!active) return
            if (alarmUntil > 0L) {
                val seconds = ((alarmUntil - clock + 999L) / 1000L).coerceAtLeast(0L)
                if (seconds > 0) change("ALERTA DE TESTE: $alarmType · $seconds s para responder")
                else {
                    alarmUntil = 0; stopRing()
                    change("Possível incidente sem resposta. ALERTA EXTERNO DESATIVADO. Usa SOS manual.")
                }
            } else if (!logic.validGps(clock, latestFix)) {
                change("GPS sem posição recente. Monitorização não fiável — não há deteção neste momento.")
            } else if (logic.armed && !logic.alerted) {
                change("A acompanhar passeio (GPS ativo). Alerta após 20 min imobilizado.")
            } else if (!logic.alerted) change("A acompanhar GPS. É preciso conduzir 45 s para armar o monitor.")
            handler.postDelayed(this, 1_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel(CHANNEL, "AlpRiders — Monitor de segurança TESTE", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Monitor GPS e alertas locais; não envia pedidos de ajuda automaticamente."
            enableVibration(true)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
    override fun onBind(intent: Intent?) = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {stopMonitor(); return START_NOT_STICKY}
            ACTION_CANCEL -> {cancelAlarm(); return START_STICKY}
            ACTION_HELP -> { stopRing(); alarmUntil=0; change("Abre SOS e contacta os teus contactos ou 112/144 manualmente."); openSos(); return START_STICKY }
            ACTION_TEST -> { if (active) startAlarm("simulação manual") else change("Inicia primeiro o monitor para testar o alarme."); return START_NOT_STICKY }
            ACTION_START -> if (!active) startMonitor()
        }
        return START_NOT_STICKY // Don't restart unprompted after Android kills app.
    }
    private fun startMonitor() {
        val granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) {change("Autoriza a localização precisa para iniciar o monitor."); stopSelf();return}
        try {
            // A foreground location service is permitted only after the user starts it visibly.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(ID, notification("Monitor de segurança TESTE — em início"), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            } else startForeground(ID, notification("Monitor de segurança TESTE — em início"))
        } catch (e: Exception) {
            change("Falha ao iniciar monitor: ${e.javaClass.simpleName}")
            stopSelf();return
        }
        // Always request location via standard provider API rather than hidden browser location.
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            locationManager=lm
            var subscribed=false
            for (name in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.isProviderEnabled(name)) {lm.requestLocationUpdates(name,4_000L,5f,this,Looper.getMainLooper());subscribed=true}
            }
            if (!subscribed) throw IllegalStateException("Sem serviço de localização ativo")
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {sensorManager?.registerListener(this,it,SensorManager.SENSOR_DELAY_NORMAL)}
            active = true; logic.reset();handler.post(tick)
            change("Monitor em teste iniciado. Nenhuma mensagem é enviada automaticamente.")
        } catch (e: Exception) {
            change("Não foi possível iniciar monitor: ${e.javaClass.simpleName}");stopMonitor()
        }
    }
    private fun stopMonitor() {
        active=false;handler.removeCallbacks(tick);stopRing();alarmUntil=0
        locationManager?.removeUpdates(this);sensorManager?.unregisterListener(this)
        change("Monitor de segurança parado.")
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()
    }
    override fun onLocationChanged(location: Location) {
        val now=clock
        if(location.elapsedRealtimeNanos/1_000_000L < now-30_000L)return
        val fix=SafetyLogic.Fix(location.latitude,location.longitude,
            if(location.hasSpeed())location.speed.toDouble() else 0.0,
            location.accuracy, now)
        latestFix=fix
        val reason=logic.location(fix)
        if(reason!=null) startAlarm(if(reason==SafetyLogic.Reason.POSSIBLE_IMPACT)"movimento brusco e paragem" else "20 min sem movimento")
    }
    override fun onSensorChanged(event: SensorEvent?) {
        if (!active || event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER || event.values.size < 3) return
        val m = kotlin.math.sqrt(event.values[0]*event.values[0] + event.values[1]*event.values[1] + event.values[2]*event.values[2])
        if (m > 44.0f && logic.armed && clock-lastImpactAt>180_000L) {lastImpactAt=clock;logic.impact(clock)}
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    private fun startAlarm(type:String) {
        if(!active || alarmUntil>0L)return
        alarmType=type;alarmUntil=clock+60_000L
        try {
            ringtone=RingtoneManager.getRingtone(this,RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            ringtone?.play()
            @Suppress("DEPRECATION") val vib=getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if(vib.hasVibrator())vib.vibrate(VibrationEffect.createOneShot(900,VibrationEffect.DEFAULT_AMPLITUDE))
        }catch(_:Exception){}
        change("ALERTA DE TESTE: $type · 60 s para responder")
    }
    private fun cancelAlarm() {stopRing();alarmUntil=0L;logic.reset();change("Estou bem — alerta cancelado. Para rearmar, continua a viagem com GPS.")}
    private fun stopRing(){try{ringtone?.stop()}catch (_:Exception){};ringtone=null}
    private fun openSos() {
        val it=Intent(this,MainActivity::class.java).apply {flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP;putExtra("open_sos",true)}
        startActivity(it)
    }
    private fun pendingAction(action:String):PendingIntent=PendingIntent.getService(this, action.hashCode(),Intent(this,SafetyMonitorService::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun notification(message:String): Notification {
        val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("open_sos",true),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("AlpRiders CH — segurança TESTE")
            .setContentText(message).setStyle(Notification.BigTextStyle().bigText(message))
            .setContentIntent(open).setOngoing(active).setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(null,"Estou bem",pendingAction(ACTION_CANCEL)).build())
            .addAction(Notification.Action.Builder(null,"Abrir SOS",open).build())
            .build()
    }
    private fun change(message:String) {
        if(summary==message)return
        summary=message;observer?.invoke(message)
        if(active) getSystemService(NotificationManager::class.java).notify(ID,notification(message))
    }
    override fun onDestroy() {active=false;handler.removeCallbacks(tick);stopRing();locationManager?.removeUpdates(this);sensorManager?.unregisterListener(this);observer=null;super.onDestroy()}
}
