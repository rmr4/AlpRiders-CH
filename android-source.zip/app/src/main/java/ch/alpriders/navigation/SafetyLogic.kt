package ch.alpriders.navigation

import kotlin.math.*

/**
 * Conservative heuristic for a TEST safety monitor, not crash recognition.
 * Pure Kotlin so simulations can be run without an Android device.
 * All timestamps must be monotonic elapsedRealtime milliseconds.
 */
class SafetyLogic {
    companion object {
        const val STILL_TIME_MS = 20 * 60 * 1000L
        const val ARM_TIME_MS = 45_000L
        const val GPS_MAX_AGE_MS = 30_000L
        const val IMPACT_WAIT_MS = 75_000L
    }
    data class Fix(val lat: Double, val lon: Double, val speedMps: Double, val accuracyM: Float, val timeMs: Long)
    enum class Reason { STILL_20_MIN, POSSIBLE_IMPACT }
    private var movingSinceMs: Long? = null
    private var lastProgress: Fix? = null
    private var stillSinceMs: Long? = null
    private var impactAtMs: Long? = null
    var armed: Boolean = false
        private set
    var alerted: Boolean = false
        private set

    fun reset() {
        movingSinceMs = null; lastProgress = null; stillSinceMs = null
        impactAtMs = null; armed = false; alerted = false
    }

    fun impact(nowMs: Long) {
        if (armed && !alerted) impactAtMs = nowMs
    }

    /** Accept only reasonably accurate, newly received positions. */
    fun location(fix: Fix): Reason? {
        if (alerted || fix.accuracyM !in 0f..40f || !fix.lat.isFinite() || !fix.lon.isFinite()) return null
        val fastEnough = fix.speedMps.isFinite() && fix.speedMps >= 2.2
        if (!armed) {
            if (fastEnough) {
                if (movingSinceMs == null) movingSinceMs = fix.timeMs
                if (fix.timeMs - movingSinceMs!! >= ARM_TIME_MS) {
                    armed = true; lastProgress = fix; stillSinceMs = null
                }
            } else movingSinceMs = null
            return null
        }
        if (fastEnough || distanceMeters(lastProgress, fix) > 75.0) {
            lastProgress = fix; stillSinceMs = null
        } else if (stillSinceMs == null) {
            stillSinceMs = fix.timeMs
        }
        val impact=impactAtMs
        if (impact != null && fix.timeMs - impact >= IMPACT_WAIT_MS &&
            fix.timeMs - impact <= 180_000L && !fastEnough) {
            alerted = true
            return Reason.POSSIBLE_IMPACT
        }
        if (impact != null && fix.timeMs - impact > 180_000L) impactAtMs = null
        if (stillSinceMs != null && fix.timeMs - stillSinceMs!! >= STILL_TIME_MS) {
            alerted = true
            return Reason.STILL_20_MIN
        }
        return null
    }

    fun validGps(nowMs: Long, latest: Fix?): Boolean = latest != null && nowMs - latest.timeMs <= GPS_MAX_AGE_MS

    private fun distanceMeters(a: Fix?, b: Fix): Double {
        if (a == null) return Double.POSITIVE_INFINITY
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.lat)) *
            cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 12742000.0 * asin(sqrt(h.coerceIn(0.0, 1.0)))
    }
}
