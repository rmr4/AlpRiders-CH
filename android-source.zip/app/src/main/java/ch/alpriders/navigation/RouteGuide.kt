package ch.alpriders.navigation

import kotlin.math.*

/** Approximate map matching to a precomputed road geometry. Not a substitute for road-aware routing. */
internal object RouteGuide {
    data class Point(val latitude:Double,val longitude:Double)
    data class Position(val alongMeters:Double,val remainingMeters:Double,val offRouteMeters:Double)
    data class Turn(val p:Point,val type:String,val modifier:String,val street:String,val alongMeters:Double=0.0)
    private const val EARTH=6371000.0
    fun metres(a:Point,b:Point):Double {
        val rad=Math.PI/180.0
        val dp=(b.latitude-a.latitude)*rad
        val dl=(b.longitude-a.longitude)*rad
        val x=sin(dp/2).pow(2.0)+cos(a.latitude*rad)*cos(b.latitude*rad)*sin(dl/2).pow(2.0)
        return 2*EARTH*asin(min(1.0,sqrt(x)))
    }
    fun progress(path:List<Point>,gps:Point,minAlongMeters:Double=0.0):Position? {
        if(path.size<2)return null
        var total=0.0
        var best=Double.MAX_VALUE
        var bestAlong=0.0
        for(i in 0 until path.size-1){
            val a=path[i];val b=path[i+1];val length=metres(a,b)
            if(length<.01)continue
            val latScale=111195.0
            val lonScale=latScale*cos(Math.toRadians((a.latitude+b.latitude)/2.0))
            val dx=(b.longitude-a.longitude)*lonScale
            val dy=(b.latitude-a.latitude)*latScale
            val vx=(gps.longitude-a.longitude)*lonScale
            val vy=(gps.latitude-a.latitude)*latScale
            val t=((vx*dx+vy*dy)/(dx*dx+dy*dy)).coerceIn(0.0,1.0)
            val distance=hypot(vx-dx*t,vy-dy*t)
            val along=total+length*t
            // On circular routes, prevent snapping back to an earlier visit
            // to the same junction. Allow 35 m GPS jitter backwards.
            if(along>=minAlongMeters-35.0 && distance<best){best=distance;bestAlong=along}
            total+=length
        }
        if(best==Double.MAX_VALUE)return null
        return Position(bestAlong,(total-bestAlong).coerceAtLeast(0.0),best)
    }
    fun upcoming(turns:List<Turn>,distance:Double):Turn? = turns.firstOrNull {
        it.alongMeters >= distance+15.0 && it.type !in listOf("depart","arrive","notification")
    }
    fun instruction(turn:Turn):String {
        val action=when(turn.type){
            "roundabout","rotary"->"Na rotunda, segue a saída indicada"
            "merge"->"Entra na estrada"
            "on ramp"->"Segue pela rampa de acesso"
            "off ramp"->"Sai pela rampa"
            "fork"->"Mantém-te na via indicada"
            else->when(turn.modifier){
                "right","slight right","sharp right"->"Vira à direita"
                "left","slight left","sharp left"->"Vira à esquerda"
                "uturn"->"Faz inversão de marcha, se permitido"
                "straight"->"Segue em frente"
                else->"Segue a próxima indicação"
            }
        }
        return if(turn.street.isNotBlank())"$action para ${turn.street}" else action
    }
}
