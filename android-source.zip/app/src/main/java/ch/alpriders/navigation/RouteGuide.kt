package ch.alpriders.navigation

import kotlin.math.*

/** Approximate map matching to a precomputed road geometry. Not a substitute for road-aware routing. */
internal object RouteGuide {
    data class Point(val latitude:Double,val longitude:Double)
    data class Position(val alongMeters:Double,val remainingMeters:Double,val offRouteMeters:Double)
    data class Turn(val p:Point,val type:String,val modifier:String,val street:String,val alongMeters:Double=0.0)
    private const val EARTH=6371000.0
    fun metres(a:Point,b:Point):Double {
        val rad=Math.PI/180.0
        val dp=(b.latitude-a.latitude)*rad
        val dl=(b.longitude-a.longitude)*rad
        val x=sin(dp/2).pow(2.0)+cos(a.latitude*rad)*cos(b.latitude*rad)*sin(dl/2).pow(2.0)
        return 2*EARTH*asin(min(1.0,sqrt(x)))
    }
    fun progress(path:List<Point>,gps:Point,minAlongMeters:Double=0.0):Position? {
        if(path.size<2)return null
        var total=0.0
        var best=Double.MAX_VALUE
        var bestAlong=0.0
        for(i in 0 until path.size-1){
            val a=path[i];val b=path[i+1];val length=metres(a,b)
            if(length<.01)continue
            val latScale=111195.0
            val lonScale=latScale*cos(Math.toRadians((a.latitude+b.latitude)/2.0))
            val dx=(b.longitude-a.longitude)*lonScale
            val dy=(b.latitude-a.latitude)*latScale
            val vx=(gps.longitude-a.longitude)*lonScale
            val vy=(gps.latitude-a.latitude)*latScale
            val t=((vx*dx+vy*dy)/(dx*dx+dy*dy)).coerceIn(0.0,1.0)
            val distance=hypot(vx-dx*t,vy-dy*t)
            val along=total+length*t
            // On circular routes, prevent snapping back to an earlier visit
            // to the same junction. Allow 35 m GPS jitter backwards.
            if(along>=minAlongMeters-35.0 && distance<best){best=distance;bestAlong=along}
            total+=length
        }
        if(best==Double.MAX_VALUE)return null
        return Position(bestAlong,(total-bestAlong).coerceAtLeast(0.0),best)
    }
    fun upcoming(turns:List<Turn>,distance:Double):Turn? = turns.firstOrNull {
        it.alongMeters >= distance+15.0 && it.type !in listOf("depart","arrive","notification")
    }
    fun instruction(turn:Turn, language:String="pt"):String {
        val code=if(language in listOf("pt","fr","it","es","de","en"))language else "pt"
        val action=when(turn.type){
            "roundabout","rotary" -> words(code,"Na rotunda, segue a saída indicada","Au rond-point, prenez la sortie indiquée","Alla rotonda prendi l’uscita indicata","En la rotonda toma la salida indicada","Im Kreisverkehr die angezeigte Ausfahrt nehmen","At the roundabout take the indicated exit")
            "merge" -> words(code,"Entra na estrada","Rejoignez la route","Immettiti sulla strada","Incorpórate a la carretera","Auf die Straße einfädeln","Merge onto the road")
            "on ramp" -> words(code,"Segue pela rampa de acesso","Prenez la bretelle d’accès","Prendi la rampa di accesso","Toma la vía de acceso","Auf die Auffahrt fahren","Take the entrance ramp")
            "off ramp" -> words(code,"Sai pela rampa","Prenez la sortie","Prendi l’uscita","Toma la salida","Die Ausfahrt nehmen","Take the exit")
            "fork" -> words(code,"Mantém-te na via indicada","Restez dans la voie indiquée","Rimani sulla corsia indicata","Mantente en el carril indicado","Auf der angezeigten Fahrspur bleiben","Keep to the indicated lane")
            else -> when(turn.modifier){
                "right","slight right","sharp right" -> words(code,"Vira à direita","Tournez à droite","Svolta a destra","Gira a la derecha","Rechts abbiegen","Turn right")
                "left","slight left","sharp left" -> words(code,"Vira à esquerda","Tournez à gauche","Svolta a sinistra","Gira a la izquierda","Links abbiegen","Turn left")
                "uturn" -> words(code,"Faz inversão de marcha, se permitido","Faites demi-tour si autorisé","Fai inversione se consentito","Da la vuelta si está permitido","Falls erlaubt, wenden","Make a U-turn if permitted")
                "straight" -> words(code,"Segue em frente","Continuez tout droit","Prosegui dritto","Sigue recto","Geradeaus weiterfahren","Continue straight")
                else -> words(code,"Segue a próxima indicação","Suivez la prochaine indication","Segui la prossima indicazione","Sigue la siguiente indicación","Der nächsten Anweisung folgen","Follow the next instruction")
            }
        }
        val street=turn.street.trim()
        if(street.isBlank())return action
        val connector=words(code," para "," vers "," verso "," hacia "," auf "," onto ")
        return action+connector+street
    }
    private fun words(lang:String,pt:String,fr:String,it:String,es:String,de:String,en:String)=when(lang){
        "fr"->fr;"it"->it;"es"->es;"de"->de;"en"->en;else->pt
    }

}
