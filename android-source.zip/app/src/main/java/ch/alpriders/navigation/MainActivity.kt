package ch.alpriders.navigation

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.annotations.PolylineOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap
import java.io.OutputStreamWriter
import java.util.Locale

/**
 * AlpRiders CH 0.2 – first integrated Android test.
 * Native vector map + GPS; routes, planner, groups, SOS, profile and six languages
 * retained from the existing AlpRiders web prototype via an internal secure WebView.
 * NO turn-by-turn certified motorcycle navigation, background tracking or crash detection.
 */
class MainActivity : Activity(), LocationListener {
    private val dark = Color.rgb(12, 27, 40)
    private val orange = Color.rgb(250, 139, 66)
    private val muted = Color.rgb(178, 205, 213)
    private val teal = Color.rgb(82, 209, 207)
    private val prefs by lazy { getSharedPreferences("alpriders_native", Context.MODE_PRIVATE) }
    private var lang = "pt"
    private var currentTab = "map"
    private lateinit var mapView: MapView
    private var map: MapLibreMap? = null
    private var gpsMarker: Marker? = null
    private var mapReady = false
    private var following = false
    private var lastLocation: Location? = null
    private var locationManager: LocationManager? = null
    private var addingPoint = false
    private var selectingStart = false
    private var webReady = false
    private var currentRoute: List<LatLng> = emptyList()
    private var routePoints: List<LatLng> = emptyList()
    private var routeSummary = ""
    private lateinit var mapHolder: FrameLayout
    private lateinit var contentHolder: FrameLayout
    private lateinit var root: LinearLayout
    private lateinit var web: WebView
    private lateinit var subtitle: TextView
    private lateinit var speed: TextView
    private lateinit var languageButton: TextView
    private lateinit var mapGpsButton: TextView
    private lateinit var actionRow: LinearLayout
    private lateinit var bottom: LinearLayout
    private var webGeoCallback: GeolocationPermissions.Callback? = null
    private var webGeoOrigin: String? = null
    private var gpxPending: String? = null
    private val requestGps = 51
    private val requestExport = 63

    private val localeNames = arrayOf("Português", "Français", "Italiano", "Español", "Deutsch", "English")
    private val localeCodes = arrayOf("pt", "fr", "it", "es", "de", "en")
    private val tabKeys = arrayOf("map", "routes", "chat", "profile", "sos")
    private val tabSymbols = arrayOf("🗺️", "🧭", "🔒", "👤", "🆘")
    private val words = mapOf(
        "pt" to arrayOf("Mapa", "Rotas", "Grupos", "Perfil", "SOS", "Planear passeio", "Adicionar ponto", "Calcular", "Guardar", "Ligar GPS", "Parar GPS", "Percurso", "Pontos", "Escolhe um ponto no mapa", "Mapa de teste · não navegar a conduzir"),
        "fr" to arrayOf("Carte", "Routes", "Groupes", "Profil", "SOS", "Créer une balade", "Ajouter un point", "Calculer", "Enregistrer", "Activer GPS", "Arrêter GPS", "Parcours", "Points", "Choisir un point sur la carte", "Carte de test · ne pas utiliser en conduisant"),
        "it" to arrayOf("Mappa", "Percorsi", "Gruppi", "Profilo", "SOS", "Pianifica giro", "Aggiungi punto", "Calcola", "Salva", "Attiva GPS", "Ferma GPS", "Percorso", "Punti", "Scegli un punto sulla mappa", "Mappa di prova · non guidare"),
        "es" to arrayOf("Mapa", "Rutas", "Grupos", "Perfil", "SOS", "Planear ruta", "Añadir punto", "Calcular", "Guardar", "Activar GPS", "Detener GPS", "Ruta", "Puntos", "Elige un punto en el mapa", "Mapa de prueba · no usar conduciendo"),
        "de" to arrayOf("Karte", "Routen", "Gruppen", "Profil", "SOS", "Tour planen", "Punkt hinzufügen", "Berechnen", "Speichern", "GPS starten", "GPS stoppen", "Route", "Punkte", "Startpunkt auf Karte wählen", "Testkarte · nicht beim Fahren nutzen"),
        "en" to arrayOf("Map", "Routes", "Groups", "Profile", "SOS", "Plan a ride", "Add point", "Calculate", "Save", "Start GPS", "Stop GPS", "Route", "Points", "Choose a point on the map", "Test map · do not use while riding")
    )
    private fun tr(idx: Int): String = (words[lang] ?: words.getValue("pt"))[idx]
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun rounded(bg: Int, r: Int = 14) = GradientDrawable().apply { setColor(bg); cornerRadius = dp(r).toFloat() }
    private fun label(s: String, size: Float = 14f, c: Int = Color.WHITE, weight: Int = Typeface.NORMAL) = TextView(this).apply {
        text = s; textSize = size; setTextColor(c); setTypeface(Typeface.DEFAULT, weight)
    }
    private fun button(s: String, bg: Int = Color.rgb(30, 55, 69), color: Int = Color.WHITE, callback: () -> Unit) = label(s, 13f, color, Typeface.BOLD).apply {
        gravity = Gravity.CENTER; setPadding(dp(9), dp(13), dp(9), dp(13)); background = rounded(bg)
        setOnClickListener { callback() }
    }
    private fun say(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun js(cmd: String) { if (webReady) web.evaluateJavascript(cmd, null) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lang = prefs.getString("lang", "pt") ?: "pt"
        window.statusBarColor = dark; window.navigationBarColor = dark
        MapLibre.getInstance(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(dark) }
        makeHeader()
        contentHolder = FrameLayout(this)
        root.addView(contentHolder, LinearLayout.LayoutParams(-1, 0, 1f))
        makeMap(savedInstanceState)
        makeWeb()
        makeNavigation()
        setContentView(root)
        showTab("map")
    }

    private fun makeHeader() {
        val hdr = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(dp(15), dp(8), dp(15), dp(9));setBackgroundColor(dark)
        }
        val line = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL }
        val title=label("🏍️ AlpRiders CH", 21f, Color.WHITE, Typeface.BOLD)
        line.addView(title, LinearLayout.LayoutParams(0,-2,1f))
        languageButton=button(localeNames[localeCodes.indexOf(lang).coerceAtLeast(0)], Color.rgb(32,64,77)) { chooseLanguage() }
        line.addView(languageButton, LinearLayout.LayoutParams(-2,-2))
        hdr.addView(line)
        subtitle=label(tr(14), 11f, muted)
        subtitle.setPadding(0,dp(5),0,0)
        hdr.addView(subtitle)
        root.addView(hdr,LinearLayout.LayoutParams(-1,-2))
    }

    private fun makeMap(savedInstanceState: Bundle?) {
        mapHolder=FrameLayout(this)
        contentHolder.addView(mapHolder,FrameLayout.LayoutParams(-1,-1))
        mapView=MapView(this)
        mapView.onCreate(savedInstanceState)
        mapHolder.addView(mapView,FrameLayout.LayoutParams(-1,-1))
        mapView.getMapAsync { m ->
            map=m
            m.cameraPosition=CameraPosition.Builder().target(LatLng(46.82,8.25)).zoom(7.0).tilt(0.0).build()
            m.setStyle("https://tiles.openfreemap.org/styles/liberty") {
                mapReady=true
                redrawRoute()
                lastLocation?.let {updateMarker(it)}
            }
            m.addOnMapClickListener { position -> onMapTap(position); true }
        }
        val speedBox = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER
            setPadding(dp(13),dp(7),dp(13),dp(7));background=rounded(Color.rgb(10,33,44))
        }
        speed=label("—",25f,teal,Typeface.BOLD).apply { gravity=Gravity.CENTER }
        speedBox.addView(speed)
        speedBox.addView(label("km/h",11f,muted).apply{gravity=Gravity.CENTER})
        mapHolder.addView(speedBox,FrameLayout.LayoutParams(dp(85),-2,Gravity.TOP or Gravity.RIGHT).apply{setMargins(0,dp(12),dp(12),0)})
        val mapBottom = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL;setPadding(dp(9),dp(8),dp(9),dp(9))
            setBackgroundColor(Color.rgb(10,30,41))
        }
        val lineA = LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL}
        val planner = button(tr(5), orange, dark) { showTab("routes");js("window.AlpNative&&AlpNative.planner()") }
        lineA.addView(planner,LinearLayout.LayoutParams(0,-2,1f).apply{rightMargin=dp(5)})
        mapGpsButton=button(tr(9)){toggleGps()}
        lineA.addView(mapGpsButton,LinearLayout.LayoutParams(0,-2,1f))
        mapBottom.addView(lineA)
        actionRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,dp(6),0,0)}
        mapBottom.addView(actionRow)
        mapHolder.addView(mapBottom,FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM))
        refreshControls()
    }

    private fun refreshControls() {
        if (!::actionRow.isInitialized) return
        actionRow.removeAllViews()
        val actions=listOf(
            tr(6) to { addingPoint=true;selectingStart=false;say(tr(13)) },
            tr(7) to { js("window.AlpNative&&AlpNative.calculate()") },
            tr(8) to { js("window.AlpNative&&AlpNative.save()") }
        )
        actions.forEachIndexed { i,p ->
            actionRow.addView(button(p.first, if (i==0) Color.rgb(27,74,76) else Color.rgb(31,55,68),Color.WHITE,p.second),
                LinearLayout.LayoutParams(0,-2,1f).apply{if(i>0)leftMargin=dp(6)})
        }
        if (::mapGpsButton.isInitialized) mapGpsButton.text=if(following)tr(10) else tr(9)
        if (::subtitle.isInitialized) subtitle.text=if(currentRoute.isEmpty())tr(14) else "$routeSummary · ${routePoints.size} ${tr(12)} · teste"
    }

    private fun makeWeb() {
        val loader=WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web=WebView(this).apply {
            setBackgroundColor(dark)
            settings.javaScriptEnabled=true
            settings.domStorageEnabled=true
            settings.setGeolocationEnabled(true)
            settings.allowFileAccess=false
            settings.allowContentAccess=false
            settings.mediaPlaybackRequiresUserGesture=true
            addJavascriptInterface(NativeBridge(),"AndroidBridge")
            webViewClient=object: WebViewClient() {
                override fun shouldInterceptRequest(view:WebView, request:WebResourceRequest) = loader.shouldInterceptRequest(request.url)
                override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest):Boolean {
                    val u=request.url
                    if(u.scheme=="tel" || u.scheme=="sms" || u.scheme=="mailto") {
                        try { startActivity(Intent(Intent.ACTION_VIEW,u)) } catch (_:Exception) {say("Sem aplicação para abrir esta ligação")}
                        return true
                    }
                    if(u.host=="appassets.androidplatform.net")return false
                    // External authentication and documentation links open outside app.
                    try {startActivity(Intent(Intent.ACTION_VIEW,u))}catch (_:Exception){}
                    return true
                }
                override fun onPageFinished(view:WebView,url:String) {
                    webReady=true
                    js("window.AlpNative&&AlpNative.language(${JSONObject.quote(lang)})")
                    js("window.AlpNative&&AlpNative.show('routes')")
                    js("window.AlpNative&&AlpNative.sync()")
                }
            }
            webChromeClient=object:WebChromeClient(){
                override fun onGeolocationPermissionsShowPrompt(origin:String,callback:GeolocationPermissions.Callback) {
                    if (origin!="https://appassets.androidplatform.net") {callback.invoke(origin,false,false);return}
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) callback.invoke(origin,true,false)
                    else {webGeoOrigin=origin;webGeoCallback=callback;requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestGps)}
                }
            }
        }
        contentHolder.addView(web,FrameLayout.LayoutParams(-1,-1))
        web.visibility=View.GONE
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun makeNavigation() {
        bottom=LinearLayout(this).apply{ orientation=LinearLayout.HORIZONTAL;setPadding(dp(3),dp(5),dp(3),dp(8));setBackgroundColor(dark) }
        root.addView(bottom,LinearLayout.LayoutParams(-1,-2))
        rebuildNavigation()
    }
    private fun rebuildNavigation() {
        bottom.removeAllViews()
        tabKeys.forEachIndexed{ i,key ->
            val active=key==currentTab
            val label=label("${tabSymbols[i]}\n${tr(i)}",12f,if(active)orange else muted,if(active)Typeface.BOLD else Typeface.NORMAL).apply {
                gravity=Gravity.CENTER; setPadding(0,dp(5),0,dp(5))
                setOnClickListener{showTab(key)}
            }
            bottom.addView(label,LinearLayout.LayoutParams(0,dp(53),1f))
        }
    }
    private fun showTab(key:String) {
        currentTab=key
        val isMap=key=="map"
        mapHolder.visibility=if(isMap)View.VISIBLE else View.GONE
        web.visibility=if(isMap)View.GONE else View.VISIBLE
        if (!isMap) js("window.AlpNative&&AlpNative.show(${JSONObject.quote(key)})")
        else mapView.postDelayed({ map?.let { m-> if(mapReady) {m.cameraPosition=m.cameraPosition} } },160)
        if(::bottom.isInitialized)rebuildNavigation()
        if(::subtitle.isInitialized)refreshControls()
    }

    private fun chooseLanguage() {
        AlertDialog.Builder(this).setTitle("Idioma / Language").setItems(localeNames){_,i ->
            lang=localeCodes[i];prefs.edit().putString("lang",lang).apply()
            languageButton.text=localeNames[i]
            refreshControls();rebuildNavigation()
            js("window.AlpNative&&AlpNative.language(${JSONObject.quote(lang)})")
        }.show()
    }

    private fun onMapTap(position:LatLng) {
        if(selectingStart) {
            selectingStart=false
            js("window.AlpNative&&AlpNative.selectPin(${position.latitude},${position.longitude})")
            showTab("routes")
            js("window.AlpNative&&AlpNative.planner()")
            return
        }
        if(addingPoint) {
            addingPoint=false
            js("window.AlpNative&&AlpNative.addPoint(${position.latitude},${position.longitude})")
        }
    }

    private fun redrawRoute() {
        val m=map?:return
        if(!mapReady)return
        m.clear();gpsMarker=null
        if(currentRoute.size>1) {
            m.addPolyline(PolylineOptions().addAll(currentRoute).color(orange).width(7f))
        }
        routePoints.forEachIndexed { i,p ->
            if (i==0 || i==routePoints.lastIndex || i%3==0) {
                m.addMarker(MarkerOptions().position(p).title(if(i==0)"Partida" else if(i==routePoints.lastIndex)"Chegada" else "Ponto ${i+1}"))
            }
        }
        lastLocation?.let {updateMarker(it)}
        if(currentRoute.size>=2) {
            try {
                val bounds=LatLngBounds.Builder().includes(currentRoute).build()
                m.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds,dp(52)),650)
            } catch (_:Exception) {m.animateCamera(CameraUpdateFactory.newLatLngZoom(currentRoute[0],12.0))}
        }
    }

    private inner class NativeBridge {
        @JavascriptInterface fun openMap() {runOnUiThread {showTab("map")}}
        @JavascriptInterface fun chooseStartPin() {runOnUiThread {
            selectingStart=true;addingPoint=false;showTab("map");say(tr(13))
        }}
        @JavascriptInterface fun languageChanged(code:String) {runOnUiThread {
            if(code in localeCodes && lang!=code) {
                lang=code;prefs.edit().putString("lang",lang).apply()
                languageButton.text=localeNames[localeCodes.indexOf(code)]
                refreshControls();rebuildNavigation()
            }
        }}
        @JavascriptInterface fun onRouteChange(json:String) {runOnUiThread {
            try {
                val obj=JSONObject(json)
                routePoints=readCoords(obj.optJSONArray("points"))
                val road=obj.optJSONObject("road")
                val line=readCoords(road?.optJSONArray("geometry"))
                currentRoute=if(line.isNotEmpty())line else routePoints
                routeSummary=if(road!=null)"${road.optString("distance")} km · ${road.optString("duration")} min" else "${routePoints.size} ${tr(12)}"
                if(mapReady)redrawRoute()
                refreshControls()
            } catch (_:Exception) { say("Não foi possível apresentar este percurso") }
        }}
        @JavascriptInterface fun exportGPX(name:String,geoJson:String) {runOnUiThread {
            try {
                val coords=readCoords(JSONArray(geoJson))
                if(coords.size<2) {say("Precisas de pelo menos dois pontos");return@runOnUiThread}
                val xml=StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><gpx version=\"1.1\" creator=\"AlpRiders CH\" xmlns=\"http://www.topografix.com/GPX/1/1\"><trk><name>")
                xml.append(name.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"))
                xml.append("</name><trkseg>")
                coords.forEach{xml.append("<trkpt lat=\"").append(it.latitude).append("\" lon=\"").append(it.longitude).append("\"/>")}
                xml.append("</trkseg></trk></gpx>")
                gpxPending=xml.toString()
                val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{
                    addCategory(Intent.CATEGORY_OPENABLE);type="application/gpx+xml"
                    putExtra(Intent.EXTRA_TITLE,"AlpRiders_CH.gpx")
                }
                startActivityForResult(intent,requestExport)
            } catch (_:Exception) {say("Não foi possível exportar GPX")}
        }}
    }
    private fun readCoords(array:JSONArray?):List<LatLng> {
        if(array==null) return emptyList()
        val result=ArrayList<LatLng>()
        val increment=if(array.length()>2500)array.length()/2500+1 else 1
        for(i in 0 until array.length() step increment) {
            val p=array.optJSONArray(i)?:continue
            if(p.length()>=2){val a=p.optDouble(0);val b=p.optDouble(1)
                if(a in -90.0..90.0 && b in -180.0..180.0)result.add(LatLng(a,b))}
        }
        if(increment>1 && array.length()>0){val last=array.optJSONArray(array.length()-1);if(last!=null)result.add(LatLng(last.optDouble(0),last.optDouble(1)))}
        return result
    }

    private fun toggleGps() {
        if(following) {
            following=false;locationManager?.removeUpdates(this)
            subtitle.text=tr(14);refreshControls()
        } else if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestGps)
        } else startGps()
    }
    private fun startGps() {
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return
        val lm=getSystemService(Context.LOCATION_SERVICE) as LocationManager
        locationManager=lm
        if(!lm.isProviderEnabled(LocationManager.GPS_PROVIDER) && !lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){
            say("Ativa a localização nas definições do Samsung");return
        }
        following=true;refreshControls()
        try {
            if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1100L,2f,this)
            if(lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,2500L,5f,this)
            (lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?:lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER))?.let{onLocationChanged(it)}
        }catch (_:SecurityException){following=false;refreshControls()}
    }
    override fun onLocationChanged(location:Location) {
        if(lastLocation==null || location.accuracy<=lastLocation!!.accuracy+25 || location.time>lastLocation!!.time+2500)lastLocation=location
        val accepted=lastLocation?:location
        speed.text=if(accepted.hasSpeed())"${(accepted.speed*3.6).toInt().coerceAtLeast(0)}" else "—"
        updateMarker(accepted)
        if(following && currentTab=="map"){
            val m=map?:return
            val bearing=if(accepted.hasBearing()&&accepted.speed>2)accepted.bearing.toDouble() else m.cameraPosition.bearing
            m.animateCamera(CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder().target(LatLng(accepted.latitude,accepted.longitude)).zoom(16.0).bearing(bearing).tilt(35.0).build()
            ),700)
        }
    }
    private fun updateMarker(location:Location) {
        val m=map?:return
        if(!mapReady)return
        val pos=LatLng(location.latitude,location.longitude)
        if(gpsMarker==null)gpsMarker=m.addMarker(MarkerOptions().position(pos).title("GPS · ${location.accuracy.toInt()} m"))
        else gpsMarker?.position=pos
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode!=requestGps)return
        val granted=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
        webGeoCallback?.invoke(webGeoOrigin,granted,false)
        webGeoCallback=null;webGeoOrigin=null
        if(granted)startGps()else say("GPS: autorização não concedida")
    }
    @Deprecated("Android callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==requestExport && resultCode==RESULT_OK){
            val uri=data?.data;val xml=gpxPending
            if(uri!=null && xml!=null){
                try {contentResolver.openOutputStream(uri)?.use{stream->OutputStreamWriter(stream,Charsets.UTF_8).use{it.write(xml)}};say("GPX exportado")}
                catch (_:Exception){say("Falha ao guardar GPX")}
            }
            gpxPending=null
        }
    }
    @Deprecated("Navigation")
    override fun onBackPressed(){if(currentTab!="map")showTab("map") else super.onBackPressed()}
    override fun onStart(){super.onStart();mapView.onStart();if(following)startGps()}
    override fun onResume(){super.onResume();mapView.onResume();web.onResume()}
    override fun onPause(){web.onPause();mapView.onPause();super.onPause()}
    override fun onStop(){locationManager?.removeUpdates(this);mapView.onStop();super.onStop()}
    override fun onLowMemory(){super.onLowMemory();mapView.onLowMemory()}
    override fun onDestroy(){locationManager?.removeUpdates(this);mapView.onDestroy();web.destroy();super.onDestroy()}
    override fun onSaveInstanceState(outState:Bundle){mapView.onSaveInstanceState(outState);super.onSaveInstanceState(outState)}
}
