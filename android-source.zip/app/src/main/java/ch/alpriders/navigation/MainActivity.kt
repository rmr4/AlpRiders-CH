package ch.alpriders.navigation

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioAttributes
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.speech.tts.TextToSpeech
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Gravity
import android.view.WindowInsets
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.Icon
import org.maplibre.android.annotations.IconFactory
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.annotations.PolylineOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap
import java.io.OutputStreamWriter
import java.util.Locale

/**
 * AlpRiders CH 0.13 – multilingual voice, one-way Swiss address rides, transparent bike marker.
 * Native vector map + GPS; routes, planner, groups, SOS, profile and six languages
 * retained from the existing AlpRiders web prototype via an internal secure WebView.
 * NO turn-by-turn certified motorcycle navigation, background tracking or crash detection.
 */
class MainActivity : Activity(), LocationListener {
    private val dark = Color.rgb(12, 27, 40)
    private val orange = Color.rgb(250, 139, 66)
    private val muted = Color.rgb(178, 205, 213)
    private val teal = Color.rgb(82, 209, 207)
    private val prefs by lazy { getSharedPreferences("alpriders_native", Context.MODE_PRIVATE) }
    private var lang = "pt"
    private var currentTab = "map"
    private lateinit var mapView: MapView
    private var map: MapLibreMap? = null
    private var gpsMarker: Marker? = null
    private var departureMarker: Marker? = null
    private var gpsBikeIcon: Icon? = null
    private var startBikeIcon: Icon? = null
    private var mapReady = false
    private var following = false
    private var lastLocation: Location? = null
    private var locationManager: LocationManager? = null
    private var addingPoint = false
    private var selectingStart = false
    private var webReady = false
    private var currentRoute: List<LatLng> = emptyList()
    private var routePoints: List<LatLng> = emptyList()
    private var routeSummary = ""
    private var routeSwissVerified = false
    private var routeTurns: List<RouteGuide.Turn> = emptyList()
    private var navActive = false
    private var navPending = false
    private var navLastProgress = 0.0
    private var navVoiceEnabled = true
    private var navSpeech: TextToSpeech? = null
    private var navSpeechReady = false
    private var navLastManeuver = ""
    private var navLastAlert = 0L
    private var navStartSpoken = false
    private var navFinishSpoken = false
    private var navOffRouteSpoken = false
    private var lastCameraUpdateAt = 0L
    private lateinit var navBanner: LinearLayout
    private lateinit var navDistanceText: TextView
    private lateinit var navInstructionText: TextView
    private lateinit var navInfoText: TextView
    private lateinit var navFooter: LinearLayout
    private lateinit var mapControls: LinearLayout
    private lateinit var speedOverlay: LinearLayout
    private lateinit var headerView: LinearLayout
    private lateinit var mapHolder: FrameLayout
    private lateinit var contentHolder: FrameLayout
    private lateinit var root: LinearLayout
    private lateinit var web: WebView
    private lateinit var subtitle: TextView
    private lateinit var speed: TextView
    private lateinit var languageButton: TextView
    private lateinit var mapGpsButton: TextView
    private lateinit var actionRow: LinearLayout
    private lateinit var bottom: LinearLayout
    private var webGeoCallback: GeolocationPermissions.Callback? = null
    private var webGeoOrigin: String? = null
    private var gpxPending: String? = null
    // Web screens request a fresh Android location only after the rider presses a GPS/SOS button.
    // The WebView is not asked to supply its own browser geolocation permissions.
    private val pendingWebPositions = mutableListOf<Int>()
    private var locationRequestActive = false
    private var pendingGpsStart = false
    private var singleFixListener: LocationListener? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private val singleFixTimeout = Runnable { finishWebLocation(null, "timeout") }
    private val requestGps = 51
    private val requestExport = 63
    private val requestSafetyLocation = 72
    private val requestSafetyNotifications = 73
    // Requires explicit one-time opt-in: no silent 24/7 or boot-time tracking.
    private var safetyAutoAttempted = false
    private var testAlarmDialog: AlertDialog? = null
    private var detectedIncidentDialog: AlertDialog? = null
    private var testAlarmRingtone: Ringtone? = null
    private var testAlarmEnd = 0L
    private val testAlarmTick = object : Runnable {
        override fun run() {
            val dialog = testAlarmDialog ?: return
            val remaining = ((testAlarmEnd - android.os.SystemClock.elapsedRealtime() + 999L) / 1000L).coerceAtLeast(0)
            if (remaining == 0L) {
                clearTestAlarm()
                say("Fim do teste: nenhuma mensagem ou chamada foi enviada.")
            } else {
                dialog.setMessage("SIMULAÇÃO LOCAL — ${remaining}s restantes.\n\nPremir «Estou bem» cancela o alarme.\n\nNÃO envia WhatsApp, SMS nem chama 112/144.")
                uiHandler.postDelayed(this, 1_000L)
            }
        }
    }

    /** Six languages, including spoken guidance. The selected voice must really exist on this phone. */
    private val navigationLocales=mapOf(
        "pt" to "pt-PT","fr" to "fr-FR","it" to "it-IT",
        "es" to "es-ES","de" to "de-DE","en" to "en-GB")
    private val guidanceStrings=mapOf(
        "pt" to listOf("Voz da AlpRiders ativada. Segue as indicações do mapa.","GPS impreciso","Aguarda sinal GPS","Sem orientação até melhorar a localização","Fora do percurso","Pára em segurança","Sem recálculo automático. Verifica o mapa antes de continuar.","Estás fora do percurso. Pára em segurança para verificar o mapa.","Chegada","Destino alcançado","Confirma que estacionaste em segurança","Chegaste ao destino. Estaciona em segurança.","Segue o percurso até ao destino","Restam","Navegação iniciada.","Daqui a","Segue o percurso apresentado no mapa.","Voz indisponível neste idioma. Instala uma voz adequada nas definições do Android."),
        "fr" to listOf("Guidage vocal AlpRiders activé. Suivez les indications.","GPS imprécis","Attendez un signal GPS","Guidage suspendu jusqu'à une meilleure position","Hors de l'itinéraire","Arrêtez-vous en sécurité","Pas de recalcul automatique. Vérifiez la carte avant de continuer.","Vous êtes hors de l'itinéraire. Arrêtez-vous pour vérifier la carte.","Arrivée","Destination atteinte","Garez-vous en sécurité","Vous êtes arrivé à destination. Garez-vous en sécurité.","Suivez l'itinéraire jusqu'à destination","Restant","Navigation démarrée.","Dans","Suivez l'itinéraire sur la carte.","Voix indisponible dans cette langue. Installez une voix Android adaptée."),
        "it" to listOf("Voce AlpRiders attivata. Segui le indicazioni.","GPS impreciso","Attendi un segnale GPS","Guida sospesa finché il segnale non migliora","Fuori percorso","Fermati in sicurezza","Nessun ricalcolo automatico. Verifica la mappa prima di ripartire.","Sei fuori percorso. Fermati in sicurezza e controlla la mappa.","Arrivo","Destinazione raggiunta","Parcheggia in sicurezza","Hai raggiunto la destinazione. Parcheggia in sicurezza.","Segui il percorso fino a destinazione","Restano","Navigazione avviata.","Tra","Segui il percorso sulla mappa.","Voce non disponibile in questa lingua. Installa una voce Android adatta."),
        "es" to listOf("Voz de AlpRiders activada. Sigue las indicaciones.","GPS impreciso","Espera señal GPS","Guía suspendida hasta mejorar la ubicación","Fuera de ruta","Detente en un lugar seguro","No hay recálculo automático. Revisa el mapa antes de continuar.","Estás fuera de ruta. Detente para revisar el mapa.","Llegada","Destino alcanzado","Aparca de forma segura","Has llegado al destino. Aparca de forma segura.","Sigue la ruta hasta el destino","Quedan","Navegación iniciada.","En","Sigue la ruta del mapa.","Voz no disponible en este idioma. Instala una voz Android adecuada."),
        "de" to listOf("AlpRiders Sprachansagen aktiviert. Folge den Hinweisen.","GPS ungenau","Auf GPS-Signal warten","Navigation pausiert, bis das Signal besser ist","Abseits der Route","Sicher anhalten","Keine automatische Neuberechnung. Prüfe die Karte vor der Weiterfahrt.","Du bist abseits der Route. Halte sicher an und prüfe die Karte.","Ankunft","Ziel erreicht","Bitte sicher parken","Du hast dein Ziel erreicht. Bitte sicher parken.","Folge der Route bis zum Ziel","Verbleibend","Navigation gestartet.","In","Folge der Route auf der Karte.","Stimme in dieser Sprache nicht verfügbar. Installiere eine passende Android-Stimme."),
        "en" to listOf("AlpRiders voice guidance enabled. Follow the map directions.","GPS inaccurate","Waiting for GPS signal","Guidance suspended until location improves","Off route","Stop safely","No automatic rerouting. Check the map before continuing.","You are off route. Stop safely and check the map.","Arrival","Destination reached","Park safely","You have reached your destination. Park safely.","Follow the route to your destination","Remaining","Navigation started.","In","Follow the route shown on the map.","Voice not available for this language. Install a matching Android voice.")
    )
    private fun navWord(index:Int)=(guidanceStrings[lang]?:guidanceStrings.getValue("pt"))[index]
    private fun configureSpeechLanguage(){
        val tts=navSpeech?:return
        val chosen=Locale.forLanguageTag(navigationLocales[lang]?:"pt-PT")
        var result=tts.setLanguage(chosen)
        // Use a voice in the same language if the exact regional accent is unavailable.
        if(result==TextToSpeech.LANG_NOT_SUPPORTED || result==TextToSpeech.LANG_MISSING_DATA)
            result=tts.setLanguage(Locale(lang))
        navSpeechReady=result!=TextToSpeech.LANG_NOT_SUPPORTED && result!=TextToSpeech.LANG_MISSING_DATA
        if(!navSpeechReady)navSpeech?.stop()
        if(navActive && !navSpeechReady)runOnUiThread {say(navWord(17))}
    }
    private val localeNames = arrayOf("Português", "Français", "Italiano", "Español", "Deutsch", "English")
    private val localeCodes = arrayOf("pt", "fr", "it", "es", "de", "en")
    private val tabKeys = arrayOf("map", "routes", "chat", "profile", "sos")
    private val tabSymbols = arrayOf("🗺️", "🧭", "🔒", "👤", "🆘")
    private val words = mapOf(
        "pt" to arrayOf("Mapa", "Rotas", "Grupos", "Perfil", "SOS", "Planear passeio", "Adicionar ponto", "Calcular", "Guardar", "Ligar GPS", "Parar GPS", "Percurso", "Pontos", "Escolhe um ponto no mapa", "Mapa de teste · não navegar a conduzir"),
        "fr" to arrayOf("Carte", "Routes", "Groupes", "Profil", "SOS", "Créer une balade", "Ajouter un point", "Calculer", "Enregistrer", "Activer GPS", "Arrêter GPS", "Parcours", "Points", "Choisir un point sur la carte", "Carte de test · ne pas utiliser en conduisant"),
        "it" to arrayOf("Mappa", "Percorsi", "Gruppi", "Profilo", "SOS", "Pianifica giro", "Aggiungi punto", "Calcola", "Salva", "Attiva GPS", "Ferma GPS", "Percorso", "Punti", "Scegli un punto sulla mappa", "Mappa di prova · non guidare"),
        "es" to arrayOf("Mapa", "Rutas", "Grupos", "Perfil", "SOS", "Planear ruta", "Añadir punto", "Calcular", "Guardar", "Activar GPS", "Detener GPS", "Ruta", "Puntos", "Elige un punto en el mapa", "Mapa de prueba · no usar conduciendo"),
        "de" to arrayOf("Karte", "Routen", "Gruppen", "Profil", "SOS", "Tour planen", "Punkt hinzufügen", "Berechnen", "Speichern", "GPS starten", "GPS stoppen", "Route", "Punkte", "Startpunkt auf Karte wählen", "Testkarte · nicht beim Fahren nutzen"),
        "en" to arrayOf("Map", "Routes", "Groups", "Profile", "SOS", "Plan a ride", "Add point", "Calculate", "Save", "Start GPS", "Stop GPS", "Route", "Points", "Choose a point on the map", "Test map · do not use while riding")
    )
    private fun tr(idx: Int): String = (words[lang] ?: words.getValue("pt"))[idx]
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun rounded(bg: Int, r: Int = 14) = GradientDrawable().apply { setColor(bg); cornerRadius = dp(r).toFloat() }
    private fun label(s: String, size: Float = 14f, c: Int = Color.WHITE, weight: Int = Typeface.NORMAL) = TextView(this).apply {
        text = s; textSize = size; setTextColor(c); setTypeface(Typeface.DEFAULT, weight)
    }
    private fun button(s: String, bg: Int = Color.rgb(30, 55, 69), color: Int = Color.WHITE, callback: () -> Unit) = label(s, 13f, color, Typeface.BOLD).apply {
        gravity = Gravity.CENTER; minimumHeight = dp(48); setPadding(dp(8), dp(8), dp(8), dp(8)); background = rounded(bg)
        setOnClickListener { callback() }
    }
    private fun say(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun js(cmd: String) { if (webReady) web.evaluateJavascript(cmd, null) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lang = prefs.getString("lang", "pt") ?: "pt"
        window.statusBarColor = dark; window.navigationBarColor = dark
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        MapLibre.getInstance(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(dark) }
        makeHeader()
        contentHolder = FrameLayout(this)
        root.addView(contentHolder, LinearLayout.LayoutParams(-1, 0, 1f))
        makeMap(savedInstanceState)
        makeWeb()
        makeNavigation()
        SafetyMonitorService.observer = { status -> runOnUiThread { safetyStatusToWeb(status) } }
        // Android 15 (target SDK 35) draws apps edge-to-edge by default.
        // Reserve the actual status/navigation/gesture-bar safe areas at runtime,
        // instead of assuming fixed Samsung-specific pixel offsets.
        setContentView(root)
        installSystemBarInsets()
        showTab(if (intent?.getBooleanExtra("open_sos",false)==true) "sos" else "map")
        // Voice is only used after the rider explicitly starts on-screen guidance.
        navSpeech=TextToSpeech(this) { status ->
            // The TTS callback can run after the screen is already showing navigation.
            navSpeechReady=status==TextToSpeech.SUCCESS
            if(navSpeechReady){
                val tts=navSpeech
                configureSpeechLanguage()
                tts?.setSpeechRate(0.94f)
                tts?.setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            }
            if(navActive && navVoiceEnabled && navSpeechReady) runOnUiThread {
                if(navActive) lastLocation?.let {updateNavigation(it)}
            }
        }
        // Ask once while app is visible, not silently at device startup.
        root.post { offerAutoSafetyConsent() }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("open_sos",false)==true) showTab("sos")
    }

    private fun safetyStatusToWeb(message:String) {
        js("window.AlpNative&&AlpNative.safetyStatus(${JSONObject.quote(message)})")
        // Show an actionable native alert while the app is open, in addition to
        // the foreground notification. This cannot pop up reliably over a locked screen.
        if (message.startsWith("ALERTA DE TESTE:")) {
            if (detectedIncidentDialog?.isShowing != true && !isFinishing) {
                detectedIncidentDialog = AlertDialog.Builder(this)
                    .setTitle("⚠️ Possível incidente — TESTE")
                    .setMessage(message + "\n\nNenhum aviso externo foi enviado.")
                    .setPositiveButton("Estou bem · cancelar") { _, _ ->
                        safetyAction(SafetyMonitorService.ACTION_CANCEL)
                        detectedIncidentDialog = null
                    }
                    .setNegativeButton("Abrir SOS") { _, _ ->
                        safetyAction(SafetyMonitorService.ACTION_HELP)
                        showTab("sos")
                        detectedIncidentDialog = null
                    }
                    .setCancelable(false).create()
                detectedIncidentDialog?.show()
            } else detectedIncidentDialog?.setMessage(message + "\n\nNenhum aviso externo foi enviado.")
        } else {
            detectedIncidentDialog?.dismiss()
            detectedIncidentDialog = null
        }
    }

    private fun offerAutoSafetyConsent() {
        if (isFinishing || prefs.getBoolean("safety_choice_seen", false)) return
        prefs.edit().putBoolean("safety_choice_seen", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Monitor automático de segurança — TESTE")
            .setMessage("Queres que o monitor de teste inicie automaticamente sempre que abres a AlpRiders CH? " +
                "Depois de detetar movimento, poderá avisar de uma imobilização anormal. " +
                "Usa a localização e uma notificação permanente, inclusive com o ecrã bloqueado. " +
                "Não envia mensagens nem faz chamadas de emergência. Podes parar a qualquer momento em SOS. " +
                "O Android pode interromper o serviço; não substitui um sistema SOS fiável.")
            .setPositiveButton("Ativar automaticamente") { _, _ ->
                prefs.edit().putBoolean("safety_auto_enabled",true).apply()
                safetyAutoAttempted = true
                startSafetyMonitor()
            }
            .setNegativeButton("Agora não") { _, _ ->
                prefs.edit().putBoolean("safety_auto_enabled",false).apply()
                safetyStatusToWeb("Monitor automático desativado. Para ativar, toca em «Iniciar monitor» no SOS.")
            }.show()
    }
    private fun startSafetyMonitor() {
        if (SafetyMonitorService.running) {
            safetyStatusToWeb("Monitor de segurança já ativo (teste).")
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestSafetyLocation)
            return
        }
        if (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),requestSafetyNotifications)
            return
        }
        try {
            startForegroundService(Intent(this,SafetyMonitorService::class.java).setAction(SafetyMonitorService.ACTION_START))
            safetyStatusToWeb("A iniciar monitorização GPS em segundo plano — TESTE. Verifica a notificação permanente.")
        } catch (e:Exception) {
            safetyStatusToWeb("Não foi possível iniciar o monitor: ${e.javaClass.simpleName}. Verifica permissões e localização.")
        }
    }
    private fun beginManualSafetyMonitor() {
        prefs.edit().putBoolean("safety_choice_seen",true).putBoolean("safety_auto_enabled",true).apply()
        safetyAutoAttempted = true
        startSafetyMonitor()
    }
    private fun safetyAction(action:String) {
        if (action == SafetyMonitorService.ACTION_STOP) {
            // A manual stop must stay stopped; never auto-restart on the next resume.
            prefs.edit().putBoolean("safety_auto_enabled",false).apply()
        }
        try { startService(Intent(this,SafetyMonitorService::class.java).setAction(action)) }
        catch (e:Exception) { safetyStatusToWeb("Ação do monitor indisponível: ${e.javaClass.simpleName}") }
    }
    /** A visible test alarm does not depend on GPS or a running monitor. */
    private fun showTestAlarm() {
        clearTestAlarm()
        testAlarmEnd = android.os.SystemClock.elapsedRealtime() + 60_000L
        testAlarmDialog = AlertDialog.Builder(this)
            .setTitle("⚠️ TESTE — Estás bem?")
            .setMessage("SIMULAÇÃO LOCAL — 60 segundos. Não envia nenhum alerta externo.")
            .setPositiveButton("Estou bem · cancelar") { _, _ -> clearTestAlarm() }
            .setNegativeButton("Pedir ajuda (abrir SOS)") { _, _ -> clearTestAlarm(); showTab("sos") }
            .setCancelable(false).create()
        testAlarmDialog?.show()
        try {
            testAlarmRingtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            testAlarmRingtone?.play()
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(1500L,VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_:Exception) { /* Dialog remains visible even if sound/vibration is unavailable. */ }
        uiHandler.post(testAlarmTick)
    }
    private fun clearTestAlarm() {
        uiHandler.removeCallbacks(testAlarmTick)
        try { testAlarmRingtone?.stop() } catch (_:Exception) {}
        testAlarmRingtone = null
        val dialog = testAlarmDialog
        testAlarmDialog = null
        if (dialog?.isShowing==true) dialog.dismiss()
    }

    /**
     * Keep ALL native controls clear of system status/navigation bars, including
     * Samsung's three-button navigation and gesture modes, in portrait/landscape.
     * The root's remaining height is split between the map/content and bottom tabs.
     */
    @Suppress("DEPRECATION")
    private fun installSystemBarInsets() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
        root.setOnApplyWindowInsetsListener { view, insets ->
            val top: Int
            val bottom: Int
            val left: Int
            val right: Int
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bars = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                top = bars.top
                bottom = bars.bottom
                left = bars.left
                right = bars.right
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
                left = insets.systemWindowInsetLeft
                right = insets.systemWindowInsetRight
            }
            view.setPadding(left, top, right, bottom)
            insets
        }
        root.requestApplyInsets()
    }

    private fun makeHeader() {
        val hdr = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(dp(13), dp(3), dp(13), dp(3));setBackgroundColor(dark)
        }
        val line = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL }
        val title=label("🏍️ AlpRiders CH", 19f, Color.WHITE, Typeface.BOLD)
        line.addView(title, LinearLayout.LayoutParams(0,-2,1f))
        languageButton=button(localeNames[localeCodes.indexOf(lang).coerceAtLeast(0)], Color.rgb(32,64,77)) { chooseLanguage() }
        languageButton.minimumHeight = dp(44)
        line.addView(languageButton, LinearLayout.LayoutParams(-2,-2))
        hdr.addView(line)
        subtitle=label(tr(14), 11f, muted)
        subtitle.setPadding(0,dp(5),0,0)
        hdr.addView(subtitle)
        headerView=hdr
        root.addView(hdr,LinearLayout.LayoutParams(-1,-2))
    }

    /** Transparent motorcycle marker, without the former circular badge. */
    private fun motorcycleIcon(color:Int):Icon {
        val size=dp(60).coerceAtLeast(70)
        val bitmap=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bitmap)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{
            textSize=size*.65f
            textAlign=Paint.Align.CENTER
            typeface=Typeface.DEFAULT_BOLD
            setShadowLayer(dp(2).toFloat(),0f,dp(2).toFloat(),Color.argb(110,0,0,0))
        }
        // Emoji glyph uses the system's motorbike font and keeps a transparent background.
        canvas.drawText("🏍️",size*.50f,size*.72f,paint)
        return IconFactory.getInstance(this).fromBitmap(bitmap)
    }

    private fun navigationZoom(fix:Location):Double = when {
        !fix.hasSpeed() -> 17.5
        fix.speed >= 27.8f -> 16.4  // motorway pace
        fix.speed >= 16.7f -> 16.9
        fix.speed >= 8.3f -> 17.3
        else -> 17.7
    }

    /** Follow the motorcycle immediately and then smoothly on each valid GPS update. */
    private fun followNavigationCamera(fix:Location,immediate:Boolean=false){
        if(!navActive || !mapReady || fix.accuracy>100f)return
        val m=map?:return
        val now=android.os.SystemClock.elapsedRealtime()
        if(!immediate && now-lastCameraUpdateAt<800L)return
        lastCameraUpdateAt=now
        val direction=if(fix.hasBearing() && fix.speed>1.5f) fix.bearing.toDouble()
            else m.cameraPosition.bearing
        val position=CameraPosition.Builder()
            .target(LatLng(fix.latitude,fix.longitude)).zoom(navigationZoom(fix))
            .bearing(direction).tilt(48.0).build()
        if(immediate) m.moveCamera(CameraUpdateFactory.newCameraPosition(position))
        else m.animateCamera(CameraUpdateFactory.newCameraPosition(position),650)
    }

    private fun speakNavigation(message:String,key:String){
        if(!navActive || !navVoiceEnabled || !navSpeechReady)return
        navSpeech?.speak(message,TextToSpeech.QUEUE_FLUSH,null,key)
    }

    private fun makeMap(savedInstanceState: Bundle?) {
        mapHolder=FrameLayout(this)
        contentHolder.addView(mapHolder,FrameLayout.LayoutParams(-1,-1))
        mapView=MapView(this)
        mapView.onCreate(savedInstanceState)
        mapHolder.addView(mapView,FrameLayout.LayoutParams(-1,-1))
        mapView.getMapAsync { m ->
            map=m
            m.cameraPosition=CameraPosition.Builder().target(LatLng(46.82,8.25)).zoom(7.0).tilt(0.0).build()
            m.setStyle("https://tiles.openfreemap.org/styles/liberty") {
                mapReady=true
                redrawRoute()
                lastLocation?.let {updateMarker(it)}
            }
            m.addOnMapClickListener { position -> onMapTap(position); true }
        }
        val speedBox = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER
            setPadding(dp(13),dp(7),dp(13),dp(7));background=rounded(Color.rgb(10,33,44))
        }
        speedOverlay=speedBox
        speed=label("—",25f,teal,Typeface.BOLD).apply { gravity=Gravity.CENTER }
        speedBox.addView(speed)
        speedBox.addView(label("km/h",11f,muted).apply{gravity=Gravity.CENTER})
        mapHolder.addView(speedBox,FrameLayout.LayoutParams(dp(85),-2,Gravity.TOP or Gravity.RIGHT).apply{setMargins(0,dp(12),dp(12),0)})
        val navigationStart=button("🧭 Navegar",Color.rgb(27,74,76)) {requestStartNavigation()}
        mapHolder.addView(navigationStart,FrameLayout.LayoutParams(dp(124),dp(50),Gravity.TOP or Gravity.LEFT).apply{
            setMargins(dp(12),dp(12),0,0)
        })
        val mapBottom = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL;setPadding(dp(9),dp(6),dp(9),dp(6))
            setBackgroundColor(Color.rgb(10,30,41))
        }
        val lineA = LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL}
        val planner = button(tr(5), orange, dark) { showTab("routes");js("window.AlpNative&&AlpNative.planner()") }
        lineA.addView(planner,LinearLayout.LayoutParams(0,-2,1f).apply{rightMargin=dp(5)})
        mapGpsButton=button(tr(9)){toggleGps()}
        lineA.addView(mapGpsButton,LinearLayout.LayoutParams(0,-2,1f))
        mapBottom.addView(lineA)
        actionRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,dp(5),0,0)}
        mapBottom.addView(actionRow)
        mapHolder.addView(mapBottom,FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM))
        mapControls=mapBottom
        addNavigationOverlay()
        refreshControls()
    }

    /** Rider-friendly full-map guidance. Experimental, NO off-route rerouting or certified instructions. */
    private fun addNavigationOverlay(){
        navBanner=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(12),dp(18),dp(12))
            setBackgroundColor(Color.rgb(7,16,23));visibility=View.GONE
        }
        navDistanceText=label("",27f,Color.WHITE,Typeface.BOLD)
        navInstructionText=label("",23f,teal,Typeface.BOLD)
        navInfoText=label("",13f,muted)
        navBanner.addView(navDistanceText)
        navBanner.addView(navInstructionText)
        navBanner.addView(navInfoText)
        mapHolder.addView(navBanner,FrameLayout.LayoutParams(-1,-2,Gravity.TOP))
        navFooter=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            setPadding(dp(12),dp(10),dp(12),dp(12))
            setBackgroundColor(Color.rgb(7,16,23));visibility=View.GONE
        }
        val stop=button("✕ Terminar",orange,dark) {stopNativeNavigation()}
        navFooter.addView(stop,LinearLayout.LayoutParams(0,dp(54),1f))
        val voice=button("🔊 Voz",Color.rgb(27,74,76)) {}
        voice.setOnClickListener {
            navVoiceEnabled=!navVoiceEnabled
            if(!navVoiceEnabled)navSpeech?.stop()
            voice.text=if(navVoiceEnabled)"🔊 Voz" else "🔇 Sem voz"
            if(navVoiceEnabled){
                if(navSpeechReady) speakNavigation(navWord(0),"alpriders_voice_test")
                else say(navWord(17))
            }
        }
        navFooter.addView(voice,LinearLayout.LayoutParams(0,dp(54),1f).apply{leftMargin=dp(6)})
        val sos=button("SOS",Color.rgb(145,39,53)) {stopNativeNavigation();showTab("sos")}
        navFooter.addView(sos,LinearLayout.LayoutParams(0,dp(54),.55f).apply{leftMargin=dp(6)})
        mapHolder.addView(navFooter,FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM))
    }
    private fun requestStartNavigation(){
        if(navActive){stopNativeNavigation();return}
        if(!routeSwissVerified||currentRoute.size<2||routeTurns.isEmpty()){
            AlertDialog.Builder(this).setTitle("Sem indicações de navegação")
                .setMessage("Cria e calcula primeiro uma rota rodoviária na Suíça. A linha de pré-visualização não chega para navegar. O planeador é experimental e não conhece todos os acessos proibidos ou estradas fechadas.")
                .setPositiveButton("Rotas") {_,_->showTab("routes")}
                .setNegativeButton("Cancelar",null).show()
            return
        }
        navPending=true
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            pendingGpsStart=true
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestGps)
            return
        }
        if(!following)startGps()
        val fix=lastLocation
        if(fix!=null && System.currentTimeMillis()-fix.time < 30_000L) beginNativeNavigation(fix)
        else say("À espera de GPS recente. Mantém o telemóvel parado até obter sinal.")
    }
    private fun beginNativeNavigation(loc:Location){
        if(!navPending || !routeSwissVerified)return
        if(loc.accuracy>80f){say("GPS ainda impreciso; aguarda um sinal melhor.");return}
        val gps=RouteGuide.Point(loc.latitude,loc.longitude)
        val progress=RouteGuide.progress(currentRoute.map {RouteGuide.Point(it.latitude,it.longitude)},gps) ?: return
        if(progress.offRouteMeters>400){
            navPending=false
            AlertDialog.Builder(this).setTitle("Afastado do percurso")
                .setMessage("Estás a mais de 400 m da rota planeada. Aproxima-te do início por meios seguros; esta versão ainda não recalcula o percurso.")
                .setPositiveButton("Entendido",null).show()
            return
        }
        navPending=false;navActive=true;navLastProgress=progress.alongMeters
        navLastManeuver="";navLastAlert=0L;navStartSpoken=false;navFinishSpoken=false;navOffRouteSpoken=false
        departureMarker?.let { map?.removeMarker(it) };departureMarker=null
        headerView.visibility=View.GONE
        bottom.visibility=View.GONE
        mapControls.visibility=View.GONE
        speedOverlay.visibility=View.GONE
        navBanner.visibility=View.VISIBLE
        navFooter.visibility=View.VISIBLE
        if(currentTab!="map")showTab("map")
        followNavigationCamera(loc,immediate=true)
        updateNavigation(loc)
    }
    private fun stopNativeNavigation(){
        navActive=false;navPending=false;navSpeech?.stop()
        if(::navBanner.isInitialized){navBanner.visibility=View.GONE;navFooter.visibility=View.GONE}
        if(::mapControls.isInitialized){mapControls.visibility=View.VISIBLE;speedOverlay.visibility=View.VISIBLE}
        if(::headerView.isInitialized)headerView.visibility=View.VISIBLE
        if(::bottom.isInitialized)bottom.visibility=View.VISIBLE
        navLastManeuver="";navLastProgress=0.0;navStartSpoken=false
        if(mapReady && currentRoute.isNotEmpty())redrawRoute()
    }
    private fun guidanceDistance(metres:Double):String = if(metres<950) "${(metres/10).toInt()*10} m"
        else String.format(Locale.US,"%.1f km",metres/1000.0)
    private fun updateNavigation(loc:Location){
        if(!navActive)return
        if(loc.accuracy>100){
            navDistanceText.text=navWord(1)
            navInstructionText.text=navWord(2)
            navInfoText.text=navWord(3)
            return
        }
        // Zoom is not dependent on the next maneuver being available.
        followNavigationCamera(loc)
        val gps=RouteGuide.Point(loc.latitude,loc.longitude)
        val progress=RouteGuide.progress(currentRoute.map {RouteGuide.Point(it.latitude,it.longitude)},gps,navLastProgress)?:return
        if(progress.offRouteMeters>120){
            navDistanceText.text=navWord(4)
            navInstructionText.text=navWord(5)
            navInfoText.text=navWord(6)
            if(!navOffRouteSpoken){
                navOffRouteSpoken=true
                speakNavigation(navWord(7),"alpriders_off_route")
            }
            return
        }
        navOffRouteSpoken=false
        navLastProgress=maxOf(navLastProgress,progress.alongMeters)
        if(progress.remainingMeters<45){
            navDistanceText.text=navWord(8);navInstructionText.text=navWord(9)
            navInfoText.text=navWord(10)
            if(!navFinishSpoken){
                navSpeech?.stop();navFinishSpoken=true
                speakNavigation(navWord(11),"alpriders_arrive")
            }
            return
        }
        val next=RouteGuide.upcoming(routeTurns,navLastProgress)
        val metresToTurn=(next?.alongMeters?.minus(navLastProgress))?.coerceAtLeast(0.0)
        val turnText=if(next==null)navWord(12) else RouteGuide.instruction(next,lang)
        navDistanceText.text=if(metresToTurn==null) guidanceDistance(progress.remainingMeters) else guidanceDistance(metresToTurn)
        navInstructionText.text=turnText
        navInfoText.text="${navWord(13)} ${guidanceDistance(progress.remainingMeters)} · GPS experimental · CH"
        if(!navStartSpoken && navSpeechReady && navVoiceEnabled){
            navStartSpoken=true
            val firstMessage=if(next!=null && metresToTurn!=null)
                "${navWord(14)} ${navWord(15)} ${guidanceDistance(metresToTurn)}, $turnText"
                else "${navWord(14)} ${navWord(16)}"
            speakNavigation(firstMessage,"alpriders_started")
            // Do not immediately interrupt the opening announcement.
            navLastAlert=System.currentTimeMillis()
        }
        if(next!=null && metresToTurn!=null){
            val threshold=when {metresToTurn<80->"near";metresToTurn<300->"300";metresToTurn<700->"700";else->""}
            val key="${next.alongMeters.toInt()}:$threshold"
            if(threshold.isNotEmpty() && key!=navLastManeuver && System.currentTimeMillis()-navLastAlert>4500L){
                navLastManeuver=key;navLastAlert=System.currentTimeMillis()
                val message=if(threshold=="near")turnText else "${navWord(15)} ${guidanceDistance(metresToTurn)}, $turnText"
                speakNavigation(message,"alpriders_turn")
            }
        }
    }
    private fun rebuildTurnList(road:JSONObject?,line:List<LatLng>){
        if(!routeSwissVerified||line.size<2){routeTurns=emptyList();return}
        val turns=ArrayList<RouteGuide.Turn>()
        val steps=road?.optJSONArray("steps")?:run{routeTurns=emptyList();return}
        val path=line.map{RouteGuide.Point(it.latitude,it.longitude)}
        for(i in 0 until steps.length()){
            val st=steps.optJSONObject(i)?:continue
            val p=st.optJSONArray("p")?:continue
            if(p.length()<2)continue
            val point=RouteGuide.Point(p.optDouble(0),p.optDouble(1))
            val along=RouteGuide.progress(path,point)?.alongMeters?:continue
            turns.add(RouteGuide.Turn(point,st.optString("type"),st.optString("mod"),st.optString("name"),along))
        }
        routeTurns=turns.sortedBy{it.alongMeters}
    }

    private fun refreshControls() {
        if (!::actionRow.isInitialized) return
        actionRow.removeAllViews()
        val actions=listOf(
            tr(6) to { addingPoint=true;selectingStart=false;say(tr(13)) },
            tr(7) to { js("window.AlpNative&&AlpNative.calculate()") },
            tr(8) to { js("window.AlpNative&&AlpNative.save()") }
        )
        actions.forEachIndexed { i,p ->
            actionRow.addView(button(p.first, if (i==0) Color.rgb(27,74,76) else Color.rgb(31,55,68),Color.WHITE,p.second),
                LinearLayout.LayoutParams(0,-2,1f).apply{if(i>0)leftMargin=dp(6)})
        }
        if (::mapGpsButton.isInitialized) mapGpsButton.text=if(following)tr(10) else tr(9)
        if (::subtitle.isInitialized) subtitle.text=when {
            currentTab!="map" -> "${tr(tabKeys.indexOf(currentTab).coerceAtLeast(0))} · teste"
            currentRoute.isEmpty() -> tr(14)
            else -> "$routeSummary · ${routePoints.size} ${tr(12)} · teste"
        }
    }

    private fun makeWeb() {
        val loader=WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web=WebView(this).apply {
            setBackgroundColor(dark)
            settings.javaScriptEnabled=true
            settings.domStorageEnabled=true
            settings.setGeolocationEnabled(true)
            settings.allowFileAccess=false
            settings.allowContentAccess=false
            settings.mediaPlaybackRequiresUserGesture=true
            addJavascriptInterface(NativeBridge(),"AndroidBridge")
            webViewClient=object: WebViewClient() {
                override fun shouldInterceptRequest(view:WebView, request:WebResourceRequest) = loader.shouldInterceptRequest(request.url)
                override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest):Boolean {
                    val u=request.url
                    if(u.scheme=="tel" || u.scheme=="sms" || u.scheme=="mailto") {
                        try { startActivity(Intent(Intent.ACTION_VIEW,u)) } catch (_:Exception) {say("Sem aplicação para abrir esta ligação")}
                        return true
                    }
                    if(u.host=="appassets.androidplatform.net")return false
                    // External authentication and documentation links open outside app.
                    try {startActivity(Intent(Intent.ACTION_VIEW,u))}catch (_:Exception){}
                    return true
                }
                override fun onPageFinished(view:WebView,url:String) {
                    webReady=true
                    js("window.AlpNative&&AlpNative.language(${JSONObject.quote(lang)})")
                    js("window.AlpNative&&AlpNative.show('routes')")
                    js("window.AlpNative&&AlpNative.sync()")
                    safetyStatusToWeb(SafetyMonitorService.summary)
                }
            }
            webChromeClient=object:WebChromeClient(){
                override fun onGeolocationPermissionsShowPrompt(origin:String,callback:GeolocationPermissions.Callback) {
                    if (origin!="https://appassets.androidplatform.net") {callback.invoke(origin,false,false);return}
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) callback.invoke(origin,true,false)
                    else {webGeoOrigin=origin;webGeoCallback=callback;requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestGps)}
                }
            }
        }
        contentHolder.addView(web,FrameLayout.LayoutParams(-1,-1))
        web.visibility=View.GONE
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun makeNavigation() {
        bottom=LinearLayout(this).apply{ orientation=LinearLayout.HORIZONTAL;setPadding(dp(3),dp(3),dp(3),dp(3));setBackgroundColor(dark) }
        root.addView(bottom,LinearLayout.LayoutParams(-1,-2))
        rebuildNavigation()
    }
    private fun rebuildNavigation() {
        bottom.removeAllViews()
        tabKeys.forEachIndexed{ i,key ->
            val active=key==currentTab
            val label=label("${tabSymbols[i]}\n${tr(i)}",12f,if(active)orange else muted,if(active)Typeface.BOLD else Typeface.NORMAL).apply {
                gravity=Gravity.CENTER; setPadding(0,dp(4),0,dp(4))
                setOnClickListener{showTab(key)}
            }
            bottom.addView(label,LinearLayout.LayoutParams(0,dp(56),1f))
        }
    }
    private fun showTab(key:String) {
        currentTab=key
        val isMap=key=="map"
        mapHolder.visibility=if(isMap)View.VISIBLE else View.GONE
        web.visibility=if(isMap)View.GONE else View.VISIBLE
        if (!isMap) {
            js("window.AlpNative&&AlpNative.show(${JSONObject.quote(key)})")
            if (key=="sos") safetyStatusToWeb(SafetyMonitorService.summary)
        }
        else mapView.postDelayed({ map?.let { m-> if(mapReady) {m.cameraPosition=m.cameraPosition} } },160)
        if(::bottom.isInitialized)rebuildNavigation()
        if(::subtitle.isInitialized)refreshControls()
    }

    private fun chooseLanguage() {
        AlertDialog.Builder(this).setTitle("Idioma / Language").setItems(localeNames){_,i ->
            lang=localeCodes[i];prefs.edit().putString("lang",lang).apply()
            languageButton.text=localeNames[i]
            configureSpeechLanguage()
            navStartSpoken=false;navLastManeuver=""
            refreshControls();rebuildNavigation()
            if(navActive)lastLocation?.let{updateNavigation(it)}
            js("window.AlpNative&&AlpNative.language(${JSONObject.quote(lang)})")
        }.show()
    }

    // IMPORTANT: Waze Deep Links specify just ONE destination.
    // Passing the final point of a round trip would take the rider straight home.
    // Select the next waypoint manually WHILE STOPPED; Waze may recalculate via France.
    private fun wazeText(pt:String, en:String) = if(lang=="pt")pt else en

    private fun showWazeChooser() {
        if(!routeSwissVerified || routePoints.size < 2) {
            AlertDialog.Builder(this)
                .setTitle("Waze")
                .setMessage(wazeText("Calcula primeiro uma estrada dentro da Suíça no separador Rotas. O Waze precisa de um destino real, não de uma linha de teste.",
                    "First calculate a road route within Switzerland in Routes. Waze needs a real destination."))
                .setPositiveButton("OK",null).show()
            return
        }
        val coordinates=routePoints.map { it.latitude to it.longitude }
        val destinations=WazeNavigation.destinations(coordinates)
        if(destinations.isEmpty()) {say("Percurso sem destino");return}
        val descriptions=destinations.map { stop ->
            val name=when {
                stop.isReturn -> wazeText("Regresso à partida", "Return to start")
                stop.isFinal -> wazeText("Destino", "Destination")
                else -> wazeText("Ponto de passagem", "Waypoint")
            }
            "${stop.stage}. $name (${String.format(Locale.US,"%.4f, %.4f",stop.latitude,stop.longitude)})"
        }.toTypedArray()
        // Do not combine setMessage() and setItems() in one Android dialog:
        // a message can suppress the selectable list on some devices.
        // The full road-safety warning is shown in the confirmation dialog.
        AlertDialog.Builder(this)
            .setTitle(wazeText("Escolher etapa no Waze (mota parada)", "Choose Waze waypoint (while stopped)"))
            .setItems(descriptions) { _,which ->
                val stop=destinations[which]
                confirmWazeDeparture(stop)
            }
            .setNegativeButton(wazeText("Cancelar", "Cancel"),null)
            .show()
    }

    private fun confirmWazeDeparture(stop:WazeNavigation.Stop) {
        AlertDialog.Builder(this)
            .setTitle(wazeText("Abrir navegação Waze?", "Open Waze navigation?"))
            .setMessage(wazeText(
                "O Waze pode escolher outra estrada ou atravessar uma fronteira. Confirma no Waze que o trajeto fica na Suíça, que está aberto e é adequado à mota. Não alteres destinos a conduzir.",
                "Waze may pick a different road or cross a border. In Waze, check that the route stays in Switzerland, is open, and is motorcycle-appropriate. Do not change destinations while riding."))
            .setNegativeButton(wazeText("Voltar", "Back"),null)
            .setPositiveButton(wazeText("Abrir Waze", "Open Waze")) { _,_ -> openWaze(stop.latitude,stop.longitude) }
            .show()
    }

    private fun openWaze(lat:Double,lon:Double) {
        val url=WazeNavigation.link(lat,lon) ?: run {say("Destino inválido");return}
        val officialHttps = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.waze")
        val customScheme = Intent(Intent.ACTION_VIEW, Uri.parse(url.replace("https://waze.com/ul", "waze://"))).setPackage("com.waze")
        try {
            startActivity(officialHttps)
            return
        } catch (_:Exception) {
            // Some Waze versions register only the waze:// URI for deep links.
            try { startActivity(customScheme); return } catch (_:Exception) { }
            AlertDialog.Builder(this)
                .setTitle("Waze")
                .setMessage(wazeText("Não foi possível abrir o Waze. Instala-o no Samsung para navegar.",
                    "Could not open Waze. Install it on your phone to navigate."))
                .setNegativeButton(wazeText("Cancelar", "Cancel"),null)
                .setPositiveButton(wazeText("Instalar Waze", "Install Waze")) { _,_ ->
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.waze"))) }
                    catch (_:Exception) {say("Não foi possível abrir a loja")}
                }.show()
        }
    }

    private fun onMapTap(position:LatLng) {
        if(selectingStart) {
            selectingStart=false
            js("window.AlpNative&&AlpNative.selectPin(${position.latitude},${position.longitude})")
            showTab("routes")
            js("window.AlpNative&&AlpNative.planner()")
            return
        }
        if(addingPoint) {
            addingPoint=false
            js("window.AlpNative&&AlpNative.addPoint(${position.latitude},${position.longitude})")
        }
    }

    private fun redrawRoute() {
        val m=map?:return
        if(!mapReady)return
        m.clear();gpsMarker=null;departureMarker=null
        if(currentRoute.size>1) {
            m.addPolyline(PolylineOptions().addAll(currentRoute).color(orange).width(7f))
        }
        val closesLoop=routePoints.size>=3 &&
            kotlin.math.abs(routePoints.first().latitude-routePoints.last().latitude)<0.0001 &&
            kotlin.math.abs(routePoints.first().longitude-routePoints.last().longitude)<0.0001
        routePoints.forEachIndexed { i,p ->
            if(closesLoop && i==routePoints.lastIndex)return@forEachIndexed
            if (i==0 || i==routePoints.lastIndex || i%3==0) {
                val title=when {
                    i==0 && closesLoop -> "Partida e regresso"
                    i==0 -> "Partida"
                    i==routePoints.lastIndex -> "Chegada"
                    else -> "Ponto ${i+1}"
                }
                val marker=MarkerOptions().position(p).title(title)
                if(i==0){
                    if(startBikeIcon==null)startBikeIcon=motorcycleIcon(orange)
                    marker.icon(startBikeIcon)
                    if(!navActive)departureMarker=m.addMarker(marker)
                }else m.addMarker(marker)
            }
        }
        lastLocation?.let {updateMarker(it)}
        if(currentRoute.size>=2) {
            try {
                val bounds=LatLngBounds.Builder().includes(currentRoute).build()
                m.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds,dp(52)),650)
            } catch (_:Exception) {m.animateCamera(CameraUpdateFactory.newLatLngZoom(currentRoute[0],12.0))}
        }
    }

    private fun hasGpsPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED

    private fun requestWebLocation(requestId:Int) {
        if (requestId !in pendingWebPositions) pendingWebPositions.add(requestId)
        if (!hasGpsPermission()) {
            if (!pendingGpsStart && !locationRequestActive && pendingWebPositions.size == 1) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestGps)
            }
        } else if (!locationRequestActive) {
            requestFreshWebLocation()
        }
    }

    private fun requestFreshWebLocation() {
        if (pendingWebPositions.isEmpty() || locationRequestActive) return
        if (!hasGpsPermission()) {finishWebLocation(null,"permission");return}
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        locationManager=lm
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
        // Indoors a network fix may arrive faster than GPS; register both if available.
        val providers=ArrayList<String>()
        if (fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) providers.add(LocationManager.GPS_PROVIDER)
        if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) providers.add(LocationManager.NETWORK_PROVIDER)
        if(providers.isEmpty()){finishWebLocation(null,"disabled");return}
        locationRequestActive=true
        singleFixListener=object:LocationListener {
            override fun onLocationChanged(location:Location) {
                finishWebLocation(location, "")
            }
        }
        try {
            providers.forEach { provider ->
                lm.requestLocationUpdates(provider, 0L, 0f, singleFixListener!!, Looper.getMainLooper())
            }
            uiHandler.postDelayed(singleFixTimeout,16000)
        } catch (_:SecurityException){finishWebLocation(null,"permission")}
          catch (_:Exception){finishWebLocation(null,"unavailable")}
    }

    private fun finishWebLocation(fix:Location?, reason:String) {
        singleFixListener?.let {locationManager?.removeUpdates(it)}
        singleFixListener=null
        uiHandler.removeCallbacks(singleFixTimeout)
        locationRequestActive=false
        val ids=pendingWebPositions.toList(); pendingWebPositions.clear()
        if (fix!=null) {
            lastLocation=fix
            val coords=JSONObject()
              .put("latitude",fix.latitude)
              .put("longitude",fix.longitude)
              .put("accuracy",fix.accuracy.toDouble())
              .put("speed",if(fix.hasSpeed())fix.speed.toDouble() else JSONObject.NULL)
              .put("heading",if(fix.hasBearing())fix.bearing.toDouble() else JSONObject.NULL)
            val position=JSONObject().put("coords",coords).put("timestamp",System.currentTimeMillis())
            ids.forEach { id -> js("window.AlpNative&&AlpNative.nativeLocationResult($id,${position})") }
        } else {
            ids.forEach { id -> js("window.AlpNative&&AlpNative.nativeLocationError($id,${JSONObject.quote(reason)})") }
        }
    }

    private inner class NativeBridge {
        @JavascriptInterface fun startSafetyMonitor() {runOnUiThread {beginManualSafetyMonitor()}}
        @JavascriptInterface fun stopSafetyMonitor() {runOnUiThread {safetyAction(SafetyMonitorService.ACTION_STOP)}}
        @JavascriptInterface fun testSafetyAlarm() {runOnUiThread {showTestAlarm()}}
        @JavascriptInterface fun cancelSafetyAlarm() {runOnUiThread {clearTestAlarm();safetyAction(SafetyMonitorService.ACTION_CANCEL)}}
        @JavascriptInterface fun safetyHelp() {runOnUiThread {showTab("sos")}}
        @JavascriptInterface fun requestLocation(requestId:Int) {runOnUiThread {requestWebLocation(requestId)}}
        @JavascriptInterface fun copyText(text:String) {runOnUiThread {
            val clipboard=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("AlpRiders CH",text))
            say("Mensagem copiada")
        }}
        @JavascriptInterface fun shareText(text:String) {runOnUiThread {
            val intent=Intent(Intent.ACTION_SEND).apply {
                type="text/plain"
                putExtra(Intent.EXTRA_TEXT,text)
            }
            try {startActivity(Intent.createChooser(intent,"Partilhar localização SOS"))}
            catch (_:Exception) {say("Não foi possível partilhar")}
        }}
        /** Opens a prefilled one-to-one chat; never dispatches the message automatically. */
        @JavascriptInterface fun openWhatsApp(phone:String, message:String) {runOnUiThread {
            if(!phone.matches(Regex("[1-9][0-9]{7,14}"))){say("Número inválido: usa o indicativo +41");return@runOnUiThread}
            val link=Uri.parse("https://wa.me/$phone?text=${Uri.encode(message)}")
            var launched=false
            for(pkg in listOf("com.whatsapp","com.whatsapp.w4b")){
                try {startActivity(Intent(Intent.ACTION_VIEW,link).setPackage(pkg));launched=true;break}
                catch (_:Exception){}
            }
            if(!launched){
                try {startActivity(Intent(Intent.ACTION_VIEW,link));launched=true}
                catch (_:Exception){}
            }
            if(!launched)say("WhatsApp indisponível; instala-o ou utiliza a partilha manual")
        }}
        @JavascriptInterface fun openMap() {runOnUiThread {showTab("map")}}
        @JavascriptInterface fun navigateWaze() {runOnUiThread {showWazeChooser()}}
        @JavascriptInterface fun startNativeNavigation() {runOnUiThread {showTab("map");requestStartNavigation()}}
        @JavascriptInterface fun chooseStartPin() {runOnUiThread {
            selectingStart=true;addingPoint=false;showTab("map");say(tr(13))
        }}
        @JavascriptInterface fun languageChanged(code:String) {runOnUiThread {
            if(code in localeCodes && lang!=code) {
                lang=code;prefs.edit().putString("lang",lang).apply()
                languageButton.text=localeNames[localeCodes.indexOf(code)]
                configureSpeechLanguage()
                navStartSpoken=false;navLastManeuver=""
                refreshControls();rebuildNavigation()
                if(navActive)lastLocation?.let{updateNavigation(it)}
            }
        }}
        @JavascriptInterface fun onRouteChange(json:String) {runOnUiThread {
            try {
                val obj=JSONObject(json)
                routePoints=readCoords(obj.optJSONArray("points"))
                val road=obj.optJSONObject("road")
                val line=readCoords(road?.optJSONArray("geometry"))
                // No Waze handoff for a mere straight-line preview or unverified route.
                routeSwissVerified=road?.optBoolean("swissVerified",false)==true && line.size>=2
                if(navActive)stopNativeNavigation()
                currentRoute=if(line.isNotEmpty())line else routePoints
                rebuildTurnList(road,line)
                routeSummary=if(road!=null)"${road.optString("distance")} km · ${road.optString("duration")} min" else "${routePoints.size} ${tr(12)}"
                if(mapReady)redrawRoute()
                refreshControls()
            } catch (_:Exception) { say("Não foi possível apresentar este percurso") }
        }}
        @JavascriptInterface fun exportGPX(name:String,geoJson:String) {runOnUiThread {
            try {
                val coords=readCoords(JSONArray(geoJson))
                if(coords.size<2) {say("Precisas de pelo menos dois pontos");return@runOnUiThread}
                val xml=StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><gpx version=\"1.1\" creator=\"AlpRiders CH\" xmlns=\"http://www.topografix.com/GPX/1/1\"><trk><name>")
                xml.append(name.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"))
                xml.append("</name><trkseg>")
                coords.forEach{xml.append("<trkpt lat=\"").append(it.latitude).append("\" lon=\"").append(it.longitude).append("\"/>")}
                xml.append("</trkseg></trk></gpx>")
                gpxPending=xml.toString()
                val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{
                    addCategory(Intent.CATEGORY_OPENABLE);type="application/gpx+xml"
                    putExtra(Intent.EXTRA_TITLE,"AlpRiders_CH.gpx")
                }
                startActivityForResult(intent,requestExport)
            } catch (_:Exception) {say("Não foi possível exportar GPX")}
        }}
    }
    private fun readCoords(array:JSONArray?):List<LatLng> {
        if(array==null) return emptyList()
        val result=ArrayList<LatLng>()
        val increment=if(array.length()>2500)array.length()/2500+1 else 1
        for(i in 0 until array.length() step increment) {
            val p=array.optJSONArray(i)?:continue
            if(p.length()>=2){val a=p.optDouble(0);val b=p.optDouble(1)
                if(a in -90.0..90.0 && b in -180.0..180.0)result.add(LatLng(a,b))}
        }
        if(increment>1 && array.length()>0){val last=array.optJSONArray(array.length()-1);if(last!=null)result.add(LatLng(last.optDouble(0),last.optDouble(1)))}
        return result
    }

    private fun toggleGps() {
        if(following) {
            if(navActive)stopNativeNavigation()
            following=false;locationManager?.removeUpdates(this)
            subtitle.text=tr(14);refreshControls()
        } else if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            pendingGpsStart=true
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),requestGps)
        } else startGps()
    }
    private fun startGps() {
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return
        val lm=getSystemService(Context.LOCATION_SERVICE) as LocationManager
        locationManager=lm
        if(!lm.isProviderEnabled(LocationManager.GPS_PROVIDER) && !lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){
            say("Ativa a localização nas definições do Samsung");return
        }
        following=true;refreshControls()
        try {
            if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1100L,2f,this)
            if(lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,2500L,5f,this)
            (lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?:lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER))?.let{onLocationChanged(it)}
            // A GPS ride can also recover a monitor stopped by the system,
            // but only if the rider opted into automatic safety monitoring.
            if (prefs.getBoolean("safety_auto_enabled", false) && !SafetyMonitorService.running) {
                safetyAutoAttempted = true
                startSafetyMonitor()
            }
        }catch (_:SecurityException){following=false;refreshControls()}
    }
    override fun onLocationChanged(location:Location) {
        if(lastLocation==null || location.accuracy<=lastLocation!!.accuracy+25 || location.time>lastLocation!!.time+2500)lastLocation=location
        val accepted=lastLocation?:location
        speed.text=if(accepted.hasSpeed())"${(accepted.speed*3.6).toInt().coerceAtLeast(0)}" else "—"
        updateMarker(accepted)
        if(navPending && System.currentTimeMillis()-accepted.time < 30_000L)beginNativeNavigation(accepted)
        if(navActive){updateNavigation(accepted);return}
        if(following && currentTab=="map"){
            val m=map?:return
            val bearing=if(accepted.hasBearing()&&accepted.speed>2)accepted.bearing.toDouble() else m.cameraPosition.bearing
            m.animateCamera(CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder().target(LatLng(accepted.latitude,accepted.longitude)).zoom(16.0).bearing(bearing).tilt(35.0).build()
            ),700)
        }
    }
    private fun updateMarker(location:Location) {
        val m=map?:return
        if(!mapReady)return
        val pos=LatLng(location.latitude,location.longitude)
        if(gpsBikeIcon==null)gpsBikeIcon=motorcycleIcon(teal)
        if(gpsMarker==null)gpsMarker=m.addMarker(MarkerOptions().position(pos)
            .title("Mota · GPS (${location.accuracy.toInt()} m)").icon(gpsBikeIcon))
        else gpsMarker?.position=pos
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if (requestCode==requestSafetyLocation) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) startSafetyMonitor()
            else say("O monitor precisa de localização precisa autorizada.")
            return
        }
        if (requestCode==requestSafetyNotifications) {
            if (grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED) startSafetyMonitor()
            else say("Notificações necessárias para avisos do monitor. Não foi iniciado.")
            return
        }
        if(requestCode!=requestGps)return
        val granted=hasGpsPermission()
        webGeoCallback?.invoke(webGeoOrigin,granted,false)
        webGeoCallback=null;webGeoOrigin=null
        val startFollowing=pendingGpsStart
        pendingGpsStart=false
        if(granted){
            if(startFollowing || navPending)startGps()
            if(pendingWebPositions.isNotEmpty())requestFreshWebLocation()
        } else {
            if(pendingWebPositions.isNotEmpty())finishWebLocation(null,"permission")
            say("Permite a localização à AlpRiders CH nas definições do Android")
        }
    }
    @Deprecated("Android callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==requestExport && resultCode==RESULT_OK){
            val uri=data?.data;val xml=gpxPending
            if(uri!=null && xml!=null){
                try {contentResolver.openOutputStream(uri)?.use{stream->OutputStreamWriter(stream,Charsets.UTF_8).use{it.write(xml)}};say("GPX exportado")}
                catch (_:Exception){say("Falha ao guardar GPX")}
            }
            gpxPending=null
        }
    }
    @Deprecated("Navigation")
    override fun onBackPressed(){
        if(navActive)stopNativeNavigation()
        else if(currentTab!="map")showTab("map")
        else super.onBackPressed()
    }
    override fun onStart(){super.onStart();mapView.onStart();SafetyMonitorService.observer={ msg ->runOnUiThread{safetyStatusToWeb(msg)}};if(following)startGps()}
    override fun onResume(){
        super.onResume();mapView.onResume();web.onResume()
        // Foreground app lifecycle: restart only after prior explicit opt-in.
        // No BOOT_COMPLETED receiver, no background auto-launch after Android kills the service.
        if (!safetyAutoAttempted && prefs.getBoolean("safety_auto_enabled", false)) {
            safetyAutoAttempted = true
            root.post { if (!isFinishing) startSafetyMonitor() }
        }
    }
    override fun onPause(){web.onPause();mapView.onPause();super.onPause()}
    override fun onStop(){locationManager?.removeUpdates(this);SafetyMonitorService.observer=null;mapView.onStop();super.onStop()}
    override fun onLowMemory(){super.onLowMemory();mapView.onLowMemory()}
    override fun onDestroy(){
        clearTestAlarm()
        detectedIncidentDialog?.dismiss()
        detectedIncidentDialog = null
        singleFixListener?.let {locationManager?.removeUpdates(it)}
        uiHandler.removeCallbacks(singleFixTimeout)
        locationManager?.removeUpdates(this)
        navSpeech?.stop();navSpeech?.shutdown()
        mapView.onDestroy();web.destroy();super.onDestroy()
    }
    override fun onSaveInstanceState(outState:Bundle){mapView.onSaveInstanceState(outState);super.onSaveInstanceState(outState)}
}
