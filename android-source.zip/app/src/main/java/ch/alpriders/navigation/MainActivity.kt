package ch.alpriders.navigation

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap

/** Primeiro APK para testar apenas o mapa vetorial e a posição GPS.
 *  Não contém cálculo de rotas, voz, navegação automóvel ou funcionamento em segundo plano.
 */
class MainActivity : Activity(), LocationListener {
    private lateinit var mapView: MapView
    private var map: MapLibreMap? = null
    private var locationManager: LocationManager? = null
    private var positionMarker: Marker? = null
    private var following = false
    private var lastPosition: Location? = null
    private lateinit var statusText: TextView
    private lateinit var gpsButton: TextView
    private lateinit var speedText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 25, 35)
        window.navigationBarColor = Color.rgb(7, 25, 35)
        MapLibre.getInstance(this)
        mapView = MapView(this)
        mapView.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.addView(mapView, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(15))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(8, 28, 41), Color.rgb(22, 48, 61)))
        }
        val brand = text("🏍 AlpRiders CH", 22f, Color.WHITE, Typeface.BOLD)
        statusText = text("Mapa vetorial · modo de teste", 13f, Color.rgb(180, 220, 220), Typeface.NORMAL)
        header.addView(brand)
        header.addView(statusText)
        root.addView(header, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(20))
            setBackgroundColor(Color.rgb(8, 28, 41))
        }
        gpsButton = text("📍 Ligar GPS", 17f, Color.rgb(15, 27, 35), Typeface.BOLD).apply {
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(255, 165, 86))
            setPadding(dp(12), dp(15), dp(12), dp(15))
            setOnClickListener { toggleGPS() }
        }
        footer.addView(gpsButton, LinearLayout.LayoutParams(0, -2, 1f))

        speedText = text("—\nkm/h", 18f, Color.WHITE, Typeface.BOLD).apply {
            gravity = Gravity.CENTER
        }
        footer.addView(speedText, LinearLayout.LayoutParams(dp(110), -2))
        root.addView(footer, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        mapView.getMapAsync { m ->
            map = m
            m.cameraPosition = CameraPosition.Builder()
                .target(LatLng(46.82, 8.25)).zoom(7.2).build()
            m.setStyle("https://tiles.openfreemap.org/styles/liberty") {
                statusText.text = "Mapa carregado · toca em Ligar GPS"
                lastPosition?.let { updateMap(it) }
            }
        }
    }

    private fun text(value: String, size: Float, color: Int, weight: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setTypeface(Typeface.DEFAULT, weight)
        }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(14).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toggleGPS() {
        if (following) {
            following = false
            locationManager?.removeUpdates(this)
            gpsButton.text = "📍 Ligar GPS"
            statusText.text = "GPS parado · mapa para consulta"
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 101)
        } else startGPS()
    }

    private fun startGPS() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        locationManager = lm
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "Ativa a localização GPS do Samsung", Toast.LENGTH_LONG).show()
            return
        }
        following = true
        gpsButton.text = "⏹ Parar GPS"
        statusText.text = "A aguardar posição GPS…"
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1200L, 2f, this)
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocationChanged(it) }
        } catch (e: SecurityException) {
            following = false
            gpsButton.text = "📍 Ligar GPS"
            statusText.text = "Autorização GPS necessária"
        }
    }

    override fun onLocationChanged(location: Location) {
        lastPosition = location
        if (!following) return
        val speed = if (location.hasSpeed()) (location.speed * 3.6f).toInt().coerceAtLeast(0) else null
        speedText.text = (speed?.toString() ?: "—") + "\nkm/h"
        statusText.text = "GPS ativo · precisão ±${location.accuracy.toInt()} m"
        updateMap(location)
    }

    private fun updateMap(location: Location) {
        val m = map ?: return
        val p = LatLng(location.latitude, location.longitude)
        if (positionMarker == null) {
            positionMarker = m.addMarker(MarkerOptions().position(p).title("A tua posição"))
        } else {
            positionMarker?.position = p
        }
        if (!following) return
        val bearing = if (location.hasBearing()) location.bearing.toDouble() else m.cameraPosition.bearing
        val camera = CameraPosition.Builder()
            .target(p).zoom(16.3).bearing(bearing).tilt(40.0).build()
        m.animateCamera(CameraUpdateFactory.newCameraPosition(camera), 650)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startGPS()
        else if (requestCode == 101) statusText.text = "Sem permissão para localização"
    }

    override fun onStart() { super.onStart(); mapView.onStart(); if (following) startGPS() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() {
        locationManager?.removeUpdates(this)
        mapView.onStop()
        super.onStop()
    }
    override fun onDestroy() { mapView.onDestroy(); super.onDestroy() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onSaveInstanceState(outState: Bundle) { mapView.onSaveInstanceState(outState); super.onSaveInstanceState(outState) }
}
