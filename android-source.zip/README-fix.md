# AlpRiders CH v0.21.1 — Correção de ecrãs vazios

## Causa confirmada

Na v0.21, `translatePage()` chamava `updateBorderInfo()` dentro do observador MutationObserver de textos. A implementação alterava o `textContent` mesmo quando a string era idêntica; isso voltava a ativar o observador numa sequência contínua de microtarefas, bloqueando a WebView e deixando Rotas, Grupos, Perfil e SOS em branco.

## Correção

* `updateBorderInfo()` só escreve no DOM se o novo texto for diferente.
* A informação das fronteiras é atualizada uma vez na inicialização e quando o idioma ou os países escolhidos mudam, não em cada mutação.
* Mantidas as funções e motor Valhalla da v0.21.
* Novo ID de teste `ch.alpriders.navigation.test21fix`, para não substituir apps assinadas com certificados debug anteriores nem perder dados.

## Validação

* HTML/JavaScript testados no Chromium em execução simulada da WebView, com bridge Android simulada. Todos os separadores renderizam conteúdo; testes com França ativada e idioma francês passaram.
* Testes JavaScript de rotas e fronteiras a executar antes da entrega.
* Compilação Android e teste físico no Samsung continuam pendentes; a app não é GPS certificado.
