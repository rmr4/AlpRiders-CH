AlpRiders CH v0.17 — testes adicionais para circuito em Genebra.

A app tenta alternativas do motor OSRM, diversifica os pontos de passagem e, em poucas tentativas, calcula cada troço separadamente quando o percurso inicial atravessa uma fronteira. Todos os troços continuam sujeitos à verificação da fronteira suíça. O modo experimental não garante criação de circuito, nem conhece estradas cortadas. Se falhar, existe botão para abrir o mapa sem navegação.

Testes: `node tests/v17-recovery.test.cjs`; `node tests/swiss-only.test.cjs`; testes de regressão adicionais.
