# AlpRiders CH v0.15 — Circuitos alternativos e desvios experimentais

**Estado:** versão de teste. Atualização do código; APK Android ainda por compilar e validar no Samsung.

## Correção da imagem enviada

Na v0.14, o planeador interrompia a geração de circuitos quando não encontrava dois pontos panorâmicos predefinidos num raio limitado. Na v0.15, continua a procurar circuitos por vias alternativas com pontos virtuais no interior da Suíça, mesmo sem pontos turísticos próximos. **Esses pontos são candidatos**, não rotas garantidas: só são aceites se o OSRM calcular estradas reais, a fronteira inteira for verificada e a estrada de regresso não tiver mais de 12% de sobreposição geométrica aproximada. A duração desejada não é garantida. Se não for possível, informa o utilizador. Se for necessário deixar o estilo escolhido, o aviso diz que gerou uma alternativa genérica.

## Durante a navegação

- **Recálculo automático experimental** quando o GPS, com precisão <= 35 m, se mantém a mais de 120 m da rota por 18 segundos. Limite de uma tentativa automática a cada 2 minutos, sem descarregar dados continuamente.
- **Botão «⛔ Desvio»** no navegador. Se a mota estiver parada, o utilizador pode indicar um possível bloqueio da estrada, que leva a procurar outra rota sem esperar pelo desvio GPS.
- Os candidatos são calculados através de estradas reais do OSRM, incluindo possíveis pontos intermédios a diferentes distâncias laterais. Não são aceites se regressarem a uma **zona aproximada de 260 m de raio à volta de três pontos da estrada anterior**, situados a ~400, ~650 e ~900 m da última posição confirmada ao longo da rota. Também precisam passar as mesmas verificações da Suíça.
- Os pontos de passagem futuros que for possível localizar no circuito são preservados para que o trajeto não se reduza automaticamente a um caminho direto para casa. O circuito original não pode continuar a ser apresentado como se fosse idêntico após o desvio.
- Em falha, a rota antiga permanece e a interface avisa para parar em segurança. O novo cálculo só é aplicado à navegação se houver um traçado aceite.

## Limitações importantes

Esta versão **não deteta automaticamente obras, encerramentos ou acidentes**, não tem trânsito em tempo real, não valida abertura legal de passagens e não assegura que não se utilize nenhum troço da estrada anteriormente percorrida. Evita apenas o corredor geográfico suspeito da estrada à frente, sem garantia sobre outros bloqueios. A API pública OSRM usada na aplicação calcula rotas para automóveis e não recebe um parâmetro para excluir um troço rodoviário arbitrário identificado pelo utilizador. O serviço pode falhar, recusar pedidos ou gerar alternativas insuficientes. Uma integração futura com as ocorrências oficiais da rede rodoviária suíça implicaria backend, tratamento de dados DATEX II e chave de acesso ao serviço (Open Transport Data Switzerland).

**Não utilizar como único GPS durante a condução. Não manipular a aplicação em andamento.**

## Instalação e dados

Pacote Android de testes com identificador `ch.alpriders.navigation.test15`, distinto dos anteriores. Não migra automaticamente contas Supabase, chats ou rotas guardadas em outras instalações.

O GitHub Actions deverá receber o novo `android-source.zip` para compilar um APK; não considerar compilação concluída até ser verificada. Execute os testes localizados em `tests/` para confirmar sintaxe, condições de fronteira, rejeição de repetição de estrada e funções de desvio.
