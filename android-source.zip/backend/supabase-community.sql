-- ALPRIDERS CH: schema for public + private chat.
-- Run once in Supabase SQL editor (or through the connected Supabase app).
-- Never put service_role keys in the mobile application.
create extension if not exists pgcrypto;

create table if not exists public.rider_public_messages (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references auth.users(id) on delete cascade,
 sender_name text not null check(char_length(sender_name) between 1 and 32),
 body text not null check(char_length(btrim(body)) between 1 and 1000),
 created_at timestamptz not null default now()
);
create index if not exists rider_public_messages_recent on public.rider_public_messages(created_at desc);
create index if not exists rider_public_messages_sender on public.rider_public_messages(sender_id,created_at desc);
alter table public.rider_public_messages enable row level security;
drop policy if exists "public read authenticated" on public.rider_public_messages;
create policy "public read authenticated" on public.rider_public_messages for select to authenticated using (true);
drop policy if exists "public send as self" on public.rider_public_messages;
create policy "public send as self" on public.rider_public_messages for insert to authenticated
 with check (sender_id = (select auth.uid()));

-- Basic anti-spam protection. This is not a moderation system.
create or replace function public.limit_rider_public_post() returns trigger
language plpgsql security definer set search_path=public as $$
begin
 if exists (select 1 from public.rider_public_messages
            where sender_id=new.sender_id and created_at>now()-interval '5 seconds') then
   raise exception 'Aguarda 5 segundos antes de enviar outra mensagem';
 end if;
 return new;
end; $$;
drop trigger if exists tr_rider_public_post_limit on public.rider_public_messages;
create trigger tr_rider_public_post_limit before insert on public.rider_public_messages
 for each row execute function public.limit_rider_public_post();

create table if not exists public.rider_groups (
 id uuid primary key default gen_random_uuid(),
 name text not null check(char_length(btrim(name)) between 3 and 50),
 description text not null default '' check(char_length(description)<=240),
 invite_code text not null unique check(char_length(invite_code)=24),
 created_by uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.rider_group_members (
 group_id uuid not null references public.rider_groups(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null default 'member' check(role in ('admin','member')),
 created_at timestamptz not null default now(),
 primary key(group_id,user_id)
);
create table if not exists public.rider_group_messages (
 id uuid primary key default gen_random_uuid(),
 group_id uuid not null references public.rider_groups(id) on delete cascade,
 sender_id uuid not null references auth.users(id) on delete cascade,
 sender_name text not null check(char_length(sender_name) between 1 and 32),
 body text not null check(char_length(btrim(body)) between 1 and 1000),
 created_at timestamptz not null default now()
);
create index if not exists rider_group_messages_recent on public.rider_group_messages(group_id,created_at desc);
-- SECURITY DEFINER avoids recursive membership policies.
create or replace function public.is_rider_group_member(check_group uuid) returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.rider_group_members
               where group_id=check_group and user_id=(select auth.uid()));
$$;
revoke all on function public.is_rider_group_member(uuid) from public;
grant execute on function public.is_rider_group_member(uuid) to authenticated;

alter table public.rider_groups enable row level security;
alter table public.rider_group_members enable row level security;
alter table public.rider_group_messages enable row level security;
drop policy if exists "groups private read" on public.rider_groups;
create policy "groups private read" on public.rider_groups for select to authenticated
 using (created_by=(select auth.uid()) or public.is_rider_group_member(id));
drop policy if exists "groups create own" on public.rider_groups;
create policy "groups create own" on public.rider_groups for insert to authenticated
 with check (created_by=(select auth.uid()));
drop policy if exists "groups owner delete" on public.rider_groups;
create policy "groups owner delete" on public.rider_groups for delete to authenticated
 using (created_by=(select auth.uid()));
drop policy if exists "member read own" on public.rider_group_members;
create policy "member read own" on public.rider_group_members for select to authenticated
 using (user_id=(select auth.uid()));
drop policy if exists "creator enroll self" on public.rider_group_members;
create policy "creator enroll self" on public.rider_group_members for insert to authenticated
 with check(user_id=(select auth.uid()) and role='admin' and exists (
 select 1 from public.rider_groups where id=group_id and created_by=(select auth.uid())));
drop policy if exists "member leave own" on public.rider_group_members;
create policy "member leave own" on public.rider_group_members for delete to authenticated
 using(user_id=(select auth.uid()) and role='member');
drop policy if exists "group messages private read" on public.rider_group_messages;
create policy "group messages private read" on public.rider_group_messages for select to authenticated
 using(public.is_rider_group_member(group_id));
drop policy if exists "group messages private send" on public.rider_group_messages;
create policy "group messages private send" on public.rider_group_messages for insert to authenticated
 with check(sender_id=(select auth.uid()) and public.is_rider_group_member(group_id));

-- Invite lookup must be server-side; never expose membership by code in a public SELECT.
create or replace function public.join_rider_group(code_input text) returns uuid
language plpgsql security definer set search_path=public as $$
declare gid uuid;
begin
 if auth.uid() is null then raise exception 'Autenticação necessária'; end if;
 select id into gid from public.rider_groups where invite_code=upper(btrim(code_input));
 if gid is null then raise exception 'Convite inválido';end if;
 insert into public.rider_group_members(group_id,user_id,role)
 values(gid,auth.uid(),'member') on conflict(group_id,user_id) do nothing;
 return gid;
end;$$;
revoke all on function public.join_rider_group(text) from public;
grant execute on function public.join_rider_group(text) to authenticated;

grant select,insert on public.rider_public_messages to authenticated;
grant select,insert,delete on public.rider_groups to authenticated;
grant select,insert,delete on public.rider_group_members to authenticated;
grant select,insert on public.rider_group_messages to authenticated;

-- Realtime publications (ignore already-added tables).
do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='rider_public_messages') then
  alter publication supabase_realtime add table public.rider_public_messages;
 end if;
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='rider_group_messages') then
  alter publication supabase_realtime add table public.rider_group_messages;
 end if;
end;$$;
