from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/index.html').read_text()
bridge=(root/'app/src/main/assets/native-bridge.js').read_text()
main=(root/'app/src/main/java/ch/alpriders/navigation/MainActivity.kt').read_text()
guide=(root/'app/src/main/java/ch/alpriders/navigation/RouteGuide.kt').read_text()
assert 'Rota só de ida por endereço' in html
assert 'findExactSwissAddress' in html and 'swissAddressInput.addEventListener' in html
assert "road={...result,roundTrip:false}" in html
assert "$('round-trip').checked=false" in html
assert 'window.AndroidBridge.chooseStartPin()' in html
assert "routePage.insertBefore(oneWay" in bridge
assert 'style===\'mix\'' in html and 'style===\'mix\')' in html
for key in ['passos','aldeias','vinhas','florestas','cidades']:
 assert '<option value="'+key+'">' in html
 assert re.search(r"k:\[[^\]]*'"+key+r"'",html), key
assert 'setShadowLayer' in main and 'drawText("🏍️"' in main
assert 'c.drawCircle' not in main[main.index('private fun motorcycleIcon'):main.index('private fun navigationZoom')]
assert 'configureSpeechLanguage()' in main and 'Locale.forLanguageTag' in main
for lc in ['pt','fr','it','es','de','en']:
 assert '"'+lc+'" to listOf' in main and '"'+lc+'" to "' in main
assert 'RouteGuide.instruction(next,lang)' in main
assert 'fun instruction(turn:Turn, language:String="pt")' in guide
assert 'test14' in (root/'app/build.gradle').read_text()
assert 'CarAppService' not in (root/'app/src/main/AndroidManifest.xml').read_text()
print('v0.14 feature contract: OK')
