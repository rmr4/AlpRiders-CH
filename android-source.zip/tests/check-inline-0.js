
'use strict';
const KEY='alpriders-demo-v1';
const safeRead=(name, fallback)=>{try{const got=localStorage.getItem(KEY+name);return got?JSON.parse(got):fallback}catch{return fallback}};
const save=(name,val)=>{try{localStorage.setItem(KEY+name,JSON.stringify(val))}catch{}};
let points=[];let road=null;let map=null;let layerMarkers=null;let layerLine=null;let currentTab='map';
let savedRoutes=safeRead('routes',[]);let chatMessages=safeRead('chat',[]);let profile=safeRead('profile',{nick:'',bike:'',canton:'VS'});
const $=id=>document.getElementById(id);
function toast(message){const el=$('toast');el.textContent=message;el.style.display='block';clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.style.display='none',3200)}
function tab(t){currentTab=t;document.querySelectorAll('.screen').forEach(el=>el.classList.toggle('active',el.id==='view-'+t));document.querySelectorAll('.nav button').forEach(el=>el.classList.toggle('active',el.dataset.tab===t));window.scrollTo({top:0,behavior:'auto'}); if(t==='map'&&map)setTimeout(()=>map.invalidateSize(),80); if(t==='routes')renderSaved()}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>tab(b.dataset.tab));
$('goto-routes').onclick=()=>tab('routes');
function initMap(){if(typeof L==='undefined'){ $('mapstatus').textContent='Mapa indisponível. Verifica a ligação à Internet.';return;}
 $('mapfallback').style.display='none';map=L.map('map',{zoomControl:false}).setView([46.82,8.25],8);
 L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap',maxZoom:18}).addTo(map);
 L.control.zoom({position:'bottomright'}).addTo(map);layerMarkers=L.layerGroup().addTo(map);layerLine=L.layerGroup().addTo(map);
 map.on('click',ev=>{const p=[ev.latlng.lat,ev.latlng.lng];if(pinSelectActive){pinSelectActive=false;selectedPin=p;placePin(p);$('pin-status').textContent=`Ponto escolhido: ${p[0].toFixed(5)}, ${p[1].toFixed(5)}`;toast('Ponto de partida marcado. Volta acima e cria o passeio.');return;}
if(points.length===12)return toast('Máximo de 12 pontos por rota.');points.push(p);road=null;draw();});draw();
}
function draw(){if(map&&layerMarkers&&layerLine){layerMarkers.clearLayers();layerLine.clearLayers();points.forEach((p,i)=>{const symbol=i===0?'P':i===points.length-1?'F':String(i+1);const marker=L.marker(p,{icon:L.divIcon({className:'',html:`<div style="display:grid;place-items:center;background:${i===0?'#fa8b42':'#52d1cf'};border:3px solid #0b2632;border-radius:50%;width:31px;height:31px;font-size:12px;font-weight:900;color:#11222e">${symbol}</div>`,iconSize:[31,31],iconAnchor:[15,15]})});marker.addTo(layerMarkers)});
 if(road&&road.geometry&&road.geometry.length)L.polyline(road.geometry,{color:'#fa8b42',weight:6,opacity:.95}).addTo(layerLine);
 else if(points.length>1)L.polyline(points,{color:'#52d1cf',weight:4,dashArray:'8 9'}).addTo(layerLine);
}
$('points-label').textContent=points.length+' pontos';$('points-count').textContent=points.length+' / 12 pontos';$('dist').textContent=road?road.distance+' km':'—';$('time').textContent=road?road.duration+' min':'—';$('route-message').textContent=road?'Traçado experimental calculado para automóveis.':points.length<2?'Marca pelo menos dois pontos no mapa.':'Linha pontilhada = ligação em linha reta, não uma estrada.';$('mapstatus').textContent=road?'Rota calculada (não é navegação para motos).':points.length?points.length+' pontos marcados · abre Rotas para continuar':'Toca no mapa para marcar os pontos da tua rota.';
}
function fit(){if(map&&points.length){map.fitBounds(points,{padding:[45,45],maxZoom:12})}}
function quick(name){let r={crans:[[46.307,7.469],[46.232,7.361]],verbier:[[46.101,7.073],[46.095,7.216]],interlaken:[[46.686,7.863],[46.625,8.034]]}[name];points=r.map(p=>[...p]);road=null;draw();fit();toast('Rota de exemplo: toca em “Ver rota”.')}
document.querySelectorAll('[data-quick]').forEach(b=>b.onclick=()=>quick(b.dataset.quick));
function clearRoute(){points=[];road=null;draw()}
$('clear-home').onclick=clearRoute;
$('undo-point').onclick=()=>{if(AlpRideUtils.isClosed(points))points.pop();points.pop();road=null;draw()};
$('swissbutton').onclick=()=>{if(map)map.setView([46.82,8.25],8)};
$('gpsbutton').onclick=()=>{if(!navigator.geolocation)return toast('GPS não suportado neste navegador.');toast('A solicitar acesso à localização…');navigator.geolocation.getCurrentPosition(p=>{const at=[p.coords.latitude,p.coords.longitude];if(map){L.circleMarker(at,{radius:9,color:'#fff',fillColor:'#fa8b42',fillOpacity:1,weight:3}).addTo(map).bindPopup('A tua posição (não partilhada)');map.setView(at,12)} toast('GPS obtido. A tua localização não foi partilhada.');},()=>toast('Não foi possível obter o GPS. Confirma as permissões do Chrome.'),{enableHighAccuracy:true,timeout:14000,maximumAge:4000})};
function routeErrorMessage(e){
  if(e?.message==='crossborder')return 'Percurso recusado: a estrada calculada atravessa uma fronteira ou está demasiado perto dela. Muda os pontos para estradas interiores da Suíça.';
  if(e?.message==='boundary_unavailable')return 'Sem verificação da fronteira suíça. Confirma Internet e tenta novamente. Nenhum percurso foi aceite.';
  if(e?.message==='outside_ch')return 'A partida ou um ponto está fora da Suíça (ou demasiado perto da fronteira). Escolhe pontos mais no interior.';
  return 'Serviço de estradas indisponível. Tenta novamente.';
}
async function calculate(){
 if(points.length<2)return toast('Marca a partida e o destino primeiro.');
 $('calc-route').disabled=true;$('calc-route').textContent='A calcular…';
 try{
   const loop=$('round-trip').checked;
   const waypoints=loop?AlpRideUtils.roundTripWaypoints(points):AlpRideUtils.distinctWaypoints(points);
   const result=await requestRoadFor(waypoints);
   if(loop&&(result.returnOverlap==null||result.returnOverlap>0.52)){
     toast('O percurso repete demasiada estrada ou não pôde ser verificado. Escolhe outros pontos para fechar um circuito.');return;
   }
   points=waypoints.map(p=>[...p]);road={...result,roundTrip:loop};draw();
   if(map)map.fitBounds(road.geometry,{padding:[25,25]});
   toast(loop?'Circuito calculado com regresso à partida. Verifica a estrada.':'Rota ponto a ponto calculada. Verifica a estrada.');
 }catch(e){toast(e.message&&(/^(Para um circuito|Afasta)/).test(e.message)?e.message:routeErrorMessage(e));}
 finally{$('calc-route').disabled=false;$('calc-route').textContent='Calcular estrada';}
}
$('calc-route').onclick=calculate;
$('round-trip').addEventListener('change',()=>{
 road=null;points=AlpRideUtils.distinctWaypoints(points);draw();
 $('round-trip-note').textContent=$('round-trip').checked
   ?'Marca a partida e dois pontos intermédios. A rota regressará ao início.'
   :'Rota simples: do primeiro ponto até ao último, sem regresso automático.';
});
$('save-route').onclick=()=>{if(points.length<2)return toast('Marca pelo menos dois pontos.');if(!road?.swissVerified)return toast('Calcula primeiro a estrada e confirma que fica dentro da Suíça antes de guardar.');if($('round-trip').checked&&(!road?.roundTrip||!AlpRideUtils.isClosed(points)))return toast('Calcula primeiro um circuito com regresso confirmado antes de guardar.');let name=$('route-name').value.trim()||'Rota sem nome';const r={id:Date.now(),name,points:points.map(p=>[...p]),road:road?JSON.parse(JSON.stringify(road)):null,roundTrip:!!road?.roundTrip,date:new Date().toLocaleDateString('pt-PT')};savedRoutes.unshift(r);save('routes',savedRoutes);renderSaved();toast('Guardada só neste telemóvel.')};
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function renderSaved(){ $('saved-count').textContent=savedRoutes.length+' guardadas';$('saved-list').innerHTML=savedRoutes.length?savedRoutes.map(r=>`<div class="listitem"><div class="listtitle">🛣️ ${escapeHTML(r.name)}</div><div class="tiny muted">${r.date} · ${r.points.length} pontos ${r.road?'· '+escapeHTML(r.road.distance)+' km':''}${AlpRideUtils.isClosed(r.points)&&!r.road?.roundTrip?' · circuito antigo por verificar':''}</div><div class="smallactions"><button data-load="${r.id}">Ver no mapa</button><button data-download="${r.id}">GPX</button><button data-delete="${r.id}">Eliminar</button></div></div>`).join(''):'<p class="tiny muted">Ainda não tens percursos guardados.</p>'; }
$('saved-list').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const id=Number(b.dataset.load||b.dataset.delete||b.dataset.download);const r=savedRoutes.find(x=>x.id===id);if(!r)return;if(b.dataset.delete){savedRoutes=savedRoutes.filter(x=>x.id!==id);save('routes',savedRoutes);renderSaved();toast('Rota eliminada.')}else if(b.dataset.download){if(!r.road?.swissVerified)return toast('Rota antiga sem validação suíça: recalcula e guarda novamente.');downloadGpx(r.points,r.name,r.road);}else{points=r.points.map(p=>[...p]);road=r.road?.swissVerified?r.road:null;if(!road)toast('Rota antiga sem validação suíça: recalcula antes de conduzir.');$('round-trip').checked=!!r.roundTrip||!!r.road?.roundTrip;draw();tab('map');setTimeout(fit,200)}});
function downloadGpx(coords,name,road){const route=(road?.geometry?.length?road.geometry:coords);if(route.length<2)return toast('Marca pelo menos dois pontos.');if(!road?.swissVerified)return toast('Calcula e verifica a rota dentro da Suíça antes de exportar GPX.');const xml='<?xml version="1.0" encoding="UTF-8"?><gpx version="1.1" creator="AlpRiders CH Demo" xmlns="http://www.topografix.com/GPX/1/1"><trk><name>'+escapeHTML(name)+'</name><trkseg>'+route.map(p=>`<trkpt lat="${p[0]}" lon="${p[1]}"></trkpt>`).join('')+'</trkseg></trk></gpx>';const blob=new Blob([xml],{type:'application/gpx+xml'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(name.replace(/[^a-z0-9-_]/gi,'_')||'rota')+'.gpx';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1200);toast('GPX criado. Verifica o percurso antes de sair.');}
$('export-gpx').onclick=()=>downloadGpx(points,$('route-name').value||'Rota de moto',road);
function renderChat(){let html='<div class="bubble system">Bem-vindo ao chat de teste da AlpRiders CH 🏍️</div>';html+=chatMessages.map(m=>`<div class="bubble">${escapeHTML(m.text)}<div class="bubblemeta">${escapeHTML(m.nick)} · ${escapeHTML(m.time)}</div></div>`).join('');$('chatlog').innerHTML=html;$('chatlog').scrollTop=$('chatlog').scrollHeight;}
$('chat-form').onsubmit=e=>{e.preventDefault();const t=$('chat-input').value.trim();if(!t)return;chatMessages.push({text:t,nick:profile.nick||'Eu',time:new Date().toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'})});chatMessages=chatMessages.slice(-100);save('chat',chatMessages);$('chat-input').value='';renderChat();toast('Mensagem guardada neste telemóvel.');};
function populateProfile(){$('nick').value=profile.nick||'';$('bike').value=profile.bike||'';$('canton').value=profile.canton||'VS'}
$('save-profile').onclick=()=>{profile={nick:$('nick').value.trim().slice(0,32),bike:$('bike').value.trim().slice(0,50),canton:$('canton').value};save('profile',profile);toast('Perfil guardado neste telemóvel.');};
let deferredInstall=null;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e});$('install-btn').onclick=async()=>{if(deferredInstall){deferredInstall.prompt();deferredInstall=null}else toast('No Chrome: menu ⋮ → Adicionar ao ecrã inicial (após alojar em HTTPS).')};
if('serviceWorker'in navigator&&location.protocol==='https:')navigator.serviceWorker.register('sw.js').catch(()=>{});

// Planeador automático: usa referências panorâmicas em território suíço;
// escolhe waypoints e pede traçados ao servidor público OSRM (automóveis).
const swissTowns = {
 'crans-montana':[46.307,7.469], 'sion':[46.232,7.360], 'martigny':[46.101,7.073], 'sierre':[46.291,7.535], 'monthey':[46.254,6.954], 'visp':[46.294,7.881], 'nendaz':[46.186,7.291], 'verbier':[46.098,7.225], 'aigle':[46.317,6.969], 'leukerbad':[46.379,7.628],
 'montreux':[46.431,6.911], 'lausanne':[46.520,6.633], 'lausana':[46.520,6.633], 'geneve':[46.205,6.144], 'genebra':[46.205,6.144],
 'interlaken':[46.686,7.864], 'bern':[46.948,7.447], 'berna':[46.948,7.447], 'lugano':[46.004,8.953],
 'davos':[46.801,9.836], 'chur':[46.851,9.532], 'zurich':[47.377,8.542],
 'lucerne':[47.050,8.309], 'luzerna':[47.050,8.309], 'zurique':[47.377,8.542], 'neuchatel':[46.991,6.931], 'fribourg':[46.806,7.161],
 'thun':[46.758,7.628], 'brig':[46.316,7.988], 'locarno':[46.169,8.799],
 'st. gallen':[47.425,9.376], 'schaffhausen':[47.696,8.635], 'gstaad':[46.475,7.287]
};
// Pontos de passagem aproximados, sem garantia de acesso ou abertura.
const sights = [
 {n:'Col de la Forclaz',p:[46.058,7.002],k:['curvas','panorama']},
 {n:'Col des Mosses',p:[46.396,7.100],k:['curvas','panorama']},
 {n:'Les Diablerets',p:[46.349,7.158],k:['panorama','curvas']},
 {n:'Gstaad',p:[46.475,7.286],k:['panorama']},
 {n:'Col du Pillon',p:[46.353,7.213],k:['curvas','panorama']},
 {n:'Col de la Croix',p:[46.341,7.089],k:['curvas','panorama']},
 {n:'Col des Planches',p:[46.128,7.077],k:['curvas']},
 {n:'Col du Simplon',p:[46.250,8.034],k:['curvas','panorama']},
 {n:'Grimselpass',p:[46.560,8.336],k:['curvas','panorama']},
 {n:'Furkapass',p:[46.574,8.416],k:['curvas','panorama']},
 {n:'Sustenpass',p:[46.729,8.448],k:['curvas','panorama']},
 {n:'Nufenenpass',p:[46.477,8.387],k:['curvas','panorama']},
 {n:'Oberalppass',p:[46.658,8.670],k:['curvas','panorama']},
 {n:'Lukmanierpass',p:[46.563,8.796],k:['curvas','panorama']},
 {n:'San Bernardino',p:[46.465,9.193],k:['curvas','panorama']},
 {n:'Julierpass',p:[46.473,9.727],k:['curvas','panorama']},
 {n:'Flüelapass',p:[46.750,9.946],k:['curvas','panorama']},
 {n:'Maloja',p:[46.402,9.695],k:['curvas','panorama','lagos']},
 {n:'St-Cergue (VD)',p:[46.449,6.156],k:['curvas','panorama']},
 {n:'Saint-George (VD)',p:[46.514,6.266],k:['curvas','panorama']},
 {n:'Aubonne (VD)',p:[46.494,6.392],k:['curvas','panorama']},
 {n:'Rolle (VD)',p:[46.458,6.336],k:['lagos','panorama']},
 {n:'Nyon (VD)',p:[46.383,6.240],k:['lagos','panorama']},
 {n:'Gland (VD)',p:[46.419,6.269],k:['lagos']},
 {n:'Morges (VD)',p:[46.511,6.499],k:['lagos','panorama']},
 {n:'Col du Marchairuz',p:[46.550,6.253],k:['curvas']},
 {n:'Col du Mollendruz',p:[46.650,6.362],k:['curvas']},
 {n:'Lac de Joux',p:[46.625,6.263],k:['lagos']},
 {n:'Lac de Gruyère',p:[46.646,7.101],k:['lagos']},
 {n:'Lac de Thoune',p:[46.680,7.715],k:['lagos']},
 {n:'Lac de Brienz',p:[46.735,7.980],k:['lagos']},
 {n:'Brünigpass',p:[46.758,8.136],k:['curvas','panorama']},
 {n:'Schallenberg',p:[46.820,7.773],k:['curvas']},
 {n:'Lac des Quatre-Cantons',p:[46.986,8.398],k:['lagos']},
 {n:'Lac de Zurich',p:[47.243,8.680],k:['lagos']},
 {n:'Appenzell',p:[47.331,9.409],k:['panorama']},
 {n:'Lago Maggiore',p:[46.170,8.799],k:['lagos']},
 {n:'Lago di Lugano',p:[45.996,8.946],k:['lagos']},
 {n:'Val Verzasca',p:[46.212,8.830],k:['panorama']}
];
function normCity(s){return s.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ü/g,'u').replace(/œ/g,'oe').replace(/[^a-z0-9 .-]/g,'');}
function kmBetween(a,b){const rad=Math.PI/180;const dl=(b[0]-a[0])*rad;const doo=(b[1]-a[1])*rad;const h=Math.sin(dl/2)**2+Math.cos(a[0]*rad)*Math.cos(b[0]*rad)*Math.sin(doo/2)**2;return 12742*Math.asin(Math.min(1,Math.sqrt(h)));}
function validSwiss(p){return p[0]>=45.79&&p[0]<=47.81&&p[1]>=5.95&&p[1]<=10.54}
async function findCity(raw){const key=normCity(raw);if(swissTowns[key])return swissTowns[key];
  const url='https://photon.komoot.io/api/?q='+encodeURIComponent(raw+' Switzerland')+'&limit=8&lang=fr';
  const response=await fetch(url,{signal:AbortSignal.timeout(13000)});
  if(!response.ok)throw Error('geocode');const obj=await response.json();
  const feature=(obj.features||[]).find(x=>{const p=x.properties||{};return String(p.countrycode||'').toUpperCase()==='CH' && ['city','town','village','municipality','locality','suburb'].includes(p.type||'')}) ||
   (obj.features||[]).find(x=>String((x.properties||{}).countrycode||'').toUpperCase()==='CH');
  if(!feature)throw Error('notfound');const coords=[feature.geometry.coordinates[1],feature.geometry.coordinates[0]];
  if(!validSwiss(coords))throw Error('notfound');return coords;
}
async function requestRoadFor(waypoints){
  // Fail closed. A Swiss town as a waypoint does not prevent an OSRM car route via France.
  try{await SwissBorders.ensure();}catch{throw Error('boundary_unavailable');}
  if(!waypoints.every(p=>SwissBorders.safeInside(p)))throw Error('outside_ch');
  const str=waypoints.map(p=>p[1].toFixed(6)+','+p[0].toFixed(6)).join(';');
  const resp=await fetch('https://router.project-osrm.org/route/v1/driving/'+str+'?overview=full&geometries=geojson&steps=true',{signal:AbortSignal.timeout(17000)});
  if(!resp.ok)throw Error('routing');const data=await resp.json();const r=data.routes?.[0];if(!r?.geometry?.coordinates?.length)throw Error('routing');
  const geometry=r.geometry.coordinates.map(p=>[p[1],p[0]]);
  if(!SwissBorders.everySegmentInside(geometry))throw Error('crossborder');
  return {geometry, swissVerified:true, country:'CH',distance:(r.distance/1000).toFixed(1),duration:Math.round(r.duration/60), returnOverlap:AlpRideUtils.retraceFraction(r.legs), steps:(r.legs||[]).flatMap(leg=>(leg.steps||[]).map(st=>({p:[st.maneuver.location[1],st.maneuver.location[0]],type:st.maneuver.type||'',mod:st.maneuver.modifier||'',name:st.name||''}))) };
}
function scenicOptions(start,style,maxKm){const pool=sights.filter(s=>validSwiss(s.p)).map(s=>({...s,d:kmBetween(start,s.p)})).filter(s=>s.d>=6&&s.d<=maxKm);
 const preferred=pool.filter(s=>style==='mix'||s.k.includes(style));return (preferred.length>=2?preferred:pool).sort((a,b)=>a.d-b.d);
}
const shuffleArray=a=>a.sort(()=>Math.random()-.5);
let surpriseInProgress=false;
async function makeSurprise(){
 if(surpriseInProgress)return;const btn=$('surprise-button'),status=$('surprise-result');
 surpriseInProgress=true;btn.disabled=true;btn.textContent='A criar passeio…';status.textContent='A procurar a localidade e as estradas panorâmicas…';
 try{
   const {start,label}=await resolveStartingPoint();try{await SwissBorders.ensure();}catch{throw Error('boundary_unavailable');}if(!SwissBorders.safeInside(start))throw Error('outside_ch');const target=Number($('ride-hours').value),style=$('ride-style').value;
   const maxRadius=Math.max(24,Math.min(95,target*.45));const pool=scenicOptions(start,style,maxRadius);
   if(pool.length<1){status.textContent='Sem pontos panorâmicos próximos. Vou tentar criar um circuito rodoviário experimental nesta região.';}
   const near=pool.filter(x=>x.d < maxRadius*.75);const primary=near.length?near:pool;
   const attempts=[];const selected=shuffleArray([...primary]).slice(0,5);
   for(const s of selected){
     const secondChoices=pool.filter(t=>t.n!==s.n && kmBetween(s.p,t.p)>9 && kmBetween(s.p,t.p)<maxRadius*1.25 && kmBetween(start,t.p)>6);
     if(secondChoices.length){const other=secondChoices[Math.floor(Math.random()*secondChoices.length)];attempts.push([start,s.p,other.p,start]);}
     if(attempts.length>=5)break;
   }
   // Circuitos de contingência geométricos: úteis quando não existem pontos curados perto.
   // São apenas candidatos; só são apresentados depois de o motor calcular estradas reais.
   if(attempts.length<3){
     const radialKm=Math.max(7,Math.min(27,target/60*10));
     for(let i=0;i<4;i++){const theta=(i*.58+Math.random()*1.8)*Math.PI;
       const offset=(angle)=>[start[0]+radialKm*Math.sin(angle)/111.1,start[1]+radialKm*Math.cos(angle)/(111.1*Math.cos(start[0]*Math.PI/180))];
       const a=offset(theta),b=offset(theta+.95),c=offset(theta+2.05);
       if(validSwiss(a)&&validSwiss(b)&&validSwiss(c))attempts.push([start,a,b,c,start]);
       if(attempts.length>=5)break;
     }
   }
   let best=null, bestScore=Infinity, rejectedAtBorder=0;
   for(let i=0;i<Math.min(attempts.length,5);i++){
     status.textContent='A calcular opções '+(i+1)+' de '+Math.min(attempts.length,5)+'…';
     const path=attempts[i];try{
       AlpRideUtils.roundTripWaypoints(path);
       const response=await requestRoadFor(path);
       if(response.returnOverlap==null||response.returnOverlap>0.52)continue;
       const score=Math.abs(response.duration-target)/Math.max(target,1)+response.returnOverlap*.45;
       if(score<bestScore){best={path,response};bestScore=score;}
       if(score<0.18)break;
     }catch(e){if(['crossborder','outside_ch'].includes(e.message))rejectedAtBorder++;/* Serviço público pode limitar pedidos; tentar seguinte */}
   }
   if(!best){status.textContent=rejectedAtBorder?'🇨🇭 Nenhum circuito disponível sem sair da Suíça nesta combinação. Tenta outro estilo ou duração; nunca será apresentada uma rota por França.':'Não foi possível obter um circuito com regresso por estradas suficientemente diferentes. Tenta outra duração ou escolhe dois pontos intermédios no mapa.';return;}
   points=best.path.map(p=>[...p]);road={...best.response,roundTrip:true};$('round-trip').checked=true;draw();
   const name='Passeio surpresa desde '+label;$('route-name').value=name;
   status.innerHTML='<b>🏍️ Passeio com regresso criado!</b><br>Partida e regresso: '+escapeHTML(label)+
     '<br>Distância estimada: <b>'+road.distance+' km</b> · Tempo estimado: <b>'+road.duration+' min</b><br>'+
     (Math.abs(road.duration-target)>target*.35?'<b>Atenção:</b> não corresponde à duração pedida. Experimenta outro passeio.<br>':'')+
     '🇨🇭 Percurso verificado dentro da Suíça (fronteira cartográfica aproximada). Verifica encerramentos, acessos e condições antes de conduzir.';
   tab('map');if(map)setTimeout(()=>map.fitBounds(road.geometry,{padding:[35,35]}),160);
   toast('Passeio criado! Podes guardá-lo em Rotas ou exportar GPX.');
 }catch(e){status.textContent=e.message==='notfound'?'Localidade não encontrada na Suíça. Verifica o nome.':e.message==='pin'?'Escolhe primeiro o ponto exato no mapa.':e.message==='gps'?'Não consegui obter GPS. Ativa a localização e autoriza a AlpRiders CH nas definições do Android.':routeErrorMessage(e);}
 finally{surpriseInProgress=false;btn.disabled=false;btn.textContent='🎲 Criar outro passeio surpresa';}
}
$('surprise-button').onclick=makeSurprise;
// Velocímetro GPS: disponível com permissão e origem segura; não é um instrumento certificado.
let speedWatch=null;
$('speed-button').onclick=()=>{
  const button=$('speed-button');
  if(speedWatch!==null){navigator.geolocation.clearWatch(speedWatch);speedWatch=null;button.textContent='Ativar GPS';$('speed-val').textContent='—';return;}
  if(!navigator.geolocation||!window.isSecureContext){toast('O GPS contínuo exige autorização e página HTTPS.');return;}
  button.textContent='A ligar GPS…';
  speedWatch=navigator.geolocation.watchPosition(pos=>{
    let speed=pos.coords.speed;
    $('speed-val').textContent=(speed==null||speed<0)?'—':String(Math.round(speed*3.6));
    onPosition(pos);
    button.textContent='Parar GPS';
  },()=>{toast('Não foi possível ativar GPS. Verifica as permissões.');if(speedWatch!==null)navigator.geolocation.clearWatch(speedWatch);speedWatch=null;button.textContent='Ativar GPS';},{enableHighAccuracy:true,maximumAge:1000,timeout:15000});
};


// ---- Nova versão: partida GPS/ponto, navegação na página e SOS manual ----
let selectedPin=null, pinSelectActive=false, startPinMarker=null, lastPosition=null, navActive=false, screenLock=null;
const SOS_KEY='alpriders_sos_contacts_v1';
let emergencyContacts=safeRead('sos-contacts',[{name:'',phone:''},{name:'',phone:''},{name:'',phone:''}]);
function changeStartMode(){const mode=$('start-mode').value;$('town-fields').hidden=mode!=='town';$('pin-fields').hidden=mode!=='pin';if(mode==='pin')toast('Carrega em Selecionar no mapa para definir a partida.');}
$('start-mode').addEventListener('change',changeStartMode);
$('choose-pin').onclick=()=>{pinSelectActive=true;tab('map');$('mapstatus').textContent='Toca no mapa para definir a partida. Não marca o destino.';map?.invalidateSize();document.querySelector('.mapbox').scrollIntoView({behavior:'smooth',block:'center'});};
function placePin(p){if(!map)return;if(startPinMarker)map.removeLayer(startPinMarker);startPinMarker=L.circleMarker(p,{radius:11,color:'#fff',fillColor:'#ffa95e',fillOpacity:1,weight:3}).addTo(map).bindPopup('Partida exata');}
function locateNow(){return new Promise((resolve,reject)=>{if(!navigator.geolocation||!window.isSecureContext)return reject(new Error('gps'));navigator.geolocation.getCurrentPosition(pos=>{onPosition(pos);resolve(pos);},()=>reject(new Error('gps')),{enableHighAccuracy:true,timeout:16000,maximumAge:15000});});}
async function resolveStartingPoint(){const mode=$('start-mode').value;
 if(mode==='pin'){if(!selectedPin)throw new Error('pin');return {start:[...selectedPin],label:'ponto escolhido no mapa'};}
 if(mode==='town'){const town=$('start-town').value.trim();if(!town)throw new Error('notfound');return {start:await findCity(town),label:town};}
 const pos=(lastPosition && Date.now()-lastPosition.timestamp < 60000)?lastPosition:await locateNow();
 const p=[pos.coords.latitude,pos.coords.longitude];if(!validSwiss(p))throw new Error('gps');return {start:p,label:'localização GPS atual'};
}
$('manual-map-start').onclick=()=>{$('start-mode').value='pin';changeStartMode();$('choose-pin').click()};
$('manual-gps-start').onclick=async()=>{try{const pos=await locateNow();points=[[pos.coords.latitude,pos.coords.longitude]];road=null;draw();map?.setView(points[0],13);toast('Partida definida no teu GPS. Toca no mapa para marcar destino.');}catch{toast('Ativa a localização e autoriza a AlpRiders CH no Android.');}};
function onPosition(pos){lastPosition=pos;const at=[pos.coords.latitude,pos.coords.longitude];
 if(navActive&&map){map.panTo(at,{animate:true,duration:.5});updateNavigationUI(pos)}
 if(currentTab==='sos')renderSosLocation();
}
async function enableGPSforNavigation(){if(speedWatch!==null){if(lastPosition)return;await locateNow();return;}
 if(!navigator.geolocation||!window.isSecureContext)throw new Error('gps');
 return new Promise((resolve,reject)=>{let first=true;
 speedWatch=navigator.geolocation.watchPosition(pos=>{onPosition(pos);$('speed-val').textContent=pos.coords.speed==null?'—':String(Math.round(pos.coords.speed*3.6));$('speed-button').textContent='Parar GPS';if(first){first=false;resolve();}},err=>{if(first){first=false;reject(new Error('gps'));}else toast('Sinal GPS perdido.');},{enableHighAccuracy:true,maximumAge:1000,timeout:16000});
 });}
async function acquireWakeLock(){if(!navActive||document.visibilityState!=='visible'||!('wakeLock'in navigator))return;
 try{screenLock=await navigator.wakeLock.request('screen');}catch{toast('O Android não permitiu manter o ecrã ligado.');}}
function stopNavigation(){navActive=false;document.body.classList.remove('nav-mode');$('nav-next').textContent='Navegação terminada';if(screenLock){screenLock.release().catch(()=>{});screenLock=null;}if(map)setTimeout(()=>map.invalidateSize(),100);}
$('nav-stop').onclick=stopNavigation;
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&navActive){acquireWakeLock();map?.invalidateSize();}});
function closestPathIndex(path,p,minIndex=0){let best=minIndex,dist=Infinity;for(let i=minIndex;i<path.length;i++){let dx=(path[i][0]-p[0])*111;let dy=(path[i][1]-p[1])*111*Math.cos(p[0]*Math.PI/180);const d=dx*dx+dy*dy;if(d<dist){dist=d;best=i;}}return {i:best,metres:Math.sqrt(dist)*1000};}
function guideText(step){if(!step)return 'Continua até ao destino';if(step.type==='arrive')return 'Chegada ao destino';if(step.type==='depart')return 'Segue pela estrada';if(step.type==='roundabout'||step.type==='rotary')return 'Entra na rotunda';
 const mapWords={right:'Vira à direita',left:'Vira à esquerda','slight right':'Ligeiramente à direita','slight left':'Ligeiramente à esquerda',straight:'Segue em frente',uturn:'Faz inversão de marcha','sharp right':'Vira bem à direita','sharp left':'Vira bem à esquerda'};
 return mapWords[step.mod]||'Continua o percurso';}
function updateNavigationUI(pos){if(!road?.geometry?.length)return;const at=[pos.coords.latitude,pos.coords.longitude],geo=road.geometry;
 const closest=closestPathIndex(geo,at);let next=null,idx=geo.length-1;
 for(const s of road.steps||[]){if(s.type==='depart')continue;const near=closestPathIndex(geo,s.p,closest.i);if(near.i>closest.i){next=s;idx=near.i;break;}}
 const trackMiss=closest.metres>150; let remain=0;for(let i=closest.i+1;i<=idx;i++){remain+=kmBetween(geo[i-1],geo[i])*1000;}
 const kmh=pos.coords.speed==null?'—':Math.round(Math.max(0,pos.coords.speed*3.6));$('nav-kmh').textContent=kmh+' km/h';
 $('nav-next').textContent=trackMiss?'Estás afastado do percurso':guideText(next);
 $('nav-detail').textContent=trackMiss?'A orientação pode estar incorreta. Encosta em segurança para rever a rota.':
 next?`Em aproximadamente ${Math.round(remain/10)*10} m${next.name?' · '+next.name:''} · GPS ±${Math.round(pos.coords.accuracy)} m`:'Aproximação ao fim do percurso · verifica o mapa';
}
$('nav-start').onclick=async()=>{if(!points.length||points.length<2)return toast('Cria primeiro uma rota ou um passeio surpresa.');
 $('nav-start').disabled=true;$('nav-start').textContent='A preparar navegação…';
 try{if(!road?.swissVerified||!road.steps?.length)road=await requestRoadFor(points);draw();await enableGPSforNavigation();navActive=true;tab('map');document.body.classList.add('nav-mode');setTimeout(()=>map?.invalidateSize(),120);await acquireWakeLock();if(lastPosition)updateNavigationUI(lastPosition);toast('Navegação de TESTE nesta app. Não funciona garantidamente com ecrã bloqueado.');}
 catch(e){toast(['outside_ch','crossborder','boundary_unavailable'].includes(e.message)?routeErrorMessage(e):'Navegação experimental indisponível. Confirma Internet e permissão GPS.');}
 finally{$('nav-start').disabled=false;$('nav-start').textContent='🧭 Iniciar navegação aqui';}
};
$('nav-sos').onclick=()=>tab('sos');$('map-sos').onclick=()=>tab('sos');
function renderSosContacts(){const area=$('sos-contacts');area.replaceChildren();emergencyContacts.forEach((c,i)=>{const row=document.createElement('div');row.className='sos-contacts-row';
 const label=document.createElement('b');label.textContent=`Contacto ${i+1}`;row.appendChild(label);
 const n=document.createElement('input');n.className='input';n.id='sos-name-'+i;n.maxLength=40;n.placeholder='Nome';n.value=c.name||'';n.setAttribute('aria-label','Nome do contacto '+(i+1));row.appendChild(n);
 const phone=document.createElement('input');phone.className='input';phone.id='sos-phone-'+i;phone.type='tel';phone.maxLength=22;phone.placeholder='Telefone com indicativo (ex.: +41...)';phone.value=c.phone||'';phone.setAttribute('aria-label','Número do contacto '+(i+1));row.appendChild(phone);area.appendChild(row);});renderSmsButtons();}
function getFreshPosition(){return lastPosition&&Date.now()-lastPosition.timestamp<5*60*1000&&Number.isFinite(lastPosition.coords.accuracy)?lastPosition:null;}
function positionMessage(){const p=getFreshPosition();if(!p)return '';
 const lat=p.coords.latitude.toFixed(6),lng=p.coords.longitude.toFixed(6),acc=Math.round(p.coords.accuracy),t=new Date(p.timestamp).toLocaleString('pt-PT');
 return `SOS — Preciso de ajuda / J'ai besoin d'aide. Posição GPS registada: ${lat}, ${lng} (precisão estimada ±${acc} m; ${t}). Mapa: https://maps.google.com/?q=${lat},${lng}. Se for uma emergência, contacta os serviços de socorro. / En cas d'urgence, contactez les secours.`;
}
function renderSosLocation(){const p=getFreshPosition();$('sos-gps-status').textContent=p?`Localização de ${new Date(p.timestamp).toLocaleTimeString('pt-PT')} · precisão estimada ±${Math.round(p.coords.accuracy)} m.`:'GPS indisponível ou desatualizado. Toca em «Atualizar GPS».';
 $('sos-position').textContent=p?`${p.coords.latitude.toFixed(6)}, ${p.coords.longitude.toFixed(6)}`:'—';$('sos-share').disabled=!p;$('sos-copy').disabled=!p;renderSmsButtons();}
$('sos-locate').onclick=async()=>{$('sos-gps-status').textContent='A pedir localização…';try{await locateNow();renderSosLocation();toast('Localização GPS atualizada.');}catch{renderSosLocation();toast('GPS indisponível. Ativa a localização e autoriza a AlpRiders CH nas definições do Android.');}};
$('sos-save').onclick=()=>{emergencyContacts=[0,1,2].map(i=>({name:($('sos-name-'+i).value||'').trim().slice(0,40),phone:($('sos-phone-'+i).value||'').trim().slice(0,22)}));
 if(emergencyContacts.some(c=>c.phone&&!/^\+?[0-9 ()-]{6,22}$/.test(c.phone)))return toast('Verifica os números. Usa dígitos e indicativo +41.');
 save('sos-contacts',emergencyContacts);renderSmsButtons();toast('Três contactos guardados neste telemóvel.');};
function renderSmsButtons(){
 const container=$('sos-sms-buttons');container.replaceChildren();
 const body=positionMessage();
 for(const [i,c] of emergencyContacts.entries()){
   if(!c.phone)continue;
   const btn=document.createElement('button');btn.type='button';
   const actionByLanguage={pt:'Preparar WhatsApp para',fr:'Préparer WhatsApp pour',it:'Prepara WhatsApp per',es:'Preparar WhatsApp para',de:'WhatsApp vorbereiten für',en:'Prepare WhatsApp for'};
   const lang=$('language-picker')?.value||'pt';
   btn.textContent=`🟢 ${actionByLanguage[lang]||actionByLanguage.pt} ${c.name||'contacto '+(i+1)}`;
   btn.addEventListener('click',()=>{
     const number=AlpRideUtils.parseWhatsappNumber(c.phone);
     if(!number){toast('Usa o número internacional do contacto, por exemplo +41...');return;}
     const gpsMessage=positionMessage();
     const latest=gpsMessage||'SOS — Preciso de ajuda. A posição GPS não está disponível. Por favor liga-me ou contacta-me; em emergência liga 112.';
     if(!gpsMessage)toast('GPS indisponível: a mensagem WhatsApp não incluirá localização.');
     if(window.AndroidBridge?.openWhatsApp){window.AndroidBridge.openWhatsApp(number,latest);}
     else window.open('https://wa.me/'+number+'?text='+encodeURIComponent(latest),'_blank','noopener');
     toast('Confirma o destinatário e carrega em Enviar no WhatsApp.');
   });
   container.appendChild(btn);
 }
 if(!emergencyContacts.some(c=>c.phone)){
   const tip=document.createElement('p');tip.className='tiny muted';
   tip.textContent='Guarda pelo menos um número com indicativo internacional para preparar uma mensagem WhatsApp.';
   container.appendChild(tip);
 }
}
$('sos-share').onclick=async()=>{const t=positionMessage();if(!t)return toast('Atualiza primeiro o GPS.');try{if(navigator.share)await navigator.share({title:'Localização SOS AlpRiders CH',text:t});else if(navigator.clipboard){await navigator.clipboard.writeText(t);toast('Mensagem copiada. Cola-a numa conversa.');}else toast('Usa a opção Copiar mensagem.');}catch{/* utilizador cancelou partilha */}};
$('sos-copy').onclick=async()=>{const t=positionMessage();if(!t)return toast('Atualiza primeiro o GPS.');try{await navigator.clipboard.writeText(t);toast('Mensagem SOS copiada.');}catch{toast('Não foi possível copiar neste navegador.');}};
const _tab=tab;
tab=function(t){_tab(t);if(t==='sos'){renderSosLocation();}};
renderSosContacts();changeStartMode();

renderSaved();renderChat();populateProfile();/* MapLibre Android displays the map */draw();
