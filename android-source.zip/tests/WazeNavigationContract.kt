import ch.alpriders.navigation.WazeNavigation

fun main() {
  val swissLoop=listOf(46.2 to 6.14,46.4 to 6.3,46.5 to 6.44,46.2 to 6.14)
  val stages=WazeNavigation.destinations(swissLoop)
  check(stages.size==3)
  check(stages[0].stage==1 && !stages[0].isReturn && stages[0].latitude==46.4)
  check(stages[1].stage==2 && !stages[1].isReturn)
  check(stages[2].stage==3 && stages[2].isReturn && stages[2].latitude==46.2)
  val oneWay=WazeNavigation.destinations(listOf(46.2 to 6.1,46.4 to 6.3))
  check(oneWay.size==1 && oneWay[0].isFinal && !oneWay[0].isReturn)
  check(WazeNavigation.destinations(emptyList()).isEmpty())
  val u=WazeNavigation.link(46.2,6.14) ?: error("No URL")
  check(u.startsWith("https://waze.com/ul?ll=46.200000%2C6.140000"))
  check("vehicle_type=motorcycle" in u)
  check("navigate=yes" in u)
  check(WazeNavigation.link(Double.NaN,4.2)==null)
  check(WazeNavigation.link(95.0,4.2)==null)
  println("WazeNavigationContract passed")
}
