from pathlib import Path
src=Path('app/src/main/java/ch/alpriders/navigation/MainActivity.kt').read_text()
gradle=Path('app/build.gradle').read_text()
manifest=Path('app/src/main/AndroidManifest.xml').read_text()
assert 'IconFactory.getInstance(this).fromBitmap(bitmap)' in src
assert 'marker.icon(startBikeIcon)' in src and '.icon(gpsBikeIcon)' in src
assert 'departureMarker?.let { map?.removeMarker(it) }' in src
assert 'if(!navActive || !mapReady || fix.accuracy>100f)return' in src
assert 'followNavigationCamera(loc,immediate=true)' in src
assert 'navigationZoom(fix)' in src and 'fix.speed >= 27.8f -> 16.4' in src
assert 'navSpeech?.speak(message,TextToSpeech.QUEUE_FLUSH' in src
assert 'Navegação iniciada.' in src
assert 'alpriders_voice_test' in src
assert 'navOffRouteSpoken' in src
assert 'ch.alpriders.navigation.test14' in gradle
assert 'v0.14 TESTE' in manifest
assert 'android.intent.action.TTS_SERVICE' in manifest
assert 'Texto' not in src[:200] # sanity
print('navigation presentation contract: OK')
