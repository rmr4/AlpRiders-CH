import ch.alpriders.navigation.RouteGuide

fun main(){
    val a=RouteGuide.Point(46.2,6.14)
    val b=RouteGuide.Point(46.2,6.15)
    val mid=RouteGuide.Point(46.2,6.145)
    val p=RouteGuide.progress(listOf(a,b),mid)!!
    check(p.offRouteMeters<2)
    check(p.alongMeters>300 && p.alongMeters<500)
    check(p.remainingMeters>300 && p.remainingMeters<500)
    val far=RouteGuide.progress(listOf(a,b),RouteGuide.Point(46.22,6.145))!!
    check(far.offRouteMeters>1500)
    val t=RouteGuide.Turn(b,"turn","right","Rue Test",500.0)
    check(RouteGuide.upcoming(listOf(t),100.0)==t)
    check(RouteGuide.upcoming(listOf(t),495.0)==null)
    check("direita" in RouteGuide.instruction(t))
    println("RouteGuideContract passed")
}
