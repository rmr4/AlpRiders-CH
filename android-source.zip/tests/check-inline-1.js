
'use strict';
// --- One touch GPS and navigation ---
let combinedGpsOn=false;
let currentMarker=null;
function setCombinedGps(on){combinedGpsOn=on;
  $('gps-one-button').textContent=on?tstr('🛑 Parar GPS + Navegação'):tstr('📍 Ligar GPS + Navegação');
  $('gps-one-info').textContent=on?tstr('GPS ativo nesta página. Não é uma navegação certificada e pode parar com o ecrã bloqueado.'):tstr('Sem rota, o botão mostra a tua posição e velocidade. Cria um passeio para receber orientação experimental no mapa.');
}
$('gps-one-button').addEventListener('click',async()=>{
 if(navActive){stopNavigation(); if(speedWatch!==null)$('speed-button').click();setCombinedGps(false);return;}
 if(combinedGpsOn){if(speedWatch!==null)$('speed-button').click();setCombinedGps(false);return;}
 if(!window.isSecureContext||!navigator.geolocation){toast(tstr('Ativa a localização e autoriza a AlpRiders CH no Android.'));return;}
 const button=$('gps-one-button');button.disabled=true;button.textContent=tstr('A ligar GPS…');
 try{
   if(speedWatch===null)await enableGPSforNavigation();else if(!lastPosition)await locateNow();
   if(lastPosition&&map)map.setView([lastPosition.coords.latitude,lastPosition.coords.longitude],14);
   setCombinedGps(true);
   if(points.length>=2){$('nav-start').click();}
   else toast(tstr('GPS ligado. Cria um passeio para iniciar a navegação.'));
 }catch{setCombinedGps(false);toast(tstr('Não foi possível ligar o GPS. Confirma as permissões e usa HTTPS.'));}
 finally{button.disabled=false;}
});
const previousPositionHandler=onPosition;
onPosition=function(pos){previousPositionHandler(pos);
  const s=pos.coords.speed;
  $('gps-one-speed').textContent=(s==null||s<0)?'—':String(Math.round(s*3.6));
  if(combinedGpsOn&&!navActive&&map){const p=[pos.coords.latitude,pos.coords.longitude];
    if(currentMarker){currentMarker.setLatLng(p)}else{currentMarker=L.circleMarker(p,{radius:9,color:'#fff',fillColor:'#45d3c8',fillOpacity:1,weight:3}).addTo(map)}
  }
};
const legacyStop=stopNavigation;
stopNavigation=function(){legacyStop();setCombinedGps(false)};

// --- Language support: all principal screens, group tools, actions ---
const i18n = {
// [French, Italian, Spanish, German, English] — Portuguese is the source UI
'Idioma':['Langue','Lingua','Idioma','Sprache','Language'],
'DEMONSTRAÇÃO':['DÉMO','DEMO','DEMO','DEMO','DEMO'],
'RODAS LIVRES • SUÍÇA':['LIBERTÉ SUR DEUX ROUES • SUISSE','LIBERTÀ SU DUE RUOTE • SVIZZERA','LIBERTAD SOBRE RUEDAS • SUIZA','FREIHEIT AUF ZWEI RÄDERN • SCHWEIZ','TWO WHEELS • SWITZERLAND'],
'A tua estrada começa aqui':['Ta route commence ici','Il tuo viaggio inizia qui','Tu ruta empieza aquí','Deine Fahrt beginnt hier','Your ride starts here'],
'O passeio começa onde quiseres.':['Partez où vous voulez.','Parti da dove vuoi.','Sal desde donde quieras.','Starte, wo du möchtest.','Start your ride anywhere.'],
'Parte do GPS atual, escolhe um ponto exato no mapa ou escreve uma localidade. Navegação experimental dentro da app.':['Utilise ton GPS, choisis un point sur la carte ou saisis une ville. Navigation expérimentale intégrée.','Usa il GPS, scegli un punto sulla mappa o scrivi una località. Navigazione sperimentale integrata.','Usa el GPS, elige un punto del mapa o escribe una ciudad. Navegación experimental integrada.','Starte mit GPS, wähle einen Kartenpunkt oder gib einen Ort ein. Experimentelle Navigation in der App.','Use GPS, choose a map point or enter a town. Experimental in-app navigation.'],
'🎲 Surpreende-me':['🎲 Surprends-moi','🎲 Sorprendimi','🎲 Sorpréndeme','🎲 Überrasch mich','🎲 Surprise me'],
'Passeio automático':['Balade automatique','Giro automatico','Ruta automática','Automatische Tour','Automatic ride'],
'Escolhe como queres partir. A app tenta criar uma rota circular com partida e regresso ao ponto escolhido.':['Choisis le départ. L’app essaie de créer une boucle qui revient au point choisi.','Scegli la partenza. L’app tenta di creare un percorso ad anello.','Elige la salida. La app intenta crear una ruta circular.','Wähle deinen Start. Die App versucht, eine Rundtour zu erstellen.','Choose your starting point. The app attempts a round trip.'],
'Partida':['Départ','Partenza','Salida','Start','Start'],
'📍 Posição atual pelo GPS':['📍 Position GPS actuelle','📍 Posizione GPS attuale','📍 Ubicación GPS actual','📍 Aktueller GPS-Standort','📍 Current GPS location'],
'🗺️ Escolher ponto no mapa':['🗺️ Choisir sur la carte','🗺️ Scegli sulla mappa','🗺️ Elegir en el mapa','🗺️ Punkt auf Karte wählen','🗺️ Choose point on map'],
'🏘️ Escrever uma localidade':['🏘️ Saisir une ville','🏘️ Inserisci località','🏘️ Escribir localidad','🏘️ Ort eingeben','🏘️ Enter a town'],
'Nome da localidade':['Nom de la ville','Nome località','Nombre de la localidad','Ortsname','Town name'],
'Selecionar no mapa':['Choisir sur la carte','Seleziona sulla mappa','Seleccionar en mapa','Auf Karte wählen','Select on map'],
'Ainda não escolheste nenhum ponto.':['Aucun point choisi.','Nessun punto selezionato.','Ningún punto seleccionado.','Kein Punkt gewählt.','No point selected.'],
'Duração pretendida':['Durée souhaitée','Durata desiderata','Duración deseada','Gewünschte Dauer','Desired duration'],
'1 hora':['1 heure','1 ora','1 hora','1 Stunde','1 hour'],
'2 horas':['2 heures','2 ore','2 horas','2 Stunden','2 hours'],
'3 horas':['3 heures','3 ore','3 horas','3 Stunden','3 hours'],
'4 horas':['4 heures','4 ore','4 horas','4 Stunden','4 hours'],
'Tipo de passeio':['Type de balade','Tipo di giro','Tipo de ruta','Tourart','Ride style'],
'Surpresa':['Surprise','Sorpresa','Sorpresa','Überraschung','Surprise'],
'Curvas e montanhas':['Virages et montagnes','Curve e montagne','Curvas y montañas','Kurven und Berge','Twists and mountains'],
'Paisagens alpinas':['Paysages alpins','Paesaggi alpini','Paisajes alpinos','Alpenpanoramen','Alpine scenery'],
'Lagos e vales':['Lacs et vallées','Laghi e valli','Lagos y valles','Seen und Täler','Lakes and valleys'],
'🎲 Criar passeio surpresa':['🎲 Créer une balade surprise','🎲 Crea un giro a sorpresa','🎲 Crear ruta sorpresa','🎲 Überraschungstour erstellen','🎲 Create surprise ride'],
'GPS + Navegação':['GPS + Navigation','GPS + Navigazione','GPS + Navegación','GPS + Navigation','GPS + Navigation'],
'Um único botão para ligar o GPS, mostrar a velocidade e navegar nesta app quando houver uma rota.':['Un bouton pour activer le GPS, afficher la vitesse et suivre un trajet dans l’app.','Un tasto per GPS, velocità e navigazione nell’app quando esiste un percorso.','Un botón para activar GPS, ver velocidad y navegar en la app.','Eine Taste für GPS, Geschwindigkeit und Navigation in der App.','One button for GPS, speed and in-app navigation.'],
'📍 Ligar GPS + Navegação':['📍 Activer GPS + Navigation','📍 Avvia GPS + Navigazione','📍 Activar GPS + Navegación','📍 GPS + Navigation starten','📍 Start GPS + Navigation'],
'🛑 Parar GPS + Navegação':['🛑 Arrêter GPS + Navigation','🛑 Ferma GPS + Navigazione','🛑 Detener GPS + Navegación','🛑 GPS + Navigation stoppen','🛑 Stop GPS + Navigation'],
'A ligar GPS…':['Connexion GPS…','Connessione GPS…','Conectando GPS…','GPS wird verbunden…','Connecting GPS…'],
'Sem rota, o botão mostra a tua posição e velocidade. Cria um passeio para receber orientação experimental no mapa.':['Sans itinéraire, voir position et vitesse. Crée une balade pour le guidage expérimental.','Senza percorso, mostra posizione e velocità. Crea un giro per la guida sperimentale.','Sin ruta, muestra ubicación y velocidad. Crea una ruta para recibir indicaciones.','Ohne Route zeigt es Standort und Tempo. Erstelle eine Tour für experimentelle Führung.','Without a route, see your position and speed. Create a ride for experimental guidance.'],
'GPS ativo nesta página. Não é uma navegação certificada e pode parar com o ecrã bloqueado.':['GPS actif ici. La navigation n’est pas certifiée et peut s’arrêter si l’écran se verrouille.','GPS attivo. Non è un navigatore certificato; può fermarsi a schermo bloccato.','GPS activo. No es navegación certificada y puede detenerse con pantalla bloqueada.','GPS aktiv. Keine zertifizierte Navigation; kann bei gesperrtem Bildschirm stoppen.','GPS running. Not certified navigation; may stop when the screen locks.'],
'Ativa a localização e autoriza a AlpRiders CH no Android.':['Ouvre l’app en HTTPS et autorise la localisation.','Apri in HTTPS e autorizza la posizione.','Abre por HTTPS y permite la ubicación.','Per HTTPS öffnen und Standort erlauben.','Open over HTTPS and allow location access.'],
'GPS ligado. Cria um passeio para iniciar a navegação.':['GPS actif. Crée une balade pour naviguer.','GPS attivo. Crea un percorso per navigare.','GPS activo. Crea una ruta para navegar.','GPS aktiv. Erstelle eine Route zur Navigation.','GPS on. Create a ride to begin navigation.'],
'GPS ligado; não foi possível iniciar a orientação da rota.':['GPS actif ; guidage de l’itinéraire indisponible.','GPS attivo; guida percorso non disponibile.','GPS activo; no se pudo iniciar la guía.','GPS aktiv; Routenführung nicht verfügbar.','GPS on; route guidance could not start.'],
'Não foi possível ligar o GPS. Confirma as permissões e usa HTTPS.':['GPS indisponible. Vérifie les autorisations et HTTPS.','GPS non disponibile. Controlla permessi e HTTPS.','GPS no disponible. Revisa permisos y HTTPS.','GPS nicht verfügbar. Berechtigungen und HTTPS prüfen.','GPS unavailable. Check permissions and HTTPS.'],
'🧭 Navegação dentro da app':['🧭 Navigation intégrée','🧭 Navigazione integrata','🧭 Navegación integrada','🧭 Navigation in der App','🧭 In-app navigation'],
'A aguardar GPS…':['En attente du GPS…','In attesa del GPS…','Esperando GPS…','Warte auf GPS…','Waiting for GPS…'],
'Terminar navegação':['Arrêter la navigation','Termina navigazione','Terminar navegación','Navigation beenden','End navigation'],
'Mapa da Suíça':['Carte de Suisse','Mappa Svizzera','Mapa de Suiza','Schweiz-Karte','Swiss map'],
'O mapa precisa de ligação à Internet.':['Carte : connexion Internet nécessaire.','La mappa richiede Internet.','El mapa necesita Internet.','Karte benötigt Internet.','Map needs internet.'],
'🧭 Criar um percurso':['🧭 Créer un trajet','🧭 Crea un percorso','🧭 Crear ruta','🧭 Route erstellen','🧭 Create route'],
'Marca a partida e o destino tocando no mapa, ou experimenta uma sugestão.':['Indique départ et arrivée sur la carte.','Seleziona partenza e arrivo sulla mappa.','Marca salida y llegada en el mapa.','Start und Ziel auf der Karte markieren.','Tap start and finish on the map.'],
'Limpar':['Effacer','Cancella','Borrar','Löschen','Clear'],
'Ver rota →':['Voir trajet →','Vedi percorso →','Ver ruta →','Route ansehen →','View route →'],
'Planeia o passeio':['Planifie ta balade','Pianifica il giro','Planifica tu ruta','Plane deine Tour','Plan your ride'],
'As minhas rotas':['Mes itinéraires','I miei percorsi','Mis rutas','Meine Routen','My routes'],
'Nova rota':['Nouvel itinéraire','Nuovo percorso','Nueva ruta','Neue Route','New route'],
'Distância estimada':['Distance estimée','Distanza stimata','Distancia estimada','Geschätzte Distanz','Estimated distance'],
'Tempo estimado':['Temps estimé','Tempo stimato','Tiempo estimado','Geschätzte Zeit','Estimated time'],
'Nome da rota':['Nom du trajet','Nome del percorso','Nombre de la ruta','Routenname','Route name'],
'Calcular estrada':['Calculer l’itinéraire','Calcola percorso','Calcular ruta','Route berechnen','Calculate road route'],
'Desfazer ponto':['Annuler point','Annulla punto','Deshacer punto','Punkt zurück','Undo point'],
'🔁 Regresso ao ponto de partida (passeio circular)':['🔁 Retour au point de départ (circuit)','🔁 Ritorno al punto di partenza (giro)','🔁 Regreso al punto de partida (circular)','🔁 Zurück zum Ausgangspunkt (Rundtour)','🔁 Return to starting point (round trip)'],
'Para voltar por estradas diferentes, marca a partida e pelo menos dois pontos intermédios; depois calcula a estrada.':['Pour boucler sans reprendre tout le même chemin, choisis le départ et deux points intermédiaires avant le calcul.','Per un percorso ad anello, segna la partenza e almeno due tappe prima di calcolare.','Para hacer una ruta circular, marca la salida y al menos dos puntos intermedios antes de calcular.','Für eine Rundtour Start und mindestens zwei Zwischenziele setzen, dann berechnen.','For a loop, mark the start and at least two intermediate stops, then calculate.'],
'Guardar no telemóvel':['Enregistrer sur ce téléphone','Salva sul telefono','Guardar en el móvil','Auf Handy speichern','Save on phone'],
'Exportar GPX':['Exporter GPX','Esporta GPX','Exportar GPX','GPX exportieren','Export GPX'],
'Percursos guardados':['Itinéraires enregistrés','Percorsi salvati','Rutas guardadas','Gespeicherte Routen','Saved routes'],
'Comunidade privada':['Communauté privée','Comunità privata','Comunidad privada','Private Community','Private community'],
'Grupos de motards':['Groupes de motards','Gruppi motociclisti','Grupos de moteros','Motorradgruppen','Rider groups'],
'Cria o teu grupo, escolhe quem participa e conversa com os membros. Grupos reais necessitam de ligação segura online.':['Crée ton groupe privé et discute avec les membres. Un serveur sécurisé est nécessaire pour de vrais groupes.','Crea un gruppo privato e chatta. Per gruppi veri serve un server sicuro.','Crea grupos privados y conversa. Para conectar móviles se necesita servidor seguro.','Erstelle private Gruppen und chatte. Echte Gruppen benötigen einen sicheren Server.','Create private groups and chat. Real multi-device groups require a secure server.'],
'Modo de demonstração:':['Mode démo :','Modalità demo:','Modo demo:','Demo-Modus:','Demo mode:'],
'grupos e mensagens ficam apenas neste telemóvel. Não são partilhados com outros motards.':['les groupes et messages restent sur ce téléphone uniquement.','gruppi e messaggi rimangono su questo dispositivo.','los grupos y mensajes quedan solo en este móvil.','Gruppen und Nachrichten bleiben nur auf diesem Handy.','groups and messages stay on this device only.'],
'🔒 Criar grupo privado':['🔒 Créer un groupe privé','🔒 Crea gruppo privato','🔒 Crear grupo privado','🔒 Private Gruppe erstellen','🔒 Create private group'],
'Nome do grupo':['Nom du groupe','Nome gruppo','Nombre del grupo','Gruppenname','Group name'],
'Descrição (opcional)':['Description (facultatif)','Descrizione (opzionale)','Descripción (opcional)','Beschreibung (optional)','Description (optional)'],
'+ Criar grupo':['+ Créer groupe','+ Crea gruppo','+ Crear grupo','+ Gruppe erstellen','+ Create group'],
'Os meus grupos':['Mes groupes','I miei gruppi','Mis grupos','Meine Gruppen','My groups'],
'Ainda não tens grupos.':['Aucun groupe pour l’instant.','Nessun gruppo ancora.','Todavía no tienes grupos.','Noch keine Gruppen.','No groups yet.'],
'Código de convite privado':['Code d’invitation privé','Codice invito privato','Código de invitación privado','Privater Einladungscode','Private invite code'],
'Entrar com convite':['Rejoindre avec un code','Entra con invito','Entrar con invitación','Mit Code beitreten','Join with invite'],
'🔒 Privado':['🔒 Privé','🔒 Privato','🔒 Privado','🔒 Privat','🔒 Private'],
'Copiar convite':['Copier l’invitation','Copia invito','Copiar invitación','Einladung kopieren','Copy invite'],
'Atualizar chat':['Actualiser le chat','Aggiorna chat','Actualizar chat','Chat aktualisieren','Refresh chat'],
'Modo local: o convite não funciona noutros telemóveis.':['Mode local : l’invitation ne fonctionne pas sur d’autres téléphones.','Modalità locale: l’invito non funziona su altri telefoni.','Modo local: la invitación no funciona en otros móviles.','Lokal: Einladungen funktionieren nicht auf anderen Handys.','Local mode: invites do not work on other phones.'],
'Sair do grupo':['Quitter le groupe','Esci dal gruppo','Salir del grupo','Gruppe verlassen','Leave group'],
'🌐 Ativar grupos reais entre telemóveis (avançado)':['🌐 Activer les groupes réels (avancé)','🌐 Attiva gruppi reali (avanzato)','🌐 Activar grupos reales (avanzado)','🌐 Echte Gruppen aktivieren (erweitert)','🌐 Enable real groups (advanced)'],
'Ligar servidor':['Connecter le serveur','Collega server','Conectar servidor','Server verbinden','Connect server'],
'Sem sessão online.':['Non connecté.','Nessuna sessione online.','Sin sesión online.','Nicht angemeldet.','Not signed in.'],
'Nome visível no grupo':['Pseudo visible','Nome visibile','Nombre visible','Anzeigename','Display name'],
'Palavra-passe':['Mot de passe','Password','Contraseña','Passwort','Password'],
'Entrar':['Connexion','Accedi','Entrar','Anmelden','Sign in'],
'Criar conta':['Créer un compte','Crea account','Crear cuenta','Konto erstellen','Sign up'],
'Sair':['Déconnexion','Esci','Salir','Abmelden','Sign out'],
'O teu espaço':['Ton espace','Il tuo spazio','Tu espacio','Dein Bereich','Your space'],
'Perfil motard':['Profil motard','Profilo motociclista','Perfil motero','Fahrerprofil','Rider profile'],
'Perfil local de teste':['Profil de démo local','Profilo demo locale','Perfil demo local','Lokales Demo-Profil','Local demo profile'],
'Nome de motard':['Pseudo motard','Nome motociclista','Nombre motero','Fahrername','Rider nickname'],
'A minha mota':['Ma moto','La mia moto','Mi moto','Mein Motorrad','My bike'],
'Cantão':['Canton','Cantone','Cantón','Kanton','Canton'],
'Guardar perfil':['Enregistrer le profil','Salva profilo','Guardar perfil','Profil speichern','Save profile'],
'Privacidade em primeiro lugar':['Vie privée d’abord','Privacy prima di tutto','Privacidad ante todo','Datenschutz zuerst','Privacy first'],
'Instalar no ecrã inicial':['Installer sur l’écran d’accueil','Installa sulla schermata Home','Instalar en inicio','Zum Startbildschirm hinzufügen','Add to home screen'],
'Instalar':['Installer','Installa','Instalar','Installieren','Install'],
'Segurança na viagem':['Sécurité en route','Sicurezza in viaggio','Seguridad en ruta','Sicherheit auf Tour','Ride safety'],
'🆘 Emergência':['🆘 Urgence','🆘 Emergenza','🆘 Emergencia','🆘 Notfall','🆘 Emergency'],
'Precisas de ajuda agora?':['Besoin d’aide maintenant ?','Hai bisogno di aiuto?','¿Necesitas ayuda ahora?','Brauchst du jetzt Hilfe?','Need help now?'],
'📞 Ligar 112':['📞 Appeler le 112','📞 Chiama 112','📞 Llamar 112','📞 112 anrufen','📞 Call 112'],
'🚑 Ambulância 144':['🚑 Ambulance 144','🚑 Ambulanza 144','🚑 Ambulancia 144','🚑 Ambulanz 144','🚑 Ambulance 144'],
'📍 Posição para enviar':['📍 Position à envoyer','📍 Posizione da inviare','📍 Ubicación para enviar','📍 Standort zum Teilen','📍 Location to share'],
'Atualizar GPS':['Actualiser GPS','Aggiorna GPS','Actualizar GPS','GPS aktualisieren','Refresh GPS'],
'Partilhar posição':['Partager la position','Condividi posizione','Compartir ubicación','Standort teilen','Share location'],
'Copiar mensagem':['Copier le message','Copia messaggio','Copiar mensaje','Nachricht kopieren','Copy message'],
'👥 Os meus 3 contactos':['👥 Mes 3 contacts','👥 I miei 3 contatti','👥 Mis 3 contactos','👥 Meine 3 Kontakte','👥 My 3 contacts'],
'Guardar contactos':['Enregistrer contacts','Salva contatti','Guardar contactos','Kontakte speichern','Save contacts'],
'Envio manual:':['Envoi manuel :','Invio manuale:','Envío manual:','Manueller Versand:','Manual sending:'],
'⚠️ Deteção de acidente: ainda não disponível':['⚠️ Détection de chute indisponible','⚠️ Rilevamento incidenti non disponibile','⚠️ Detección de accidente no disponible','⚠️ Unfallerkennung nicht verfügbar','⚠️ Crash detection unavailable'],
'Mapa':['Carte','Mappa','Mapa','Karte','Map'],
'Rotas':['Trajets','Percorsi','Rutas','Routen','Routes'],
'Grupos':['Groupes','Gruppi','Grupos','Gruppen','Groups'],
'Perfil':['Profil','Profilo','Perfil','Profil','Profile'],
'LOCAL':['LOCAL','LOCALE','LOCAL','LOKAL','LOCAL'],
'Nome':['Nom','Nome','Nombre','Name','Name'],
'Nome de motard':['Pseudo','Nickname','Apodo','Spitzname','Nickname'],
'Eu':['Moi','Io','Yo','Ich','Me'],
'Email':['E-mail','Email','Correo','E-Mail','Email'],
'Mensagem para o grupo...':['Message au groupe…','Messaggio per gruppo…','Mensaje para el grupo…','Nachricht an Gruppe…','Message to group…'],
'Ex.: Motards do Valais':['Ex. : Motards du Valais','Es.: Motociclisti del Vallese','Ej.: Moteros del Valais','Z. B. Motorradfahrer Wallis','E.g. Valais Riders'],
'Ex.: Passeios aos domingos':['Ex. : sorties du dimanche','Es.: giri domenicali','Ej.: rutas los domingos','Z. B. Sonntagsfahrten','E.g. Sunday rides'],
'Código enviado pelo administrador':['Code envoyé par l’admin','Codice dall’amministratore','Código del administrador','Code vom Admin','Code from the group admin'],
};
Object.assign(i18n,{
'Cria, guarda e exporta percursos. Nesta versão ficam apenas neste telemóvel.':['Crée, enregistre et exporte des trajets sur ce téléphone.','Crea, salva ed esporta percorsi su questo telefono.','Crea, guarda y exporta rutas en este teléfono.','Routen erstellen, speichern und von diesem Handy exportieren.','Create, save and export routes on this phone.'],
'Os números ficam guardados apenas neste dispositivo. Introduz o indicativo, por exemplo +41.':['Les numéros restent sur cet appareil. Ajoute l’indicatif +41.','I numeri restano sul dispositivo. Usa prefisso +41.','Los números quedan en el dispositivo. Usa +41.','Nummern bleiben auf dem Gerät. Mit +41 eingeben.','Numbers stay on this device. Include +41.'],
'Prepara contactos de confiança e partilha a tua posição GPS quando precisas de ajuda.':['Prépare des contacts de confiance et partage ta position en cas de besoin.','Salva contatti fidati e condividi la posizione se hai bisogno di aiuto.','Configura contactos de confianza y comparte tu ubicación si necesitas ayuda.','Notfallkontakte speichern und bei Bedarf den Standort teilen.','Prepare trusted contacts and share your location when you need help.'],
'Personaliza a tua experiência. Os dados ficam guardados apenas neste dispositivo.':['Personnalise ton profil. Les données restent sur cet appareil.','Personalizza il tuo profilo. Dati salvati solo su questo dispositivo.','Personaliza tu perfil. Los datos quedan en este dispositivo.','Passe dein Profil an. Daten bleiben auf diesem Gerät.','Customize your profile. Data stays on this device.'],
'Os membros só podem ler chats dos grupos a que pertencem.':['Seuls les membres peuvent lire les conversations de leur groupe.','Solo i membri possono leggere i messaggi del loro gruppo.','Solo miembros pueden leer mensajes de su grupo.','Nur Mitglieder dürfen ihren Gruppenchat lesen.','Only members can read their group chats.'],
'O registo pode exigir confirmação por email. Os membros só podem ler chats dos grupos a que pertencem.':['Une confirmation par e-mail peut être nécessaire. Seuls les membres accèdent aux chats de leurs groupes.','La registrazione può richiedere verifica email. Solo membri vedono i messaggi del gruppo.','Puede ser necesario confirmar por correo. Solo miembros ven su chat de grupo.','Registrierung erfordert ggf. E-Mail-Bestätigung. Nur Mitglieder lesen den Gruppenchat.','Email confirmation may be required. Only group members can read their messages.'],
'Para chat real, um administrador precisa de criar um projeto Supabase e aplicar as regras de privacidade incluídas no pacote ZIP. Sem servidor não é possível conversar entre telemóveis.':['Pour le chat réel, un administrateur doit configurer Supabase avec les règles de sécurité du ZIP.','Per chat reale, un amministratore deve configurare Supabase con le regole nel ZIP.','Para chat real, un administrador debe configurar Supabase con las reglas del ZIP.','Für echten Chat muss ein Admin Supabase mit den Sicherheitsregeln im ZIP einrichten.','For real chat, an admin must configure Supabase and apply the security rules in the ZIP.'],
'O registo pode exigir confirmação por email.':['La confirmation par email peut être requise.','Potrebbe servire conferma email.','Puede requerirse confirmación por correo.','E-Mail-Bestätigung kann nötig sein.','Email confirmation may be needed.'],
'Os números ficam guardados apenas neste dispositivo.':['Les numéros restent sur cet appareil.','I numeri restano su questo dispositivo.','Los números quedan en este dispositivo.','Nummern bleiben auf diesem Gerät.','Numbers stay on this device.'],
'Os contactos guardam-se apenas neste telemóvel.':['Les contacts restent sur ce téléphone.','I contatti restano su questo telefono.','Los contactos quedan en este móvil.','Kontakte bleiben auf diesem Handy.','Contacts remain on this phone.'],
'Mantém a app aberta, com localização autorizada. Indicações aproximadas.':['Laisse l’app ouverte et autorise le GPS. Indications approximatives.','Tieni l’app aperta e autorizza il GPS. Indicazioni approssimative.','Mantén la app abierta y permite el GPS. Indicaciones aproximadas.','App geöffnet lassen und GPS erlauben. Nur ungefähre Anweisungen.','Keep the app open and allow GPS. Approximate guidance.'],
'Este chat está vazio. Envia a primeira mensagem.':['Ce chat est vide. Envoie un message.','Chat vuota. Invia un messaggio.','Chat vacío. Envía un mensaje.','Der Chat ist leer. Schreibe etwas.','No messages yet. Start the conversation.'],
'Online privado':['Privé en ligne','Privato online','Privado online','Privat online','Private online'],
'Só neste telemóvel':['Sur cet appareil seulement','Solo su questo dispositivo','Solo en este móvil','Nur auf diesem Handy','This device only'],
'Ligado: os grupos e mensagens são partilhados apenas com membros autorizados.':['Connecté : seules les personnes autorisées accèdent aux groupes et messages.','Connesso: solo membri autorizzati accedono ai gruppi e messaggi.','Conectado: solo miembros autorizados acceden a grupos y mensajes.','Verbunden: nur autorisierte Mitglieder lesen Gruppen und Nachrichten.','Connected: only authorized members can access groups and messages.'],
'Copia o código e partilha-o apenas com quem quiseres no grupo.':['Partage le code uniquement avec les invités.','Condividi il codice solo con gli invitati.','Comparte el código solo con invitados.','Code nur an eingeladene Mitglieder geben.','Share the code only with invited members.'],
'Apagar grupo para todos':['Supprimer pour tous','Elimina per tutti','Eliminar para todos','Gruppe für alle löschen','Delete group for everyone'],
'Grupo de demonstração criado neste telemóvel.':['Groupe démo créé sur cet appareil.','Gruppo demo creato sul dispositivo.','Grupo demo creado en el móvil.','Demo-Gruppe auf diesem Handy erstellt.','Demo group created on this phone.'],
'Grupo privado online criado. Partilha apenas o código de convite.':['Groupe privé créé. Partage le code avec les invités.','Gruppo privato creato. Condividi il codice solo con invitati.','Grupo privado creado. Comparte el código solo con invitados.','Private Gruppe erstellt. Code nur an Eingeladene geben.','Private online group created. Share the code only with invitees.'],
'Introduz um email válido e palavra-passe de pelo menos 8 caracteres.':['E-mail valide et mot de passe de 8 caractères minimum.','Email valido e password di almeno 8 caratteri.','Correo válido y contraseña de mínimo 8 caracteres.','Gültige E-Mail und Passwort mit mindestens 8 Zeichen.','Use a valid email and password with at least 8 characters.'],
'Código de convite inválido.':['Code d’invitation invalide.','Codice invito non valido.','Código de invitación inválido.','Ungültiger Einladungscode.','Invalid invite code.'],
'Código copiado. Partilha-o apenas com os convidados.':['Code copié. Partage-le uniquement aux invités.','Codice copiato. Solo con gli invitati.','Código copiado. Solo con invitados.','Code kopiert. Nur mit Eingeladenen teilen.','Code copied. Share only with invitees.'],
'Código de convite:':['Code d’invitation :','Codice invito:','Código de invitación:','Einladungscode:','Invite code:'],
'Já fazes parte do grupo.':['Tu as rejoint le groupe.','Ora fai parte del gruppo.','Ya formas parte del grupo.','Du bist der Gruppe beigetreten.','You joined the group.'],
'Tens a certeza?':['Es-tu sûr ?','Sei sicuro?','¿Estás seguro?','Bist du sicher?','Are you sure?'],
'Entra numa conta online para usares convites.':['Connecte-toi pour utiliser un code.','Accedi per usare gli inviti.','Inicia sesión para usar invitaciones.','Für Einladungen bitte anmelden.','Sign in to use invites.'],
'Entra na tua conta antes de criar grupos.':['Connecte-toi avant de créer des groupes.','Accedi prima di creare gruppi.','Inicia sesión antes de crear grupos.','Vor dem Erstellen bitte anmelden.','Sign in before creating groups.'],
'Verifica o email para confirmar a conta antes de entrar.':['Confirme ton e-mail avant connexion.','Conferma l’email prima di accedere.','Confirma tu correo antes de entrar.','Bitte E-Mail vor Anmeldung bestätigen.','Confirm your email before signing in.'],
'O nome do grupo precisa de pelo menos 3 caracteres.':['Le nom du groupe doit contenir au moins 3 caractères.','Il nome deve avere almeno 3 caratteri.','El nombre necesita al menos 3 caracteres.','Gruppenname mindestens 3 Zeichen.','Group name needs at least 3 characters.'],
'Sessão online ativa.':['Session en ligne active.','Sessione online attiva.','Sesión online activa.','Online-Anmeldung aktiv.','Online session active.'],
'Servidor ligado. Entra ou cria conta para ativar grupos online.':['Serveur connecté. Connecte-toi ou inscris-toi.','Server connesso. Accedi o registrati.','Servidor conectado. Entra o regístrate.','Server verbunden. Anmelden oder registrieren.','Server connected. Sign in or sign up.'],
'Bem-vindo aos grupos online.':['Bienvenue dans les groupes en ligne.','Benvenuto nei gruppi online.','Bienvenido a los grupos online.','Willkommen bei Online-Gruppen.','Welcome to online groups.'],
});
const languages={pt:0,fr:0,it:1,es:2,de:3,en:4};
let selectedLanguage=safeRead('lang','pt');if(!Object.hasOwn(languages,selectedLanguage))selectedLanguage='pt';
const originalNodes=new WeakMap();const originalAttrs=new WeakMap();
function tstr(v){return selectedLanguage==='pt'?v:(i18n[v]?.[languages[selectedLanguage]]||v)}
function translatePage(){document.documentElement.lang=selectedLanguage;
 let walker=document.createTreeWalker(document.querySelector('.app'),NodeFilter.SHOW_TEXT);
 while(walker.nextNode()){
  const node=walker.currentNode;
  if(node.parentNode?.closest?.('#group-chatlog,#groups-list,.listitem'))continue;
  const orig=originalNodes.get(node)??node.textContent.trim();if(!originalNodes.has(node))originalNodes.set(node,orig);
  if(!Object.hasOwn(i18n,orig))continue;
  const m=node.textContent.match(/^(\s*)(.*?)(\s*)$/s);node.textContent=(m?.[1]||'')+tstr(orig)+(m?.[3]||'');
 }
 for(const el of document.querySelectorAll('[placeholder],[aria-label],[title]')){
  let old=originalAttrs.get(el);if(!old){old={};for(const a of ['placeholder','aria-label','title'])if(el.hasAttribute(a))old[a]=el.getAttribute(a);originalAttrs.set(el,old)}
  for(const [key,v] of Object.entries(old))if(Object.hasOwn(i18n,v))el.setAttribute(key,tstr(v));
 }
 $('language-picker').value=selectedLanguage;
}
$('language-picker').value=selectedLanguage;
$('language-picker').addEventListener('change',e=>{selectedLanguage=e.target.value;save('lang',selectedLanguage);translatePage();renderGroupUI();renderSmsButtons();});

// --- Private groups: on-device demo and optional secure online Supabase groups ---
const groupKey='private-groups-v1';
let localGroups=safeRead(groupKey,[]),currentGroupId=null, onlineGroups=[],groupSession=null,sb=null,online=false,groupChannel=null;
let onlineConfig=safeRead('online-group-config',{url:'',key:''});
$('sb-url').value=onlineConfig.url||'';$('sb-key').value=onlineConfig.key||'';
$('auth-nick').value=profile.nick||'';
function activeGroups(){return online?onlineGroups:localGroups}
function activeGroup(){return activeGroups().find(g=>String(g.id)===String(currentGroupId))||null}
function randomCode(){const alphabet='ABCDEFGHJKMNPQRSTUVWXYZ23456789';const array=new Uint8Array(24);crypto.getRandomValues(array);return Array.from(array,n=>alphabet[n%alphabet.length]).join('')}
function makeChip(group){const b=document.createElement('button');b.type='button';b.className='group-chip'+(String(group.id)===String(currentGroupId)?' selected':'');
 const name=document.createElement('b');name.textContent='🔒 '+group.name;b.append(name);
 const sub=document.createElement('small');sub.textContent=(group.description||'')+' · '+(online?tstr('Online privado'):tstr('Só neste telemóvel'));b.append(sub);
 b.addEventListener('click',()=>{currentGroupId=group.id;renderGroupUI();if(online)subscribeGroup(group.id)});return b;
}
function groupNotices(){const notice=$('groups-mode-notice');
 if(online&&groupSession){notice.innerHTML='';notice.textContent='🔐 '+tstr('Ligado: os grupos e mensagens são partilhados apenas com membros autorizados.');}
 else{notice.innerHTML='';const b=document.createElement('b');b.textContent=tstr('Modo de demonstração:');notice.append('🧪 ',b,' '+tstr('grupos e mensagens ficam apenas neste telemóvel. Não são partilhados com outros motards.'));}
 $('groups-mode-pill').textContent=online?'ONLINE':tstr('LOCAL');$('groups-join-wrap').hidden=!online;
 $('group-demo-warning').textContent=online?tstr('Copia o código e partilha-o apenas com quem quiseres no grupo.'):tstr('Modo local: o convite não funciona noutros telemóveis.');
 $('group-copy-code').hidden=!online;
 $('group-leave').textContent=online&&activeGroup()?.created_by===groupSession?.user?.id?tstr('Apagar grupo para todos'):tstr('Sair do grupo');
}
function renderGroupMessages(group){const box=$('group-chatlog');box.replaceChildren();const arr=group.messages||[];
 if(!arr.length){const p=document.createElement('div');p.className='bubble system';p.textContent=tstr('Este chat está vazio. Envia a primeira mensagem.');box.append(p);}
 else for(const message of arr){const bubble=document.createElement('div');bubble.className='bubble';
  const para=document.createElement('div');para.textContent=message.body;const meta=document.createElement('div');meta.className='bubblemeta';
  meta.textContent=(message.sender_name||'Motard')+' · '+new Date(message.created_at).toLocaleString(selectedLanguage,{hour:'2-digit',minute:'2-digit',day:'2-digit',month:'2-digit'});
  bubble.append(para,meta);box.append(bubble)}box.scrollTop=box.scrollHeight;
}
function renderGroupUI(){groupNotices();const list=$('groups-list');list.replaceChildren();const gs=activeGroups();
 if(!gs.length){const p=document.createElement('p');p.className='tiny muted';p.textContent=tstr('Ainda não tens grupos.');list.append(p)}
 else for(const g of gs)list.append(makeChip(g));
 if(currentGroupId&&!activeGroup())currentGroupId=null;
 const g=activeGroup();$('group-chat-card').hidden=!g;
 if(g){$('selected-group-name').textContent=g.name;$('selected-group-desc').textContent=g.description||'';
 renderGroupMessages(g)}
 translatePage();
}
$('group-create').onclick=async()=>{
 const name=$('group-name').value.trim().slice(0,50),desc=$('group-desc').value.trim().slice(0,240);
 if(name.length<3){toast(tstr('O nome do grupo precisa de pelo menos 3 caracteres.'));return;}
 if(!online){const g={id:(crypto.randomUUID?.()||Date.now().toString(36)),name,description:desc,created_at:new Date().toISOString(),messages:[]};localGroups.unshift(g);save(groupKey,localGroups);currentGroupId=g.id;renderGroupUI();toast(tstr('Grupo de demonstração criado neste telemóvel.'));}
 else{
  if(!groupSession){toast(tstr('Entra na tua conta antes de criar grupos.'));return;}
  const code=randomCode();const uid=groupSession.user.id;
  const {data,error}=await sb.from('rider_groups').insert({name,description:desc,invite_code:code,created_by:uid}).select().single();
  if(error){toast(tstr('Não foi possível criar grupo: ')+error.message);return;}
  const membership=await sb.from('rider_group_members').insert({group_id:data.id,user_id:uid,role:'admin'});
  if(membership.error){await sb.from('rider_groups').delete().eq('id',data.id);toast(tstr('Não foi possível confirmar a inscrição no grupo.'));return;}
  currentGroupId=data.id;await fetchOnlineGroups();toast(tstr('Grupo privado online criado. Partilha apenas o código de convite.'));
 }
 $('group-name').value='';$('group-desc').value='';
};
$('group-send-form').addEventListener('submit',async e=>{e.preventDefault();const group=activeGroup();if(!group)return;
 const text=$('group-message').value.trim().slice(0,1000);if(!text)return;
 if(!online){group.messages.push({body:text,sender_name:profile.nick||tstr('Eu'),created_at:new Date().toISOString()});group.messages=group.messages.slice(-250);save(groupKey,localGroups);$('group-message').value='';renderGroupUI();}
 else {if(!groupSession){toast(tstr('Tens de iniciar sessão.'));return;}
 const result=await sb.from('rider_group_messages').insert({group_id:group.id,sender_id:groupSession.user.id,sender_name:($('auth-nick').value.trim()||profile.nick||'Motard').slice(0,32),body:text});
 if(result.error){toast(result.error.message);return;}$('group-message').value='';await fetchMessages(group.id);}
});
$('group-refresh').onclick=async()=>{if(online&&activeGroup())await fetchMessages(activeGroup().id);else renderGroupUI();};
$('group-copy-code').onclick=async()=>{const g=activeGroup();if(!online||!g)return toast(tstr('Os convites só funcionam nos grupos online.'));
 try{await navigator.clipboard.writeText(g.invite_code);toast(tstr('Código copiado. Partilha-o apenas com os convidados.'));}catch{prompt(tstr('Código de convite:'),g.invite_code)};
};
$('group-leave').onclick=async()=>{const g=activeGroup();if(!g)return;
 if(!confirm(tstr('Tens a certeza?')))return;
 if(!online){localGroups=localGroups.filter(x=>x.id!==g.id);save(groupKey,localGroups);currentGroupId=null;renderGroupUI();return;}
 if(!groupSession)return;
 let resp;
 if(g.created_by===groupSession.user.id)resp=await sb.from('rider_groups').delete().eq('id',g.id);
 else resp=await sb.from('rider_group_members').delete().eq('group_id',g.id).eq('user_id',groupSession.user.id);
 if(resp.error){toast(resp.error.message);return;}currentGroupId=null;await fetchOnlineGroups();
};
async function loadSB(){if(window.supabase?.createClient)return window.supabase;
 return new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js';script.onload=()=>window.supabase?.createClient?resolve(window.supabase):reject(Error('library'));script.onerror=()=>reject(Error('connection'));document.head.append(script)});
}
async function connectBackend(){let url=$('sb-url').value.trim().replace(/\/$/,''),key=$('sb-key').value.trim();
 if(!/^https:\/\/[\w-]+\.supabase\.co$/.test(url)||!key||/service_role/i.test(key)){toast(tstr('Usa o endereço HTTPS do Supabase e uma chave publishable/anon. Nunca uses a chave service_role.'));return;}
 try{const sdk=await loadSB();sb=sdk.createClient(url,key,{auth:{persistSession:true,autoRefreshToken:true}});onlineConfig={url,key};save('online-group-config',onlineConfig);
 const resp=await sb.auth.getSession();if(resp.error)throw resp.error;groupSession=resp.data.session;online=Boolean(groupSession);
 $('auth-status').textContent=groupSession?tstr('Sessão online ativa.'):tstr('Servidor ligado. Entra ou cria conta para ativar grupos online.');
 if(online)await fetchOnlineGroups();else renderGroupUI();toast(tstr('Servidor configurado.'));
 }catch(err){online=false;sb=null;toast(tstr('Falha na ligação: ')+(err?.message||''));renderGroupUI()}
}
$('sb-connect').onclick=connectBackend;
async function userAuth(signup){if(!sb){await connectBackend();if(!sb)return;}
 const email=$('auth-email').value.trim(),password=$('auth-password').value,nick=$('auth-nick').value.trim().slice(0,32);
 if(!email.includes('@')||password.length<8){toast(tstr('Introduz um email válido e palavra-passe de pelo menos 8 caracteres.'));return;}
 const response=signup?await sb.auth.signUp({email,password,options:{data:{nick}}}):await sb.auth.signInWithPassword({email,password});
 if(response.error){toast(response.error.message);return;}
 const info=await sb.auth.getSession();groupSession=info.data.session;
 if(groupSession){online=true;currentGroupId=null;await fetchOnlineGroups();$('auth-status').textContent=tstr('Sessão online ativa.');toast(tstr('Bem-vindo aos grupos online.'));}
 else{online=false;renderGroupUI();toast(tstr('Verifica o email para confirmar a conta antes de entrar.'));}
}
$('sb-login').onclick=()=>userAuth(false);$('sb-signup').onclick=()=>userAuth(true);
$('sb-logout').onclick=async()=>{if(sb)await sb.auth.signOut();groupSession=null;online=false;currentGroupId=null;onlineGroups=[];
 if(groupChannel&&sb)await sb.removeChannel(groupChannel);groupChannel=null;renderGroupUI();$('auth-status').textContent=tstr('Sem sessão online.');};
$('group-join').onclick=async()=>{if(!online||!groupSession)return toast(tstr('Entra numa conta online para usares convites.'));
 const code=$('group-code').value.trim().toUpperCase();if(code.length!==24)return toast(tstr('Código de convite inválido.'));
 const {data,error}=await sb.rpc('join_rider_group',{code_input:code});if(error){toast(error.message);return;}
 currentGroupId=data;$('group-code').value='';await fetchOnlineGroups();toast(tstr('Já fazes parte do grupo.'));
};
async function fetchOnlineGroups(){if(!sb||!groupSession)return;
 const memberResp=await sb.from('rider_group_members').select('group_id').eq('user_id',groupSession.user.id);
 if(memberResp.error){toast(memberResp.error.message);return;}
 const ids=memberResp.data.map(x=>x.group_id);
 if(ids.length){const result=await sb.from('rider_groups').select('id,name,description,invite_code,created_by').in('id',ids).order('name');
 if(result.error){toast(result.error.message);return;}onlineGroups=result.data.map(g=>({...g,messages:[]}));}
 else onlineGroups=[];
 if(!activeGroup())currentGroupId=null;
 renderGroupUI();if(activeGroup()){await fetchMessages(currentGroupId);subscribeGroup(currentGroupId)}
}
async function fetchMessages(id){if(!online||!id)return;
 const res=await sb.from('rider_group_messages').select('id,body,sender_name,created_at').eq('group_id',id).order('created_at',{ascending:false}).limit(150);
 if(res.error){toast(res.error.message);return;}
 const g=onlineGroups.find(x=>x.id===id);if(g){g.messages=res.data.reverse();if(String(currentGroupId)===String(id))renderGroupMessages(g)}
}
async function subscribeGroup(id){if(!sb||!id)return;
 if(groupChannel)await sb.removeChannel(groupChannel);
 await fetchMessages(id);
 groupChannel=sb.channel('riders-group-'+id).on('postgres_changes',{event:'INSERT',schema:'public',table:'rider_group_messages',filter:'group_id=eq.'+id},()=>fetchMessages(id)).subscribe();
}
const originalTab=tab;tab=function(k){originalTab(k);if(k==='chat'&&online&&activeGroup())fetchMessages(currentGroupId)};
renderGroupUI();translatePage();
if(onlineConfig.url&&onlineConfig.key&&location.protocol==='https:'){setTimeout(()=>connectBackend().catch(()=>{}),600);}

