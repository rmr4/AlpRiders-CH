const assert=require('node:assert/strict');
require('../app/src/main/assets/ride-utils.js');
require('../app/src/main/assets/detour-utils.js');
require('../app/src/main/assets/swiss-borders.js');
require('../app/src/main/assets/allowed-countries.js');
require('../app/src/main/assets/route-recovery.js');
const {AlpRouteRecovery:r,AlpRideUtils:u}=global;
// Inject a simple rectangular Swiss-area fixture in place of a network fetch.
global.SwissBorders={safeInside:p=>p[1]>=6&&p[1]<=7,
 everySegmentInside:points=>points.length>=2 && points.every(p=>p[1]>=6&&p[1]<=7)};
const shape={type:'Polygon',coordinates:[[[6,46],[7,46],[7,47],[6,47],[6,46]]]};
// These tests are simulations, NOT proof that a real OSRM service will deliver alternatives.
const inside=[[46.1,6.1],[46.2,6.2],[46.33,6.4],[46.1,6.1]];
const perimeter=[inside,[inside[0],[46.9,6.9],[46.3,6.4],inside[0]],
 [[46.3,6.4],[46.5,6.5],[46.6,6.6],inside[0]]];
const chosen=r.prioritize(perimeter,inside[0],3);
assert.ok(chosen.length>=1,'nearby inside candidates retained');
function route(coords){const geom=coords.map(p=>[p[1],p[0]]);return {geometry:{coordinates:geom},
  distance:12000,duration:1200,legs:[{steps:[{geometry:{coordinates:geom},maneuver:{location:geom[0],type:'depart'}}]}]};}
const good=route([[46.10,6.10],[46.15,6.12],[46.2,6.2]]);
const bad=route([[46.10,6.10],[46.15,7.2],[46.2,6.2]]);
assert.equal(r.fromResponse({routes:[bad]},{}).length,0,'rejects foreign section');
assert.equal(r.fromResponse({routes:[bad,good]},{}).length,1,'valid alternative is retained');
async function mockedRequest(stops){return {routes:[route(stops)]};}
(async()=>{const result=await r.legwise(inside,mockedRequest,{targetMinutes:120,maxOverlap:.90});
assert.ok(result?.swissVerified,'legwise alternative only accepted after checks');
assert.equal(result.steps.length,3,'keeps manoeuvres across legs');
const rejectRequest=async()=>({routes:[bad]});
assert.equal(await r.legwise(inside,rejectRequest,{maxOverlap:.9}),null,'not inventing foreign detour');
console.log('v17 recovery: candidate priority, alternatives, verified legwise route OK');})().catch(e=>{console.error(e);process.exitCode=1});
