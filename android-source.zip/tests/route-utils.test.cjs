const assert=require('node:assert/strict');
require('../app/src/main/assets/ride-utils.js');
const u=globalThis.AlpRideUtils;
const start=[46.200,6.100],a=[46.270,6.140],b=[46.330,6.240];
let route=u.roundTripWaypoints([start,a,b]);
assert.equal(route.length,4);
assert.deepEqual(route[0],route[3]);
assert.equal(u.isClosed(route),true);
assert.deepEqual(u.roundTripWaypoints(route),route);
assert.throws(()=>u.roundTripWaypoints([start,a,start]),/pelo menos dois pontos intermédios/);
assert.throws(()=>u.roundTripWaypoints([start,start,b]),/Afasta os pontos/);
assert.equal(u.parseWhatsappNumber('+41 79 123 45 67'),'41791234567');
assert.equal(u.parseWhatsappNumber('0791234567'),'');
assert.equal(u.parseWhatsappNumber('+41) ;test'), '');
function line(from,to){const n=160;return Array.from({length:n+1},(_,i)=>[from[1]+(to[1]-from[1])*i/n,from[0]+(to[0]-from[0])*i/n]);}
function leg(from,to){return {steps:[{geometry:{coordinates:line(from,to)}}]};}
const realLoop=[leg(start,a),leg(a,b),leg(b,start)];
const shared=[leg(start,a),leg(a,b),leg(b,a),leg(a,start)];
const loopOverlap=u.retraceFraction(realLoop);
const retrace=u.retraceFraction(shared);
assert.ok(loopOverlap<.52,'True triangle should have low overlap: '+loopOverlap);
assert.ok(retrace>.52,'Backtrack should have high overlap: '+retrace);
console.log('PASS: route closure, duplicate waypoint validation, contact number parsing, circuit diversity', {loopOverlap,retrace});
