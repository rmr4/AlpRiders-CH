import ch.alpriders.navigation.SafetyLogic

private fun fix(t:Long,lat:Double=46.205,lon:Double=6.144, speed:Double=0.0,accuracy:Float=7f)=
    SafetyLogic.Fix(lat,lon,speed,accuracy,t)
private fun assertThat(ok:Boolean,message:String){if(!ok)throw IllegalStateException(message)}
fun main(){
    // Starting when the motorcycle has never moved must not trigger an accident alert.
    val parked=SafetyLogic()
    (0L..(28*60_000L) step 30_000L).forEach {t ->
        assertThat(parked.location(fix(t))==null,"Stationary at start must not alarm")
    }
    assertThat(!parked.armed,"Parked app must not arm")

    // 45 seconds riding, followed by >=20 minutes stationary => test alarm.
    val still=SafetyLogic()
    still.location(fix(0, speed=10.0));still.location(fix(46_000,speed=10.0))
    assertThat(still.armed,"Riding arm failed")
    assertThat(still.location(fix(60_000,speed=0.0))==null,"Too early stationarity")
    assertThat(still.location(fix(60_000+19*60_000,speed=0.0))==null,"19 min shouldn't trigger")
    assertThat(still.location(fix(60_000+20*60_000,speed=0.0))==SafetyLogic.Reason.STILL_20_MIN,"20 min should trigger")

    // A real new distance/progress resets the stationary countdown.
    val breaks=SafetyLogic()
    breaks.location(fix(0,speed=9.0));breaks.location(fix(45_000,speed=8.0))
    breaks.location(fix(60_000));breaks.location(fix(19*60_000))
    assertThat(breaks.location(fix(19*60_000+10_000,lon=6.15,speed=5.0))==null,"Movement must reset")
    assertThat(breaks.location(fix(40*60_000,lon=6.15))==null,"First stop sample")
    assertThat(breaks.location(fix(40*60_000+19*60_000,lon=6.15))==null,"second countdown reset")

    // Large uncertainty does not arm or trigger.
    val unreliable=SafetyLogic()
    unreliable.location(fix(0,speed=12.0,accuracy=150f));unreliable.location(fix(50_000,speed=12.0,accuracy=150f))
    assertThat(!unreliable.armed,"Poor GPS cannot arm")

    // A possible impact is only a candidate after GPS-confirmed riding and subsequent stop.
    val impact=SafetyLogic()
    impact.location(fix(0,speed=12.0));impact.location(fix(50_000,speed=12.0))
    impact.impact(52_000)
    assertThat(impact.location(fix(52_000+60_000))==null,"Impact warning too early")
    assertThat(impact.location(fix(52_000+80_000))==SafetyLogic.Reason.POSSIBLE_IMPACT,"Impact candidate should alarm locally")
    println("PASS: parked, stationary 20min, movement reset, inaccurate GPS, impact candidate")
}
