from pathlib import Path
root = Path(__file__).resolve().parents[1]
a = (root/'app/src/main/java/ch/alpriders/navigation/MainActivity.kt').read_text()
b = (root/'app/src/main/java/ch/alpriders/navigation/SafetyMonitorService.kt').read_text()
m = (root/'app/src/main/AndroidManifest.xml').read_text()
for token in ('offerAutoSafetyConsent()', 'safety_choice_seen', 'safety_auto_enabled', 'prefs.getBoolean("safety_auto_enabled", false)', 'startForegroundService(', 'testAlarmDialog?.show()', 'clearTestAlarm()', 'SafetyMonitorService.running'):
    assert token in a, token
assert 'safetyAutoAttempted = true' in a
assert 'if (action == SafetyMonitorService.ACTION_STOP)' in a
assert 'putBoolean("safety_auto_enabled",false)' in a
assert 'setPositiveButton("Estou bem · cancelar")' in a
assert 'showTestAlarm()' in a
assert 'ACTION_START' in b and 'FOREGROUND_SERVICE_TYPE_LOCATION' in b
assert 'NOT_STICKY' in b and 'BOOT_COMPLETED' not in m
assert '<uses-permission android:name="android.permission.POST_NOTIFICATIONS"' in m
assert '"app"' not in m
print('PASS: explicit opt-in, automatic start, manual stop, visible test, foreground service, no boot restart')
