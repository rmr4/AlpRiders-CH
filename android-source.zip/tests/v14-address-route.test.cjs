const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const root=__dirname+'/../app/src/main/assets/';
function read(name){return fs.readFileSync(root+name,'utf8')}
// Stub browser globals only for pure modules.
const context={console,URLSearchParams,AbortController,fetch:async url=>({ok:true,json:async()=>({results:[
 {attrs:{origin:'address',lat:46.205,lon:6.144,label:'Rue du Rhône <b>14</b> Genève',featureId:'123'}},
 {attrs:{origin:'address',lat:46.205,lon:6.144,label:'Rue du Rhône <b>14</b> Genève'}},
 {attrs:{origin:'gazetteer',lat:45.9,lon:6.1,label:'Rue de Test'}},
 {attrs:{origin:'address',lat:48.5,lon:2.2,label:'Paris 123'}}]})})};
vm.createContext(context);
vm.runInContext(read('swiss-address-search.js'),context);
(async()=>{
 const s=context.SwissAddressSearch;
 assert.equal(s.safeLabel('<img src=x onerror=alert(1)> Rue <b>3</b>'), 'Rue 3');
 const rows=s.parseAddressRows({results:[
 {attrs:{origin:'address',lat:46.205,lon:6.144,label:'Rue du Rhône <b>14</b> Genève'}},
 {attrs:{origin:'address',lat:46.205,lon:6.144,label:'Rue du Rhône <b>14</b> Genève'}},
 {attrs:{origin:'gazetteer',lat:46.2,lon:6.1,label:'Geneva'}},
 {attrs:{origin:'address',lat:48.8,lon:2.3,label:'Paris'}}
 ]});
 assert.equal(rows.length,1);
 assert.equal(rows[0].label,'Rue du Rhône 14 Genève');
 assert.deepEqual(Array.from(rows[0].coord),[46.205,6.144]);
 assert.equal((await s.search('Ge')).length,0);
 assert.equal((await s.search('Rue du Rhône 14')).length,1);
 vm.runInContext(read('ride-utils.js'),context);
 const ride=context.AlpRideUtils;
 const A=[46.2,6.2],B=[46.21,6.21],C=[46.22,6.22],D=[46.22,6.19];
 const leg=(p)=>({steps:[{geometry:{coordinates:p.map(x=>[x[1],x[0]])}}]});
 const repeat=ride.retraceFraction([leg([A,B]),leg([B,C]),leg([C,B,A])]);
 const different=ride.retraceFraction([leg([A,B]),leg([B,C]),leg([C,D,A])]);
 assert.ok(repeat>0.8, 'backtrack should be rejected '+repeat);
 assert.ok(different<0.18, 'distinct return should pass '+different);
 const html=read('index.html');
 assert.ok(html.includes('response.returnOverlap>0.27'));
 assert.ok(html.includes('result.returnOverlap>0.18'));
 assert.ok(html.includes('const dest=findExactSwissAddress();'));
 assert.ok(html.includes('swissAddressInput.addEventListener(\'input\''));
 assert.ok(html.includes('aria-expanded'));
 console.log('v0.14 address/autocomplete and return-road tests OK; ratios', {repeat,different});
})().catch(e=>{console.error(e);process.exit(1)});
