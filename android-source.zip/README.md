# AlpRiders CH v0.8 — Segurança com arranque automático (TESTE)

## O que mudou

- À primeira abertura, pergunta se queres ativar monitorização **automática**. Só depois de consentimento expresso é que pede acesso a localização/notificações e inicia o serviço.
- Nas próximas aberturas da aplicação, o monitor de GPS reinicia automaticamente se mantiveste a preferência ativa. Não é iniciado automaticamente após reinício do Samsung, nem por um processo de fundo quando a aplicação está fechada.
- Continua a exigir **45 segundos de movimento GPS fiável** antes de poder detetar 20 minutos de imobilização. Mota estacionada no arranque não dispara o alarme.
- O botão **Testar alarme 60 s** mostra um diálogo nativo visível, toca e vibra durante o teste, mesmo sem o monitor GPS ativo. O botão «Estou bem» cancela a simulação. Sons dependem do volume, modo silêncio e permissões do dispositivo.
- O botão **Ativar monitor automático** ativa a preferência para as próximas aberturas. **Parar monitor** desativa a preferência e encerra o serviço.
- Para verificar proteção, a notificação Android do monitor deve permanecer visível; interrupções do sistema, falta de GPS ou limitações da bateria podem suspender a monitorização.

## Limites de segurança (importante)

**Versão de TESTE, NÃO é um dispositivo de deteção de acidentes certificado, nem serviço de emergência.** Nenhum WhatsApp, SMS ou chamada é enviado automaticamente. É possível não detetar acidentes, provocar falsos alarmes ou perder GPS. Não usar esta aplicação como único meio de pedir socorro. Emergências na Suíça: ligar 112 / 144 manualmente.

## Compilação

ZIP contém projeto Android com Gradle 8.11.1 e Java 17. O fluxo GitHub Actions existente compila com `gradle --no-daemon :app:assembleDebug`.

ID da app: `ch.alpriders.navigation.test08`, distinto de `test07` para não perder dados instalados da versão anterior. Os dados da v0.7 NÃO são importados automaticamente.
