# AlpRiders CH v0.20 — ajuste do planeador (TESTE)

Esta versão **não foi verificada num passeio real nem num Samsung**. Concentra-se num problema demonstrado no código da v0.18: o planeador podia gastar a quota do servidor público de Valhalla a tentar corrigir um único circuito, deixando poucas tentativas para outras opções.

Mudanças:
- Tenta primeiro 8 circuitos diferentes (máximo um pedido de Valhalla por circuito).
- Guarda 4 pedidos para uma segunda fase de cálculo troço a troço, com até 3 alternativas por ligação, somente se falhar a primeira fase.
- Mantém a verificação integral da geometria na Suíça e a exigência de pouca estrada repetida.
- Respeita intervalos de 1,3 s entre pedidos, respeitando o servidor público de demonstração.
- Mantém GPS, mapa, SOS, chat e vozes inalterados. Identificador Android novo para instalar sem remover a versão existente.

Limites: Não há acesso a trânsito e obras ao vivo; o serviço Valhalla usado é um servidor público de demonstração. Passar os testes locais não comprova que consiga fazer um passeio de duas horas junto a Genebra. O projeto necessita de testes de API reais e testes num dispositivo Android antes de ser utilizado como GPS de condução.
