# v0.17 — Recuperação de circuitos suíços perto de fronteiras

Ver [README-v17.md](README-v17.md) para as novas alterações e limites.

# AlpRiders CH v0.16 — Circuitos em Genebra e idiomas (TESTE)

**Estado:** código testado localmente; compilação Android no GitHub e teste no Samsung ainda pendentes.

## Correções desta versão

1. **Mais hipóteses para gerar o passeio de 2 horas em Genebra:** o raio de procura do planeador é ampliado e foram acrescentados vários pontos de passagem aproximados em Genebra/Vaud, incluindo Versoix, Coppet, Nyon e Gingins. O planeador experimenta mais ordens de passagem por estradas e, se falhar, mostra separadamente as recusas por fronteira, estrada repetida e falhas do serviço de rotas. A duração pedida é indicativa.
2. **Regresso por estradas diferentes:** a última etapa não pode repetir mais de cerca de **18%** da geometria amostrada das anteriores. É um teste geográfico aproximado; não garante 100% de troços exclusivos, nem que o OSRM conheça estradas encerradas. Também se aplica ao guardar um circuito.
3. **Verificação de fronteira incluída no ZIP:** `app/src/main/assets/swiss-border.geojson` está agora embutido no projeto fonte. Extraído do APK anterior, que já recebia o ficheiro no build do GitHub, e proveniente do conjunto público ZHB/switzerland-geojson. Não inventámos uma nova fronteira.
4. **Botão «Planear passeio» traduzido:** referência ao botão nativo é atualizada ao mudar entre português, francês, alemão, italiano, espanhol e inglês. A caixa de diálogo que surge ao clicar em «Navegar» sem rota também foi traduzida.
5. **Sem navegação fictícia:** continua impossível iniciar instruções se não existir rota rodoviária verificada com manobras. É um comportamento de segurança deliberado, não uma rota criada automaticamente a partir de uma linha reta.

## Limites

Não há garantia de que se encontre um circuito com a duração e a não-repetição pedidas: a rede rodoviária pode ter poucas alternativas, em especial junto às fronteiras. A API pública OSRM pode estar indisponível ou limitar pedidos. Não existe serviço de obras e trânsito em tempo real. A aplicação não é um GPS moto certificado, nem substitui navegação fiável na estrada. Faz todos os testes com a mota parada.

O identificador Android desta variante é `ch.alpriders.navigation.test16`, para não apagar a v0.15 ou dados locais de outras versões. As definições Supabase não são migradas automaticamente.

## Para gerar o APK

Substituir `android-source.zip` no repositório GitHub da AlpRiders CH e confirmar o commit. Verificar o resultado do GitHub Actions antes de instalar. **Não está confirmado que compile enquanto o workflow não terminar com sucesso.**

## Testes locais

`node tests/v16-regression.test.cjs`, `node tests/v14-address-route.test.cjs`, `node tests/v15-detour-contract.test.cjs`, `node tests/swiss-only.test.cjs`, `node tests/route-utils.test.cjs` e os ficheiros `tests/*.test.py`. Também foi verificada a sintaxe do JavaScript inline.

---

# AlpRiders CH v0.15 — Circuitos alternativos e desvios experimentais

**Estado:** versão de teste. Atualização do código; APK Android ainda por compilar e validar no Samsung.

## Correção da imagem enviada

Na v0.14, o planeador interrompia a geração de circuitos quando não encontrava dois pontos panorâmicos predefinidos num raio limitado. Na v0.15, continua a procurar circuitos por vias alternativas com pontos virtuais no interior da Suíça, mesmo sem pontos turísticos próximos. **Esses pontos são candidatos**, não rotas garantidas: só são aceites se o OSRM calcular estradas reais, a fronteira inteira for verificada e a estrada de regresso não tiver mais de 12% de sobreposição geométrica aproximada. A duração desejada não é garantida. Se não for possível, informa o utilizador. Se for necessário deixar o estilo escolhido, o aviso diz que gerou uma alternativa genérica.

## Durante a navegação

- **Recálculo automático experimental** quando o GPS, com precisão <= 35 m, se mantém a mais de 120 m da rota por 18 segundos. Limite de uma tentativa automática a cada 2 minutos, sem descarregar dados continuamente.
- **Botão «⛔ Desvio»** no navegador. Se a mota estiver parada, o utilizador pode indicar um possível bloqueio da estrada, que leva a procurar outra rota sem esperar pelo desvio GPS.
- Os candidatos são calculados através de estradas reais do OSRM, incluindo possíveis pontos intermédios a diferentes distâncias laterais. Não são aceites se regressarem a uma **zona aproximada de 260 m de raio à volta de três pontos da estrada anterior**, situados a ~400, ~650 e ~900 m da última posição confirmada ao longo da rota. Também precisam passar as mesmas verificações da Suíça.
- Os pontos de passagem futuros que for possível localizar no circuito são preservados para que o trajeto não se reduza automaticamente a um caminho direto para casa. O circuito original não pode continuar a ser apresentado como se fosse idêntico após o desvio.
- Em falha, a rota antiga permanece e a interface avisa para parar em segurança. O novo cálculo só é aplicado à navegação se houver um traçado aceite.

## Limitações importantes

Esta versão **não deteta automaticamente obras, encerramentos ou acidentes**, não tem trânsito em tempo real, não valida abertura legal de passagens e não assegura que não se utilize nenhum troço da estrada anteriormente percorrida. Evita apenas o corredor geográfico suspeito da estrada à frente, sem garantia sobre outros bloqueios. A API pública OSRM usada na aplicação calcula rotas para automóveis e não recebe um parâmetro para excluir um troço rodoviário arbitrário identificado pelo utilizador. O serviço pode falhar, recusar pedidos ou gerar alternativas insuficientes. Uma integração futura com as ocorrências oficiais da rede rodoviária suíça implicaria backend, tratamento de dados DATEX II e chave de acesso ao serviço (Open Transport Data Switzerland).

**Não utilizar como único GPS durante a condução. Não manipular a aplicação em andamento.**

## Instalação e dados

Pacote Android de testes com identificador `ch.alpriders.navigation.test15`, distinto dos anteriores. Não migra automaticamente contas Supabase, chats ou rotas guardadas em outras instalações.

O GitHub Actions deverá receber o novo `android-source.zip` para compilar um APK; não considerar compilação concluída até ser verificada. Execute os testes localizados em `tests/` para confirmar sintaxe, condições de fronteira, rejeição de repetição de estrada e funções de desvio.

---

# AlpRiders CH v0.14 — Circuitos com menos estrada repetida, pesquisa de moradas e textos multilíngues (TESTE)

**Estado:** código atualizado e testes locais concluídos. Não compilado nem testado num Samsung nesta fase; **não utilizar como único GPS de condução**.

## Alterações específicas

1. **Ida e regresso por estradas diferentes**: rejeita novos circuitos se a última etapa repetir mais de 12% da geometria amostrada do percurso de ida, ou se os dados não forem suficientes para o verificar. Reforça as tentativas com dois ou três pontos intermédios em ordens diferentes e escolhe as rotas com menos repetição. Esta é uma *verificação geométrica aproximada*, não garantia de ausência de um único troço comum; ao sair do mesmo parqueamento/rua o primeiro e o último troço podem coincidir. O planeador pode não encontrar circuito e deverá avisar.
2. **Endereços exatos suíços**: pesquisa enquanto digita, a partir de 3 caracteres, com debounce e cancelamento de pedidos antigos. Utiliza `https://api3.geo.admin.ch/rest/services/ech/SearchServer` com `type=locations&origins=address`. Lista endereços oficiais e exige que o utilizador selecione um antes de calcular um percurso de ida. Não inventa coordenadas nem aceita automaticamente resultados aproximados. Necessita de Internet e acesso à API oficial; se o serviço estiver indisponível a app deverá mostrar erro de pesquisa.
3. **Tradução textual mais completa**: revisão de mensagens, formulários, segurança e pesquisa em PT/FR/IT/ES/DE/EN. Textos criados dinamicamente são tratados através de traduções específicas e observação de atualizações no interface. Continua necessário teste manual por um falante de cada idioma; a tradução automática de nomes de ruas é intencionalmente evitada.
4. **Dados do utilizador**: esta compilação utiliza o identificador isolado `ch.alpriders.navigation.test14`, para preservar dados das versões de teste anteriores. A configuração Supabase e os dados locais não são importados automaticamente.

## Limitações críticas

- As rotas são calculadas num serviço público de **automóveis** (OSRM demo), não num motor comercial ou específico para motas. Não verifica encerramentos de estradas, tipo de via, trânsito ou condições meteorológicas. Não garante disponibilidade permanente nem consegue fornecer todos os circuitos pedidos.
- A verificação «só Suíça» depende de dados geográficos aproximados; não assegura acesso legal e pode rejeitar estradas suíças perto da fronteira.
- A interface de navegação nativa tem limitações anteriores: não recalcula automaticamente uma rota, não suporta offline e não oferece navegação certificada.
- O SOS de acidente é simulado e não envia automaticamente chamadas ou mensagens.

## Testes locais

- `node tests/v14-address-route.test.cjs`: normalização segura dos resultados oficiais e ausência de regresso pela mesma estrada, com percursos sintéticos.
- `node --check` em `swiss-address-search.js`, `extra-locales.js`, `native-bridge.js` e scripts HTML inline.
- Revisão estática de IDs do HTML e das configurações Android.
- Pendente compilação Android pelo GitHub Actions e teste físico no Samsung.

## Distribuição

Carregar o ficheiro `android-source.zip` na raiz do repositório GitHub, substituindo a versão anterior, para acionar o workflow de compilação existente. **Não desinstalar as apps existentes antes de guardar dados importantes.**

---

## Histórico anterior

# AlpRiders CH v0.13 — Mota no mapa, zoom automático e voz em português (TESTE)

**Estado:** código-fonte atualizado e testes locais; o APK Android ainda precisa de compilação e teste no Samsung. Não utilizar como único dispositivo de navegação em estrada.

## Alterações em relação à v0.11

- Os marcadores de **partida** e **posição GPS** usam o desenho original de uma **mota** sobre fundos de cor diferente (laranja e turquesa) para não os confundir. O marcador da partida é ocultado durante navegação para dar destaque à posição real.
- Ao carregar em **Navegar** com uma rota rodoviária válida dentro da Suíça e GPS recente e preciso, o mapa **aproxima de imediato a mota**; enquanto a aplicação estiver aberta, acompanha a posição e ajusta o zoom consoante a velocidade GPS. Sem localização precisa, não inicia orientações como se a posição fosse conhecida.
- **Voz portuguesa** (motor Android TextToSpeech): anuncia o início da navegação e próximas manobras segundo os passos fornecidos pelo serviço de estradas. O botão **Voz** permite desligar/ligar e ouvir uma frase de teste. Informa quando a voz PT não está instalada. A saída de áudio depende do Samsung e do respetivo motor TTS.
- Aviso de saída do percurso por voz apenas uma vez por desvio; não recalcula a rota. Mantidos botões SOS, perfis, grupos, passeios de 1 a 24 h e verificações de fronteira anteriores.
- APK de teste isolado: `ch.alpriders.navigation.test12` para não sobrepor os dados de versões anteriores.

## Limitações

Não é o Waze, nem dispõe de recálculo automático, limites para motos, trânsito em tempo real, mapas offline ou orientação garantida com o ecrã bloqueado. Para percursos longos, confirmar sempre itinerário, fronteiras e condições rodoviárias. A declaração Android para descobrir motores TTS foi adicionada conforme a documentação oficial. O TTS só funciona com as vozes do Android instaladas; testá-lo antes de conduzir e com a mota parada. A v0.13 mantém o SOS automático externo desativado.

---

# AlpRiders CH v0.11 — Navegação integrada experimental e passeios de 1–24 horas

**ESTADO:** código-fonte de teste, compilação Android e teste no Samsung ainda pendentes. Não usar como único GPS durante a condução. Ainda não equivale a Waze, Calimoto ou a um navegador rodoviário certificado.

## Pedidos implementados

- O planeador apresenta durações pretendidas de **1 a 24 horas** (em passos de uma hora), em seis idiomas. Para dias muito longos experimenta vários pontos panorâmicos distribuídos pela Suíça; aceita apenas um traçado calculado pelo serviço de estradas e validado por fronteira cartográfica. É possível que não exista um circuito para 24 h e a duração real seja diferente.
- O mapa **MapLibre nativo** passa a ter botão «Navegar»; o planeador oferece «Navegar na AlpRiders». Não abre o Waze automaticamente.
- Em modo de navegação, o mapa ocupa mais área: orientação de acordo com a posição GPS e a direção de deslocação, faixa superior grande com próxima manobra e distância, estimativa de distância restante, indicação por voz em português (TextToSpeech), e botões para parar, desligar voz e abrir SOS.
- Desenho da rota continua com cor de contraste; segue a geometria real calculada por OSRM (automóveis) e as manobras incluídas na resposta da mesma rota. Apenas fica disponível se a rota estiver assinalada como verificada dentro da Suíça e houver instruções rodoviárias.
- Recusa iniciar navegação se estiveres a mais de 400 m do percurso; mostra «fora do percurso» caso te afastes mais de 120 m. Não inventa nem recalcula traçados automaticamente.
- A versão mantém grupos, chat Supabase e segurança local anteriores, mas com identificador APK isolado `ch.alpriders.navigation.test11`.

## Limites / problemas conhecidos

- **Não é Waze incorporado.** O Waze não disponibiliza o seu mapa/navegação completa para incorporar numa aplicação de terceiros. Esta é uma interface original que usa MapLibre e serviço público de rotas automóveis (OSRM).
- **Não há recálculo automático, mapas offline, conhecimento de acessos proibidos a motos, congestionamento em tempo real, encerramentos de passes, garantia de velocidade ou instruções equivalentes às de um navegador comercial.** Para trânsito real e condução, continua a ser necessário um GPS fiável.
- **GPS com ecrã bloqueado não está garantido neste modo.** Mapa e instruções só quando aplicação está aberta e com permissões concedidas.
- **Suíça apenas** é uma verificação cartográfica aproximada do traçado, não comprovação rodoviária de que nenhuma fronteira será cruzada.
- Para 24 h, o serviço público OSRM pode limitar chamadas / tempo de cálculo ou não encontrar circuitos; o programa deve declarar a falha, não fingir sucesso.
- As instruções de navegação nativas de teste estão em português nesta fase. O restante planeador mantém seis idiomas.
- SOS automático de acidentes e envio de emergências continuam inativos (simulação local).
- MapLibre, OSRM e a aplicação Waze têm tecnologias e licenças diferentes; não copiar imagens ou marca de Waze.

## Testes realizados

- `RouteGuideContract.kt`: progresso num segmento, desvio e próxima manobra.
- `node --check` nos dois scripts inline HTML e na ponte JavaScript Android.
- Opções de 1 a 24 h contadas e verificadas por script.
- **Ainda falta compilar pelo GitHub Actions, instalar e testar no Samsung:** GPS, TTS, seleção de manobras, fronteiras, regresso e ecrã bloqueado.

## Compilar no repositório

Substituir `android-source.zip` no repositório GitHub para disparar a compilação existente. Este ZIP contém a raiz Gradle Android; o workflow atual extrai o ZIP. Confirmar o estado verde da compilação antes de distribuir o APK.


## v0.13 – Endereço e voz multilíngue (teste)

- Seis idiomas de instruções de navegação sincronizados com o idioma escolhido na aplicação. A síntese de voz precisa de um pacote de voz instalado para o idioma; se não existir, a app não afirma que está a falar o idioma correto.
- Sinal de mota com fundo transparente, sem bolinha.
- Cinco estilos de passeio adicionais com seleção de pontos de interesse identificados. Se não houver pontos suficientes, o sistema informa em vez de gerar um circuito fora do estilo.
- Rota de ida por endereço: exige correspondência de rua e número de porta com geocodificação na Suíça, seguindo depois o cálculo de estrada já existente e a verificação de fronteira. O geocodificador público pode falhar; não inventa coordenadas aproximadas.
- **Carpuride/Android Auto não está implementado nesta versão.** Cada Carpuride tem capacidades próprias. Uma app Android normal não é publicada automaticamente para Android Auto; requer `androidx.car.app`, `CarAppService`, UI adaptada, testes e aprovação, além de um motor de navegação mais completo. Antes de desenvolver, identificar o modelo exato e protocolo do equipamento.
- Continua sem recalcular rotas automaticamente, sem informação de trânsito e não substitui navegação homologada.
