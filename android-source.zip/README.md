# AlpRiders CH v0.18 — Valhalla experimental (protótipo)

**Não é uma APK de navegação fiável.** Este protótipo substitui as consultas OSRM por Valhalla, com perfil `motorcycle` em modo beta e dados OpenStreetMap, usando temporariamente o **servidor público de demonstração** de FOSSGIS. A interface existente (mapa, voz, SOS) foi mantida. Não estão incluídos dados de trânsito, obras em tempo real, nem bloqueio integral da fronteira pelo motor. A fronteira suíça continua a ser validada do lado da aplicação antes de aceitar uma rota.

As manobras e a geometria vêm de uma resposta Valhalla no formato compatível OSRM. O planeador limita o número de pedidos de teste (até 12 por criação de circuito, 8 candidaturas), coloca pausas de 1,3 segundos e faz, no máximo, uma segunda tentativa por percurso para tentar evitar pontos da estrada fora da Suíça. **O servidor de demonstração pode ter limites de utilização e não é apropriado para uma aplicação pública em produção.** Para isso será necessário alojamento próprio de Valhalla ou um fornecedor com condições comerciais. A documentação do servidor solicita contacto com os operadores e identificação do cliente: `X-Client-Id: alpriders-ch-test`.

## Testes

Execute `node tests/v18-valhalla-adapter.test.cjs` para verificar o protocolo e a política de fronteira com respostas simuladas. **Sem ligação direta à API pública neste ambiente, ainda não foram verificados os resultados reais na região de Genebra**. A versão não deve ser considerada pronta para condução nem garante criação de passeios de 2 horas.

## Próximas tarefas necessárias

Testar pedido real via Samsung, confirmar CORS e versão do Valhalla no demo, verificar se o servidor devolve o formato OSRM esperado, ajustar repetição de troços usando identificadores de estradas, e preparar servidor Valhalla com **grafo suíço** para que o serviço evite estradas estrangeiras sem depender de tentativas sucessivas. Também é necessário obter informação oficial de encerramentos rodoviários antes de prometer desvios fiáveis.
