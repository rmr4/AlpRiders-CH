# AlpRiders CH v0.11 — Navegação integrada experimental e passeios de 1–24 horas

**ESTADO:** código-fonte de teste, compilação Android e teste no Samsung ainda pendentes. Não usar como único GPS durante a condução. Ainda não equivale a Waze, Calimoto ou a um navegador rodoviário certificado.

## Pedidos implementados

- O planeador apresenta durações pretendidas de **1 a 24 horas** (em passos de uma hora), em seis idiomas. Para dias muito longos experimenta vários pontos panorâmicos distribuídos pela Suíça; aceita apenas um traçado calculado pelo serviço de estradas e validado por fronteira cartográfica. É possível que não exista um circuito para 24 h e a duração real seja diferente.
- O mapa **MapLibre nativo** passa a ter botão «Navegar»; o planeador oferece «Navegar na AlpRiders». Não abre o Waze automaticamente.
- Em modo de navegação, o mapa ocupa mais área: orientação de acordo com a posição GPS e a direção de deslocação, faixa superior grande com próxima manobra e distância, estimativa de distância restante, indicação por voz em português (TextToSpeech), e botões para parar, desligar voz e abrir SOS.
- Desenho da rota continua com cor de contraste; segue a geometria real calculada por OSRM (automóveis) e as manobras incluídas na resposta da mesma rota. Apenas fica disponível se a rota estiver assinalada como verificada dentro da Suíça e houver instruções rodoviárias.
- Recusa iniciar navegação se estiveres a mais de 400 m do percurso; mostra «fora do percurso» caso te afastes mais de 120 m. Não inventa nem recalcula traçados automaticamente.
- A versão mantém grupos, chat Supabase e segurança local anteriores, mas com identificador APK isolado `ch.alpriders.navigation.test11`.

## Limites / problemas conhecidos

- **Não é Waze incorporado.** O Waze não disponibiliza o seu mapa/navegação completa para incorporar numa aplicação de terceiros. Esta é uma interface original que usa MapLibre e serviço público de rotas automóveis (OSRM).
- **Não há recálculo automático, mapas offline, conhecimento de acessos proibidos a motos, congestionamento em tempo real, encerramentos de passes, garantia de velocidade ou instruções equivalentes às de um navegador comercial.** Para trânsito real e condução, continua a ser necessário um GPS fiável.
- **GPS com ecrã bloqueado não está garantido neste modo.** Mapa e instruções só quando aplicação está aberta e com permissões concedidas.
- **Suíça apenas** é uma verificação cartográfica aproximada do traçado, não comprovação rodoviária de que nenhuma fronteira será cruzada.
- Para 24 h, o serviço público OSRM pode limitar chamadas / tempo de cálculo ou não encontrar circuitos; o programa deve declarar a falha, não fingir sucesso.
- As instruções de navegação nativas de teste estão em português nesta fase. O restante planeador mantém seis idiomas.
- SOS automático de acidentes e envio de emergências continuam inativos (simulação local).
- MapLibre, OSRM e a aplicação Waze têm tecnologias e licenças diferentes; não copiar imagens ou marca de Waze.

## Testes realizados

- `RouteGuideContract.kt`: progresso num segmento, desvio e próxima manobra.
- `node --check` nos dois scripts inline HTML e na ponte JavaScript Android.
- Opções de 1 a 24 h contadas e verificadas por script.
- **Ainda falta compilar pelo GitHub Actions, instalar e testar no Samsung:** GPS, TTS, seleção de manobras, fronteiras, regresso e ecrã bloqueado.

## Compilar no repositório

Substituir `android-source.zip` no repositório GitHub para disparar a compilação existente. Este ZIP contém a raiz Gradle Android; o workflow atual extrai o ZIP. Confirmar o estado verde da compilação antes de distribuir o APK.
