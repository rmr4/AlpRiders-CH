# AlpRiders CH v0.13 — Mota no mapa, zoom automático e voz em português (TESTE)

**Estado:** código-fonte atualizado e testes locais; o APK Android ainda precisa de compilação e teste no Samsung. Não utilizar como único dispositivo de navegação em estrada.

## Alterações em relação à v0.11

- Os marcadores de **partida** e **posição GPS** usam o desenho original de uma **mota** sobre fundos de cor diferente (laranja e turquesa) para não os confundir. O marcador da partida é ocultado durante navegação para dar destaque à posição real.
- Ao carregar em **Navegar** com uma rota rodoviária válida dentro da Suíça e GPS recente e preciso, o mapa **aproxima de imediato a mota**; enquanto a aplicação estiver aberta, acompanha a posição e ajusta o zoom consoante a velocidade GPS. Sem localização precisa, não inicia orientações como se a posição fosse conhecida.
- **Voz portuguesa** (motor Android TextToSpeech): anuncia o início da navegação e próximas manobras segundo os passos fornecidos pelo serviço de estradas. O botão **Voz** permite desligar/ligar e ouvir uma frase de teste. Informa quando a voz PT não está instalada. A saída de áudio depende do Samsung e do respetivo motor TTS.
- Aviso de saída do percurso por voz apenas uma vez por desvio; não recalcula a rota. Mantidos botões SOS, perfis, grupos, passeios de 1 a 24 h e verificações de fronteira anteriores.
- APK de teste isolado: `ch.alpriders.navigation.test12` para não sobrepor os dados de versões anteriores.

## Limitações

Não é o Waze, nem dispõe de recálculo automático, limites para motos, trânsito em tempo real, mapas offline ou orientação garantida com o ecrã bloqueado. Para percursos longos, confirmar sempre itinerário, fronteiras e condições rodoviárias. A declaração Android para descobrir motores TTS foi adicionada conforme a documentação oficial. O TTS só funciona com as vozes do Android instaladas; testá-lo antes de conduzir e com a mota parada. A v0.13 mantém o SOS automático externo desativado.

---

# AlpRiders CH v0.11 — Navegação integrada experimental e passeios de 1–24 horas

**ESTADO:** código-fonte de teste, compilação Android e teste no Samsung ainda pendentes. Não usar como único GPS durante a condução. Ainda não equivale a Waze, Calimoto ou a um navegador rodoviário certificado.

## Pedidos implementados

- O planeador apresenta durações pretendidas de **1 a 24 horas** (em passos de uma hora), em seis idiomas. Para dias muito longos experimenta vários pontos panorâmicos distribuídos pela Suíça; aceita apenas um traçado calculado pelo serviço de estradas e validado por fronteira cartográfica. É possível que não exista um circuito para 24 h e a duração real seja diferente.
- O mapa **MapLibre nativo** passa a ter botão «Navegar»; o planeador oferece «Navegar na AlpRiders». Não abre o Waze automaticamente.
- Em modo de navegação, o mapa ocupa mais área: orientação de acordo com a posição GPS e a direção de deslocação, faixa superior grande com próxima manobra e distância, estimativa de distância restante, indicação por voz em português (TextToSpeech), e botões para parar, desligar voz e abrir SOS.
- Desenho da rota continua com cor de contraste; segue a geometria real calculada por OSRM (automóveis) e as manobras incluídas na resposta da mesma rota. Apenas fica disponível se a rota estiver assinalada como verificada dentro da Suíça e houver instruções rodoviárias.
- Recusa iniciar navegação se estiveres a mais de 400 m do percurso; mostra «fora do percurso» caso te afastes mais de 120 m. Não inventa nem recalcula traçados automaticamente.
- A versão mantém grupos, chat Supabase e segurança local anteriores, mas com identificador APK isolado `ch.alpriders.navigation.test11`.

## Limites / problemas conhecidos

- **Não é Waze incorporado.** O Waze não disponibiliza o seu mapa/navegação completa para incorporar numa aplicação de terceiros. Esta é uma interface original que usa MapLibre e serviço público de rotas automóveis (OSRM).
- **Não há recálculo automático, mapas offline, conhecimento de acessos proibidos a motos, congestionamento em tempo real, encerramentos de passes, garantia de velocidade ou instruções equivalentes às de um navegador comercial.** Para trânsito real e condução, continua a ser necessário um GPS fiável.
- **GPS com ecrã bloqueado não está garantido neste modo.** Mapa e instruções só quando aplicação está aberta e com permissões concedidas.
- **Suíça apenas** é uma verificação cartográfica aproximada do traçado, não comprovação rodoviária de que nenhuma fronteira será cruzada.
- Para 24 h, o serviço público OSRM pode limitar chamadas / tempo de cálculo ou não encontrar circuitos; o programa deve declarar a falha, não fingir sucesso.
- As instruções de navegação nativas de teste estão em português nesta fase. O restante planeador mantém seis idiomas.
- SOS automático de acidentes e envio de emergências continuam inativos (simulação local).
- MapLibre, OSRM e a aplicação Waze têm tecnologias e licenças diferentes; não copiar imagens ou marca de Waze.

## Testes realizados

- `RouteGuideContract.kt`: progresso num segmento, desvio e próxima manobra.
- `node --check` nos dois scripts inline HTML e na ponte JavaScript Android.
- Opções de 1 a 24 h contadas e verificadas por script.
- **Ainda falta compilar pelo GitHub Actions, instalar e testar no Samsung:** GPS, TTS, seleção de manobras, fronteiras, regresso e ecrã bloqueado.

## Compilar no repositório

Substituir `android-source.zip` no repositório GitHub para disparar a compilação existente. Este ZIP contém a raiz Gradle Android; o workflow atual extrai o ZIP. Confirmar o estado verde da compilação antes de distribuir o APK.


## v0.13 – Endereço e voz multilíngue (teste)

- Seis idiomas de instruções de navegação sincronizados com o idioma escolhido na aplicação. A síntese de voz precisa de um pacote de voz instalado para o idioma; se não existir, a app não afirma que está a falar o idioma correto.
- Sinal de mota com fundo transparente, sem bolinha.
- Cinco estilos de passeio adicionais com seleção de pontos de interesse identificados. Se não houver pontos suficientes, o sistema informa em vez de gerar um circuito fora do estilo.
- Rota de ida por endereço: exige correspondência de rua e número de porta com geocodificação na Suíça, seguindo depois o cálculo de estrada já existente e a verificação de fronteira. O geocodificador público pode falhar; não inventa coordenadas aproximadas.
- **Carpuride/Android Auto não está implementado nesta versão.** Cada Carpuride tem capacidades próprias. Uma app Android normal não é publicada automaticamente para Android Auto; requer `androidx.car.app`, `CarAppService`, UI adaptada, testes e aprovação, além de um motor de navegação mais completo. Antes de desenvolver, identificar o modelo exato e protocolo do equipamento.
- Continua sem recalcular rotas automaticamente, sem informação de trânsito e não substitui navegação homologada.
