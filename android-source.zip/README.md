# AlpRiders CH Android — protótipo integrado v0.4 (GPS Android integrado)

## O que está incluído

- **Mapa vetorial nativo MapLibre** em toda a área central, sem quadrados vazios de Leaflet.
- **GPS Android**, marcador, seguimento com rotação no rumo quando o sensor disponibiliza `bearing`, velocidade GPS.
- **5 separadores**, com conteúdo preservado do protótipo HTML original: Mapa, Rotas, Grupos, Perfil e SOS.
- **6 idiomas** existentes no projeto original (PT, FR, IT, ES, DE, EN).
- **Rotas**: apontar partida/destino no mapa nativo, pedir rota rodoviária via OSRM, visualizar o traçado no MapLibre, guardar rotas na memória local do WebView, exportar GPX pelo seletor de documentos Android.
- **Planeador surpresa** e rotas panorâmicas migrados do HTML original (roteamento público OSRM para automóveis; duração apenas aproximada).
- **Grupos de demonstração locais**; para grupos reais entre telemóveis, o Supabase precisa de ser configurado e de políticas de segurança adequadas.
- **Perfil e SOS** com contactos e links de marcação telefónica/manuais. Não realiza chamadas/SMS automáticos.

## Limitações importantes

Este é um **protótipo híbrido** (mapa Android nativo e ecrãs de funções web embebidas no APK), **não** um GPS ao nível do Calimoto/Waze.

**Não inclui**: orientações por voz fiáveis, recálculo automático ao sair de rota, escolha de vias otimizada especificamente para motas, mapas offline, navegação em segundo plano com ecrã bloqueado, deteção de acidente, integração entre rotas e grupos através de servidor, ou testes de segurança em estrada.

O serviço de rotas OSRM usado neste protótipo é para *automóveis*, pode gerar percursos inadequados a motas e não conhece o estado atual das passagens alpinas.

Precisa de Internet para mapa vetorial e traçado. Uma interrupção de rede pode deixar o mapa sem dados.

Os dados guardados na versão web anterior **não são migrados automaticamente** para o armazenamento privado desta aplicação Android; guarda/exporta previamente os GPX importantes.

## Compilação

Este ficheiro ZIP é o projeto Gradle (não um APK compilado):

`gradle --no-daemon :app:assembleDebug`

Android SDK 35 e Java 17. O primeiro build deve ser feito via GitHub Actions e verificado antes de instalar o APK.

## Segurança

Nunca utilizar o protótipo como única fonte de navegação durante a condução; respeitar sinais, encerramentos e condições reais. Interface e GPS ainda requerem testes reais.

## Correção v0.3: ecrã e botões Samsung

- Ajusta a raiz da aplicação aos **insets reais** das barras do Android (topo, laterais e rodapé).
- Mantém os cinco separadores sempre acima dos botões de sistema do Samsung, tanto em navegação por gestos como por três botões.
- Reduz cabeçalho e espaços verticais, mantendo alturas mínimas de toque de 48 dp nos botões.
- Ajusta o mapa automaticamente à altura restante, sem deslocar os separadores para baixo da barra de navegação.
- Não altera o HTML dos percursos, grupos, perfil ou SOS.
- Compilação e instalação precisam de validação real. Se o APK tiver uma assinatura de depuração diferente, pode ser necessário desinstalar o APK antigo antes de instalar o novo; desinstalar apaga os dados locais dessa aplicação.

## Correções v0.4
- Roteamento, planeador e SOS solicitam a localização diretamente ao Android após ação do utilizador, sem depender da API GPS do Chrome na WebView.
- A aplicação pede a permissão de localização quando necessária; localizações para SOS não são enviadas automaticamente.
- Mensagens de erro de GPS passaram a mencionar as permissões da aplicação Android.
- Remove a opção sem sentido «Instalar no ecrã inicial» dentro da aplicação instalada.
- Os botões de copiar e partilhar a localização SOS usam o Android nativo; não enviam mensagens automaticamente.
- Mantém as margens de segurança do Samsung e desloca o conteúdo para o início ao mudar de separador.
- Os cinco separadores e os seis idiomas são mantidos.

O GPS e a navegação ainda exigem testes no dispositivo; não usar como navegador principal.

## Verificação obrigatória no Samsung (v0.4)

1. Atualizar sem desinstalar, se o Android permitir. No caso de conflito de assinatura, **não desinstalar** antes de preservar os dados locais importantes (a desinstalação apaga perfis, grupos e rotas desta APK).
2. Autorizar a localização à AlpRiders CH quando for pedido.
3. Em **Rotas**, escolher «Posição atual pelo GPS» e tentar «Criar passeio surpresa» parado. Se falhar, registar a mensagem; pode ser a rede ou o serviço OSRM.
4. Em **SOS**, carregar «Atualizar GPS» e confirmar que aparecem coordenadas e precisão. O botão de partilha deve abrir o menu Android; nunca envia SMS sozinho.
5. Verificar os separadores Mapa, Rotas, Grupos, Perfil, SOS acima da barra de navegação do Samsung.
6. Confirmar que não aparece «Instalar no ecrã inicial» dentro do APK.

O teste de sintaxe JavaScript e de integridade do ZIP foi realizado localmente; **a compilação Android e testes num dispositivo ainda não foram executados** para esta revisão.
