# AlpRiders CH v0.10 — Waze a partir da aplicação Android (teste)

- Mapa nativo mantém-se dentro da AlpRiders CH. Em **Mapa**, botão **Waze** abre a escolha do próximo ponto; no separador **Rotas** também há um botão Waze.
- Só disponibiliza passagem para Waze após uma rota calculada e validada como suíça pelo protótipo. Permite escolher um ponto intermédio ou o regresso à partida, um de cada vez.
- Usa o Deep Link oficial `https://waze.com/ul?ll=latitude,longitude&navigate=yes&vehicle_type=motorcycle&utm_source=alpriders_ch`. Abre a aplicação Waze instalada; se não existir, oferece instalação.
- **Limitação importante**: o Waze **não recebe nem segue a geometria total** do passeio, não respeita necessariamente todas as paragens, não garante estradas de curvas/montanhas ou evitar fronteiras. Pode recalcular a rota e atravessar França mesmo que a linha AlpRiders fique na Suíça. Verificar a rota em paragem antes de conduzir. Não mudar etapas em andamento.
- Não integra mapas nem navegação Waze dentro da AlpRiders; o Waze funciona como uma aplicação externa.
- Mantém os separadores e a preparação de chat geral/privado da v0.9. O backend é independente e continua a exigir URL, chave pública e autenticação. Dados de aplicações anteriores ficam separados neste APK TESTE com applicationId distinto.
- Monitor de segurança continua EXPERIMENTAL; não envia chamadas de urgência nem mensagens automáticas.
- Executar `tests/WazeNavigationContract.kt` para validar links e etapas.

Documentação oficial: https://developers.google.com/waze/deeplinks

# AlpRiders CH v0.9 — Comunidade online (preparação) e planeador CH

**O servidor NÃO está provisionado neste pacote.** Não confundir UI instalada com chat operacional.

## Alterações
- Ecrã **Chat geral**: visível a todos os utilizadores autenticados quando o Supabase estiver configurado; sem servidor fica claramente desativado.
- Grupos privados continuam separados e podem funcionar online após configuração Supabase.
- SQL de criação das tabelas e políticas RLS: `backend/supabase-community.sql` (incluído no ZIP, não é executado automaticamente).
- Circuitos Suíça: mais candidatos interiores (até 8 tentativas), mensagens específicas para falhas do serviço rodoviário, fronteiras e excesso de repetição. **Pode não ser possível** gerar circuito; sem rota válida o sistema não deve inventar estradas.
- O mapa Android MapLibre continua nativo. As regras de fronteira suíça e de segurança são preservadas.
- O chat público exige contas com confirmação por e-mail, anti-spam básico de 5 segundos, e **continua a precisar de moderação, denúncia e bloqueio** antes de ser aberto ao público geral.

## Configuração em falta
1. Conectar uma conta Supabase autorizada ao ChatGPT ou criar projeto no painel Supabase.
2. Executar o SQL de `backend/supabase-community.sql`.
3. Ativar autenticação por e-mail no Supabase.
4. Configurar no cliente a Project URL e chave `publishable` (nunca service_role).
5. Testar com duas contas em dois telemóveis: chat público, privacidade dos grupos, membros convidados, RLS, reconexão e bloqueios.

**Não usar esta versão para navegar de mota ou como único SOS.**
