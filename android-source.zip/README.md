# AlpRiders CH Android v0.7 — Monitor de segurança em TESTE

**Não é um serviço de assistência ativo nem um detetor de acidentes certificado.**

Esta atualização continua o projeto anterior com mapa nativo, Rotas (percursos circulares exclusivamente na Suíça), Grupos, Perfil e SOS manual por WhatsApp. Acrescenta no separador **SOS** um monitor *local* com botões de iniciar, parar, simular 60 segundos e confirmar «Estou bem».

## Como funciona o protótipo

- O utilizador inicia expressamente um serviço Android em primeiro plano. A aplicação solicita permissão para localização precisa e notificações, e mostra uma notificação persistente durante a monitorização. Sem essas permissões, o monitor não arranca.
- Para reduzir falsos positivos, o monitor só arma depois de pelo menos **45 segundos de movimento GPS** (velocidade >=2,2 m/s com precisão <=40 m). Um telemóvel parado desde o arranque não gera um alerta.
- Após armar, pode emitir um alarme **local** depois de 20 minutos de imobilização inferida pelo GPS (sem progresso >=75 m), quando houver medições novas e aceitáveis, ou quando o acelerómetro registar um impacto brusco suspeito seguido de imobilização. Estes limiares são heurísticos não validados, não evidência de acidente.
- O alarme local vibra/toca e apresenta **60 segundos** para cancelar em «Estou bem». Também abre SOS manual. Após 60 segundos sem resposta, mostra que um possível incidente não teve resposta e que **NENHUMA MENSAGEM FOI ENVIADA**.
- O modo de simulação deve ser usado sem conduzir. O serviço não arranca sozinho após reinício do Android e pode ser interrompido por restrições do sistema, bateria e perda de GPS.
- **Nenhuma mensagem WhatsApp, SMS nem telefonema é enviado automaticamente.** Não existe servidor de envio nem consentimento/validação do canal de alertas nesta versão. Contactos SOS existentes continuam disponíveis apenas para chamadas/WhatsApp manuais.
- Números de emergência 112 e 144 são abertos manualmente no marcador; **nunca são marcados pela aplicação automaticamente**.

## Por que ainda não envia automaticamente a três contactos?

A primeira fase verifica a deteção e o alarme no Samsung, sem causar falsas chamadas ou mensagens. Para envio real será necessário configurar com o utilizador o **canal de comunicação (SMS ou serviço online)**, guardar explicitamente os números aceites, ativar opt-in individual, testar entregas e recuperação de falhas, e informar que o serviço nunca é garantido. O WhatsApp normal não oferece envio silencioso em segundo plano por uma APK comum.

## Build

O ficheiro `android-source.zip` contém o projeto Gradle. Compilar com Android SDK 35, Java 17 e Gradle 8.11.1:

`gradle --no-daemon :app:assembleDebug`

O identificador Android deste teste é `ch.alpriders.navigation.test07`, separado das instalações anteriores (`test06`, `test05`). **Os dados guardados não são transferidos automaticamente** entre instalações de teste diferentes. O APK não foi compilado nem testado num Samsung nesta sessão. A sintaxe JavaScript, o XML, as simulações de segurança em Kotlin e a integridade do ZIP foram verificadas localmente.

## Teste recomendado (mota parada)

1. Em SOS, conceder localização precisa/notificações e iniciar o monitor. A notificação Android deve ficar visível.
2. Escolher «Testar alarme 60 s» e confirmar vibração/som e notificação; carregar «Estou bem» e verificar cancelamento.
3. Confirmar que a aplicação **não** envia WhatsApp/SMS/chamadas durante o teste.
4. Terminar o monitor. Não interpretar um teste bem-sucedido como sistema de emergência pronto para utilização em estrada.

## Licenças e restrições

Dependências MapLibre / WebView e dados geográficos de terceiros conservados da v0.6. O mapa/rotas necessitam de acesso à Internet, e a verificação de fronteira é aproximada. Código experimental, sem garantia de navegação ou deteção de quedas em estrada.
