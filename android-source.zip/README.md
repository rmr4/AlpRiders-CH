# AlpRiders CH v0.21 — Passagem de fronteiras (TESTE)

Base: **v0.20**, mantendo mapa nativo, voz, GPS, contactos e grupos.

## Funcionalidade

- A configuração de rotas é **Apenas Suíça** por defeito e usa o mesmo contorno detalhado da v0.20.
- Em **Rotas → Surpreende-me → Passagem de fronteiras**, é possível escolher **Permitir países vizinhos** e assinalar França, Itália, Alemanha e/ou Áustria.
- O modo de fronteiras altera o cálculo com o Valhalla (perfil de mota experimental), os pontos cénicos candidatos e a validação dos trajetos. As seleções ficam guardadas neste telemóvel.
- Todos os segmentos da rota são verificados contra os países escolhidos; o cálculo de regresso por uma estrada diferente mantém-se.
- A política de fronteiras fica associada ao percurso calculado/guardado. Reabrir uma rota guardada restaura as escolhas correspondentes.
- **Liechtenstein não está nesta primeira versão**, porque não temos um contorno com qualidade adequada incluído.

## Limitações importantes

- Para os países vizinhos, usa geometrias **generalizadas do Natural Earth 1:110m (domínio público), alargadas cerca de 7 km para compensar a imprecisão cartográfica perto das fronteiras**. Isso significa que a validação multinacional é apenas indicativa e **NÃO confirma em absoluto o país de cada troço**, o posto fronteiriço ou a legalidade da circulação.
- A posição GPS também não confirma estradas abertas, portagens, autorização para motos ou trânsito. Não é um GPS certificado. Verifica o percurso e a sinalização antes de conduzir.
- O servidor público Valhalla tem limites e pode não produzir um circuito válido para a duração pedida. A TomTom ainda não está ativada nesta versão.
- Testes automatizados locais passaram, mas **não foi feita navegação real num Samsung nem uma chamada real ao Valhalla** nesta sessão.
- Esta versão foi criada com um identificador Android separado (`test21`), para não substituir a v0.20.

## Instalação

1. Enviar o conteúdo deste arquivo ao GitHub como `android-source.zip`.
2. O workflow Android compila `:app:assembleDebug` e disponibiliza um APK debug.
3. Testar com a mota parada: **Rotas → Passagem de fronteiras → Permitir países vizinhos → França → 2 horas → Surpresa**.

Geometrias: Natural Earth public domain, obtidas da cópia local `naturalearth_lowres` distribuída com Pyogrio, com simplificação e margem cartográfica.
